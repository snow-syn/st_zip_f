export type ValidationStepStatus =
  | 'pending'
  | 'processing'
  | 'success'
  | 'error';

export interface ValidationStep {
  id: string;
  name: string;
  status: ValidationStepStatus;
  message?: string;
}

export interface ValidationState {
  isValidating: boolean;
  isSaving: boolean;
  validationSteps: ValidationStep[];
  validationErrors: string[];
  showValidateDialog: boolean;
  showConfirmSave: boolean;
}
