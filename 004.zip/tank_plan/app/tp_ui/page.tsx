'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Activity,
  Calendar,
  History,
  ListTodo,
  List,
  Info,
} from 'lucide-react';
import { PlanList } from './components/plan-list';
import { OperationLog } from './components/operation-log';
import { HistoryList } from './components/history-list';
import { cn } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import DatabaseService from './services/DatabaseService';
import { logger } from './utils/logger';
import { Badge } from '@/components/ui/badge';
import type { PlanVersion } from './types';

function StatCard({
  title,
  value,
  icon,
  description,
  onClick,
  tags,
}: {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
  onClick?: () => void;
  tags?: React.ReactNode;
}) {
  return (
    <motion.div
      whileHover={{ scale: onClick ? 1.02 : 1 }}
      whileTap={{ scale: onClick ? 0.98 : 1 }}
      onClick={onClick}
      className={cn('relative h-[88px]', onClick && 'cursor-pointer')}
    >
      <Card className="group relative h-full overflow-hidden">
        <div className="absolute right-0 top-0 h-16 w-16 translate-x-4 translate-y-[-4px] rotate-12 transform bg-gradient-to-br from-primary/5 to-transparent" />
        <CardContent className="flex h-full flex-col justify-center p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <p className="text-xs font-medium text-muted-foreground">
                  {title}
                </p>
                {tags}
              </div>
              <div className="flex items-center gap-2">
                <p className="text-lg font-semibold tracking-tight">{value}</p>
                {description && (
                  <p className="text-xs text-muted-foreground">{description}</p>
                )}
              </div>
            </div>
            <div className="rounded-lg bg-primary/10 p-2">{icon}</div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function NavCard({
  title,
  icon,
  href,
}: {
  title: string;
  icon: React.ReactNode;
  href: string;
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="cursor-pointer"
      onClick={() => (window.location.href = href)}
    >
      <Card className="group relative overflow-hidden border transition-colors hover:border-primary/50">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        <CardContent className="flex flex-col items-center p-4">
          {' '}
          <div className="mb-2 rounded-xl bg-primary/10 p-2 shadow-lg shadow-primary/5 ring-1 ring-primary/10 transition-all duration-300 group-hover:bg-primary/20 group-hover:shadow-primary/10 group-hover:ring-primary/20">
            {icon}
          </div>
          <h3 className="text-sm font-semibold">{title}</h3>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function TankPlanUI() {
  const router = useRouter();
  const [latestPlan, setLatestPlan] = useState<PlanVersion | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const loadLatestPlan = async () => {
      const context = {
        module: 'TankPlanUI',
        function: 'loadLatestPlan',
      };

      try {
        logger.debug('Loading latest plan', context);
        setIsLoading(true);

        const result = await DatabaseService.getLatestPlan();
        logger.debug('Latest plan API response', context, { result });

        if (result.success && result.data) {
          setLatestPlan(result.data);
          logger.debug('Latest plan loaded successfully', context, {
            plan: result.data,
          });
        } else {
          logger.warn('No latest plan found or API error', context, {
            success: result.success,
            error: result.error,
          });
        }
      } catch (error) {
        logger.error('Failed to load latest plan', context, {
          error,
          message: error instanceof Error ? error.message : 'Unknown error',
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadLatestPlan();
  }, []);

  const handleLatestPlanClick = () => {
    if (latestPlan) {
      logger.debug('Navigating to latest plan', {
        module: 'TankPlanUI',
        planId: latestPlan.plan_master_id,
      });
      router.push(`/tp_ui/plan-view?id=${latestPlan.plan_master_id}`);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const modules = [
    {
      title: 'Plan List',
      icon: <List className="h-4 w-4 text-primary" />,
      href: '/tp_ui/plan-list',
    },
    {
      title: 'Long-term Plan',
      icon: <Calendar className="h-4 w-4 text-primary" />,
      href: '/tp_ui/long-term',
    },
    {
      title: 'Weekly Plan',
      icon: <ListTodo className="h-4 w-4 text-primary" />,
      href: '/tp_ui/weekly',
    },
    {
      title: 'Tank Detail',
      icon: <Info className="h-4 w-4 text-primary" />,
      href: '/tp_ui/tank-detail',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="flex h-full flex-col"
    >
      <div className="flex-none space-y-3">
        {' '}
        <div>
          <h1 className="px-2 text-xl font-semibold tracking-tight">
            Tank Plan UI
          </h1>
        </div>
        <div className="grid gap-2 md:grid-cols-3">
          <StatCard
            title="Latest Plan"
            value={
              isLoading
                ? 'Loading...'
                : latestPlan
                  ? latestPlan.plan_version
                  : 'No plans'
            }
            icon={<Activity className="h-4 w-4 text-primary" />}
            description={
              isLoading
                ? undefined
                : latestPlan
                  ? `by ${latestPlan.user_name}`
                  : undefined
            }
            tags={
              !isLoading &&
              latestPlan && (
                <div className="flex items-center gap-1 pl-2">
                  <Badge
                    variant="outline"
                    className={cn(
                      'h-4 px-1.5 text-[10px] font-medium',
                      latestPlan.plan_type === 'Long-term'
                        ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950/30 dark:text-blue-400'
                        : 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400',
                    )}
                  >
                    {latestPlan.plan_type}
                  </Badge>
                  {latestPlan.plan_version_no > 1 && (
                    <Badge
                      variant="outline"
                      className="h-4 px-1.5 text-[10px] font-medium"
                    >
                      v{latestPlan.plan_version_no}
                    </Badge>
                  )}
                  {latestPlan.plan_official && (
                    <Badge
                      variant="outline"
                      className={cn(
                        'h-4 px-1.5 text-[10px] font-medium',
                        latestPlan.plan_official === 'GB'
                          ? 'border-purple-300 bg-purple-50/50 text-purple-700 dark:border-purple-800 dark:bg-purple-950/20 dark:text-purple-400'
                          : 'border-amber-300 bg-amber-50/50 text-amber-700 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-400',
                      )}
                    >
                      {latestPlan.plan_official}
                    </Badge>
                  )}
                </div>
              )
            }
            onClick={latestPlan ? handleLatestPlanClick : undefined}
          />
          <StatCard
            title="Plans This Month"
            value="8"
            icon={<Calendar className="h-4 w-4 text-primary" />}
            description="4 weekly, 4 long-term"
          />
          <StatCard
            title="Recent Changes"
            value="24"
            icon={<History className="h-4 w-4 text-primary" />}
            description="Last 7 days"
          />
        </div>
        <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-4">
          {modules.map((module) => (
            <NavCard
              key={module.title}
              title={module.title}
              icon={module.icon}
              href={module.href}
            />
          ))}
        </div>
      </div>

      <div className="mt-3 min-h-0 flex-1">
        <Tabs defaultValue="plan-list" className="flex h-full flex-col">
          <div>
            <TabsList className="h-8 w-fit">
              <TabsTrigger value="plan-list" className="text-xs">
                Plan Version List
              </TabsTrigger>
              <TabsTrigger value="history-list" className="text-xs">
                Change History
              </TabsTrigger>
              <TabsTrigger value="operation-log" className="text-xs">
                Operation Log
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent
            value="plan-list"
            className="flex-1 overflow-auto data-[state=active]:flex-1"
          >
            <PlanList refreshing={refreshing} onRefresh={handleRefresh} />
          </TabsContent>

          <TabsContent
            value="history-list"
            className="flex-1 overflow-auto data-[state=active]:flex-1"
          >
            <HistoryList refreshing={refreshing} onRefresh={handleRefresh} />
          </TabsContent>

          <TabsContent
            value="operation-log"
            className="flex-1 overflow-auto data-[state=active]:flex-1"
          >
            <OperationLog refreshing={refreshing} onRefresh={handleRefresh} />
          </TabsContent>
        </Tabs>
      </div>
    </motion.div>
  );
}
