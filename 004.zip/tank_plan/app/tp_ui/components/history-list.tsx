import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import DatabaseService from '../services/DatabaseService';
import { cn } from '@/lib/utils';
import { DataListCard } from './data-list-card';
import { changeTypeOptions } from '../config/list-config';
import type { DateRange } from 'react-day-picker';
import { getDefaultDateRange } from '../utils';
import { useDataList } from '../hooks/useDataList';
import type { PlanHistoryRecord } from '../types';

interface HistoryListProps {
  refreshing: boolean;
  onRefresh: () => void;
}

export function HistoryList({ refreshing, onRefresh }: HistoryListProps) {
  const [selectedChangeType, setSelectedChangeType] = useState<string>('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>(
    getDefaultDateRange(),
  );

  const {
    data: historyRecords,
    loading,
    searchTerm,
    setSearchTerm,
    refresh,
  } = useDataList<PlanHistoryRecord>({
    loadData: async () => {
      const result = await DatabaseService.getHistoryRecords(
        dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : undefined,
        dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : undefined,
      );
      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load history records');
      }
      return {
        success: true,
        data: result.data,
      };
    },
    context: {
      module: 'HistoryList',
      function: 'loadHistoryRecords',
    },
    refreshTrigger: refreshing,
    filterFn: (record: PlanHistoryRecord, term: string): boolean => {
      // 首先检查日期范围
      if (dateRange?.from || dateRange?.to) {
        const recordDate = new Date(record.create_timestamp);
        if (dateRange.from && recordDate < dateRange.from) return false;
        if (dateRange.to && recordDate > dateRange.to) return false;
      }

      // 检查变更类型筛选
      if (selectedChangeType !== 'all' && record.change_type !== selectedChangeType) {
        return false;
      }

      // 搜索词筛选
      if (term) {
        const searchLower = term.toLowerCase();
        return (
          record.tank.toLowerCase().includes(searchLower) ||
          record.field_name.toLowerCase().includes(searchLower) ||
          (record.old_value?.toLowerCase() || '').includes(searchLower) ||
          (record.new_value?.toLowerCase() || '').includes(searchLower) ||
          record.user_name.toLowerCase().includes(searchLower) ||
          (record.plan_version?.toLowerCase() || '').includes(searchLower)
        );
      }

      return true;
    },
  });

  const getChangeTypeColor = (changeType: string) => {
    switch (changeType) {
      case 'INSERT':
        return 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950/30 dark:text-green-400';
      case 'UPDATE':
        return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/30 dark:text-blue-400';
      case 'DELETE':
        return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/30 dark:text-red-400';
      default:
        return '';
    }
  };

  return (
    <DataListCard<string>
      title="Change History"
      loading={loading}
      onRefresh={refresh}
      searchPlaceholder="Search changes..."
      onSearch={setSearchTerm}
      filterOptions={{
        type: changeTypeOptions,
      }}
      onFilterChange={{
        type: setSelectedChangeType,
      }}
      selectedFilters={{
        type: selectedChangeType,
      }}
      dateRange={dateRange}
      onDateRangeChange={setDateRange}
    >
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Plan Version</TableHead>
            <TableHead>Tank</TableHead>
            <TableHead>Change Type</TableHead>
            <TableHead>Field</TableHead>
            <TableHead>Old Value</TableHead>
            <TableHead>New Value</TableHead>
            <TableHead>User</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {historyRecords.map((record) => (
            <TableRow key={record.history_id}>
              <TableCell>
                {record.create_timestamp
                  ? format(new Date(record.create_timestamp), 'PPp')
                  : '-'}
              </TableCell>
              <TableCell>{record.plan_version || '-'}</TableCell>
              <TableCell>{record.tank}</TableCell>
              <TableCell>
                <Badge
                  variant="outline"
                  className={cn(
                    'font-medium',
                    getChangeTypeColor(record.change_type),
                  )}
                >
                  {record.change_type}
                </Badge>
              </TableCell>
              <TableCell>{record.field_name}</TableCell>
              <TableCell>{record.old_value || '-'}</TableCell>
              <TableCell>{record.new_value || '-'}</TableCell>
              <TableCell>{record.user_name}</TableCell>
            </TableRow>
          ))}
          {!historyRecords.length && (
            <TableRow>
              <TableCell colSpan={8} className="h-24 text-center">
                No records found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </DataListCard>
  );
}
