'use client';

import * as React from 'react';
import { Check, XCircle, Loader2, CheckCircle, Circle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { logger } from '../utils/logger';
import type { ValidationStep } from '../types/validation';

interface ValidationStepsProps {
  steps: ValidationStep[];
  isValidating: boolean;
  className?: string;
}

function ValidationSteps({
  steps,
  isValidating,
  className,
}: ValidationStepsProps) {
  return (
    <div
      className={cn(
        'space-y-2.5 rounded-lg bg-muted/30 p-3 transition-all duration-300',
        isValidating ? 'opacity-100' : 'opacity-80',
        className,
      )}
    >
      {steps.map((step) => (
        <div
          key={step.id}
          className={cn(
            'flex items-center gap-3 rounded-md px-3 py-2 transition-all duration-200',
            step.status === 'processing' &&
              'bg-background shadow-sm ring-1 ring-border/50',
            step.status === 'success' && 'text-green-600',
            step.status === 'error' && 'text-red-600',
          )}
        >
          <div className="flex-shrink-0">
            {step.status === 'pending' && (
              <Circle className="h-4 w-4 text-muted-foreground/30" />
            )}
            {step.status === 'processing' && (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            )}
            {step.status === 'success' && (
              <CheckCircle className="h-4 w-4 text-green-500" />
            )}
            {step.status === 'error' && (
              <XCircle className="h-4 w-4 text-red-500" />
            )}
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-sm font-medium">{step.name}</span>
            {step.message && (
              <span className="text-xs text-muted-foreground">
                {step.message}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

interface ValidationErrorsProps {
  errors: string[];
  className?: string;
}

function ValidationErrors({ errors, className }: ValidationErrorsProps) {
  if (!errors.length) return null;

  return (
    <div
      className={cn(
        'duration-300 animate-in fade-in slide-in-from-top-2',
        className,
      )}
    >
      <div className="space-y-3 rounded-lg bg-red-50 px-4 py-3 text-red-900 ring-1 ring-red-200">
        <div className="flex items-center gap-2">
          <div className="h-1 w-1 rounded-full bg-red-500" />
          <p className="text-sm font-medium">Please fix the following issues</p>
        </div>
        <ScrollArea className="h-[200px] w-full rounded pr-4">
          <div className="space-y-2 pl-3">
            {errors.map((error, index) => (
              <p
                key={index}
                className={cn(
                  'text-sm text-red-700',
                  'py-1',
                  'border-l-2 border-red-200/50 pl-2',
                  'animate-in fade-in-50 slide-in-from-top-1',
                  'duration-100',
                )}
              >
                {error}
              </p>
            ))}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

interface ValidationSuccessProps {
  step?: ValidationStep;
  message?: string;
  className?: string;
}

function ValidationSuccess({
  step,
  message,
  className,
}: ValidationSuccessProps) {
  if (!step || step.status !== 'pending') return null;

  return (
    <div
      className={cn(
        'duration-300 animate-in fade-in slide-in-from-top-2',
        className,
      )}
    >
      <div className="min-h-[90px] space-y-2 rounded-lg bg-green-50 px-4 py-3 text-green-900 ring-1 ring-green-200">
        <div className="flex items-center gap-2">
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100">
            <Check className="h-3 w-3 text-green-600" />
          </div>
          <p className="text-sm font-medium">Ready to save changes</p>
        </div>
        <div className="pl-7">
          <p className="text-sm text-green-700">
            {message ||
              'All validations passed successfully. Would you like to proceed with saving?'}
          </p>
        </div>
      </div>
    </div>
  );
}

interface SavingStatusProps {
  message?: string;
  className?: string;
}

function SavingStatus({
  message = 'Please wait while we save your data. This may take a few moments...',
  className,
}: SavingStatusProps) {
  return (
    <div
      className={cn(
        'duration-300 animate-in fade-in slide-in-from-top-2',
        className,
      )}
    >
      <div className="min-h-[90px] space-y-2 rounded-lg bg-primary/5 px-4 py-3 text-primary ring-1 ring-primary/20">
        <div className="flex items-center gap-2">
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/10">
            <Loader2 className="h-3 w-3 animate-spin text-primary" />
          </div>
          <p className="text-sm font-medium">Saving your changes</p>
        </div>
        <div className="pl-7">
          <p className="text-sm text-primary/80">{message}</p>
        </div>
      </div>
    </div>
  );
}

export interface ValidationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isValidating: boolean;
  isSaving: boolean;
  errors?: string[];
  validationSteps: ValidationStep[];
  onConfirmSave?: () => Promise<void>;
  className?: string;
}

export function ValidationDialog({
  open,
  onOpenChange,
  validationSteps,
  errors = [],
  isValidating,
  isSaving,
  onConfirmSave,
  className,
}: ValidationDialogProps) {
  const handleConfirmSave = async () => {
    try {
      logger.debug('Confirming save operation', {
        module: 'ValidationDialog',
      });
      await onConfirmSave?.();
    } catch (error) {
      logger.error('Failed to save changes', {
        module: 'ValidationDialog',
        error,
      });
    }
  };

  const getStatusIcon = () => {
    if (isValidating) {
      return (
        <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      );
    }
    if (errors.length > 0) {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
    return <Check className="h-4 w-4 text-primary" />;
  };

  const getStatusTitle = () => {
    if (isValidating) return 'Validating Data';
    if (errors.length > 0) return 'Validation Failed';
    return 'Save Data';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className={cn(
          'transition-all duration-300 sm:max-w-[525px]',
          className,
        )}
      >
        <DialogHeader className="space-y-4">
          <DialogTitle className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-background shadow-sm ring-1 ring-border/50">
              {getStatusIcon()}
            </div>
            <span className="text-lg font-medium">{getStatusTitle()}</span>
          </DialogTitle>

          <DialogDescription asChild>
            <div className="relative space-y-4">
              <ValidationSteps
                steps={validationSteps}
                isValidating={isValidating}
              />
              {errors.length > 0 && <ValidationErrors errors={errors} />}
              {!isValidating && errors.length === 0 && (
                <ValidationSuccess
                  step={validationSteps.find((s) => s.id === 'save')}
                />
              )}
              {isSaving && <SavingStatus />}
            </div>
          </DialogDescription>
        </DialogHeader>

        {!isValidating && !isSaving && (
          <DialogFooter className="mt-6">
            <div className="flex w-full items-center justify-end gap-3">
              <Button
                variant="ghost"
                onClick={() => onOpenChange(false)}
                className="transition-all duration-200"
              >
                Cancel
              </Button>

              {errors.length === 0 && onConfirmSave && (
                <Button
                  onClick={handleConfirmSave}
                  className="relative min-w-[120px] transition-all duration-200"
                >
                  Save Changes
                </Button>
              )}

              {errors.length > 0 && (
                <Button
                  variant="ghost"
                  onClick={() => onOpenChange(false)}
                  className="transition-all duration-200"
                >
                  Close
                </Button>
              )}
            </div>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
