import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import type { PlanType, PlanTag } from '../types';

interface TypeBadgeProps {
  type: PlanType;
  className?: string;
}

interface TagBadgeProps {
  tag: PlanTag;
  className?: string;
}

export function TypeBadge({ type, className }: TypeBadgeProps) {
  return (
    <Badge
      variant="outline"
      className={cn(
        'h-5 px-2 text-xs font-medium',
        type === 'Long-term'
          ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950/30 dark:text-blue-400'
          : 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400',
        className,
      )}
    >
      {type}
    </Badge>
  );
}

export function TagBadge({ tag, className }: TagBadgeProps) {
  if (!tag) return null;

  return (
    <Badge
      variant="outline"
      className={cn(
        'h-5 px-2 text-xs font-medium',
        tag === 'GB'
          ? 'border-purple-300 bg-purple-50/50 text-purple-700 hover:bg-purple-100 dark:border-purple-800 dark:bg-purple-950/20 dark:text-purple-400'
          : tag === '18MP'
            ? 'border-amber-300 bg-amber-50/50 text-amber-700 hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-400'
            : '',
        className,
      )}
    >
      {tag}
    </Badge>
  );
}
