import { useState, useCallback } from 'react';
import type { TankPlanDetailData } from '../types';
import { COLUMNS, validateField } from '../config/config';
import { logger } from '../utils/logger';

export type ValidationStepStatus =
  | 'pending'
  | 'processing'
  | 'success'
  | 'error';

export interface ValidationStep {
  id: string;
  name: string;
  status: ValidationStepStatus;
  message?: string;
}

const DEFAULT_VALIDATION_STEPS: ValidationStep[] = [
  { id: 'format', name: 'Format Validation', status: 'pending' },
  { id: 'required', name: 'Required Fields', status: 'pending' },
  { id: 'business', name: 'Business Rules', status: 'pending' },
  { id: 'save', name: 'Save Data', status: 'pending' },
];

interface ValidationOptions {
  onValidationStart?: () => void;
  onValidationComplete?: (success: boolean) => void;
  onStepUpdate?: (step: ValidationStep) => void;
}

export function useValidation(options?: ValidationOptions) {
  const [validationSteps, setValidationSteps] = useState<ValidationStep[]>(
    DEFAULT_VALIDATION_STEPS,
  );
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isValidating, setIsValidating] = useState(false);

  const updateStepStatus = useCallback(
    (stepId: string, status: ValidationStepStatus, message?: string) => {
      setValidationSteps((steps) =>
        steps.map((step) =>
          step.id === stepId ? { ...step, status, message } : step,
        ),
      );

      const updatedStep = validationSteps.find((step) => step.id === stepId);
      if (updatedStep) {
        options?.onStepUpdate?.({ ...updatedStep, status, message });
      }
    },
    [options, validationSteps],
  );

  const validateFormatAndRequired = useCallback(
    async (data: TankPlanDetailData[]) => {
      const errors: string[] = [];

      // Format validation
      updateStepStatus('format', 'processing');
      await new Promise((resolve) => setTimeout(resolve, 800));

      data.forEach((row, index) => {
        Object.entries(COLUMNS).forEach(([key, column]) => {
          if (!column.validation) return;
          const value = row[key as keyof TankPlanDetailData];
          const error = validateField(value, column);
          if (error) {
            errors.push(`Row ${index + 1}: ${error}`);
          }
        });
      });

      updateStepStatus('format', errors.length ? 'error' : 'success');
      if (errors.length) return errors;

      // Required fields validation
      updateStepStatus('required', 'processing');
      await new Promise((resolve) => setTimeout(resolve, 800));

      data.forEach((row, index) => {
        Object.entries(COLUMNS)
          .filter(([_, col]) =>
            col.validation?.some((rule) => rule.type === 'required'),
          )
          .forEach(([key, column]) => {
            const value = row[key as keyof TankPlanDetailData];
            if (!value?.trim()) {
              errors.push(`Row ${index + 1}: ${column.label} is required`);
            }
          });
      });

      updateStepStatus('required', errors.length ? 'error' : 'success');
      return errors;
    },
    [updateStepStatus],
  );

  const validateBusinessRules = useCallback(
    async (data: TankPlanDetailData[]) => {
      const errors: string[] = [];

      updateStepStatus('business', 'processing');
      await new Promise((resolve) => setTimeout(resolve, 800));

      data.forEach((row, index) => {
        if (row.drain_date && row.repair_date) {
          const drainDate = new Date(row.drain_date);
          const startDate = new Date(row.repair_date);
          if (drainDate > startDate) {
            errors.push(
              `Row ${index + 1}: Drain date must be before Start date`,
            );
          }
        }
      });

      updateStepStatus('business', errors.length ? 'error' : 'success');
      return errors;
    },
    [updateStepStatus],
  );

  const validateData = useCallback(
    async (data: TankPlanDetailData[]): Promise<string[]> => {
      const context = {
        module: 'useValidation',
        function: 'validateData',
        dataLength: data.length,
      };

      try {
        logger.group('Starting data validation', context);
        setIsValidating(true);
        options?.onValidationStart?.();

        const formatAndRequiredErrors = await validateFormatAndRequired(data);
        if (formatAndRequiredErrors.length) {
          return formatAndRequiredErrors;
        }

        const businessErrors = await validateBusinessRules(data);

        options?.onValidationComplete?.(businessErrors.length === 0);
        return businessErrors;
      } catch (error) {
        logger.error('Validation failed', context, { error });
        const errorMessage =
          error instanceof Error ? error.message : 'Unknown validation error';
        return [errorMessage];
      } finally {
        setIsValidating(false);
        logger.groupEnd();
      }
    },
    [validateFormatAndRequired, validateBusinessRules, options],
  );

  const resetValidation = useCallback(() => {
    setValidationSteps(DEFAULT_VALIDATION_STEPS);
    setValidationErrors([]);
    setIsValidating(false);
  }, []);

  return {
    validationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
    resetValidation,
  } as const;
}
