import { useState } from 'react';
import type { TankPlanDetailData } from '../types';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';

interface UseLatestPlanOptions {
  onSuccess?: (data: TankPlanDetailData[]) => void;
  onError?: (error: string) => void;
  onLoadStart?: () => void;
  onLoadEnd?: () => void;
}

export function useLatestPlan(options?: UseLatestPlanOptions) {
  const [isLoading, setIsLoading] = useState(false);

  const loadLatestPlan = async () => {
    const context = {
      module: 'useLatestPlan',
      function: 'loadLatestPlan',
    };

    try {
      logger.group('Loading latest plan', context);
      setIsLoading(true);
      options?.onLoadStart?.();

      const result = await DatabaseService.getLatestPlanData();

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load latest plan');
      }

      logger.debug('Latest plan loaded successfully', context, {
        rowCount: result.data.length,
      });

      options?.onSuccess?.(result.data);
      return result.data;
    } catch (error) {
      logger.error('Failed to load latest plan', context, { error });
      const errorMessage =
        error instanceof Error ? error.message : 'Failed to load latest plan';
      options?.onError?.(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
      options?.onLoadEnd?.();
      logger.groupEnd();
    }
  };

  return {
    isLoading,
    loadLatestPlan,
  } as const;
}
