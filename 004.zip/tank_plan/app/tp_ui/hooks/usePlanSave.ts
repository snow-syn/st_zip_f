import { useState } from 'react';
import type { TankPlanDetailData, PlanType } from '../types';
import { logger } from '../utils/logger';
import { useToast } from '@/hooks/use-toast';
import { useValidation } from './useValidation';
import { useSaveData } from './useSaveData';

interface UsePlanSaveOptions {
  onSaveSuccess?: () => void;
  onSaveError?: (error: string) => void;
}

export function usePlanSave(options?: UsePlanSaveOptions) {
  const [showValidateDialog, setShowValidateDialog] = useState(false);
  const [showConfirmSave, setShowConfirmSave] = useState(false);
  const { toast } = useToast();
  const { saveData, isSaving } = useSaveData();
  const {
    validationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
  } = useValidation();

  const handleSave = async (data: TankPlanDetailData[]) => {
    try {
      setShowValidateDialog(true);
      setIsValidating(true);
      setValidationErrors([]);

      updateStepStatus('format', 'pending');
      updateStepStatus('required', 'pending');
      updateStepStatus('business', 'pending');
      updateStepStatus('save', 'pending');

      const errors = await validateData(data);

      if (errors.length > 0) {
        setValidationErrors(errors);
        return;
      }

      setShowConfirmSave(true);
      setIsValidating(false);
    } catch (error) {
      logger.error('Validation failed', { error });
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to validate data',
      });
      setIsValidating(false);
    }
  };

  const handleConfirmSave = async (
    data: TankPlanDetailData[],
    planType: PlanType,
  ) => {
    try {
      updateStepStatus('save', 'processing');

      const success = await saveData(data, planType);

      if (success) {
        updateStepStatus('save', 'success');
        toast({
          title: 'Success',
          description: 'Plan saved successfully',
        });

        setTimeout(() => {
          setShowValidateDialog(false);
          options?.onSaveSuccess?.();
        }, 1000);
      } else {
        updateStepStatus('save', 'error', 'Failed to save data');
        options?.onSaveError?.('Failed to save data');
      }
    } catch (error) {
      logger.error('Save error:', { error });
      updateStepStatus('save', 'error', 'Failed to save data');
      options?.onSaveError?.(
        error instanceof Error ? error.message : 'Failed to save data',
      );
    }
  };

  return {
    showValidateDialog,
    setShowValidateDialog,
    showConfirmSave,
    setShowConfirmSave,
    validationSteps,
    validationErrors,
    isValidating,
    isSaving,
    handleSave,
    handleConfirmSave,
  } as const;
}
