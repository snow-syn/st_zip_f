import { useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useErrorState } from './useErrorState';
import { usePlanData } from './usePlanData';
import { useVersionInfo } from './useVersionInfo';
import { useExport } from './useExport';
import { useLoadingState } from './useLoadingState';
import { ltPlanExcelConfig } from '../config/excel-config';
import { logger } from '../utils/logger';

export function usePlanView(planId: string | null) {
  const router = useRouter();
  const { errors, addError, clearErrors } = useErrorState();

  const {
    data,
    setData,
    isLoading: isLoadingData,
    loadPlanData,
  } = usePlanData({
    onError: addError,
  });

  const {
    versionInfo,
    parentInfo,
    isLoading: isLoadingVersion,
    loadVersionInfo,
  } = useVersionInfo({
    loadParentInfo: true,
    onError: addError,
  });

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);

  const loadingState = useLoadingState({
    isLoadingData,
    isLoadingVersion,
    isExporting,
  });

  const handleParentClick = useCallback(
    (parentId: number) => {
      const context = {
        module: 'usePlanView',
        function: 'handleParentClick',
        parentId,
      };

      try {
        logger.debug('Navigating to parent plan', context);
        router.replace(`/tp_ui/plan-view?id=${parentId}`);
      } catch (error) {
        logger.error('Failed to navigate to parent plan', context, { error });
        addError(error);
      }
    },
    [router, addError],
  );

  const handleCreateWeekly = useCallback(() => {
    if (!versionInfo) return;

    const context = {
      module: 'usePlanView',
      function: 'handleCreateWeekly',
      sourceVersionId: versionInfo.plan_master_id,
    };

    try {
      logger.debug('Navigating to weekly plan creation', context);
      router.push(`/tp_ui/weekly?id=${versionInfo.plan_master_id}`);
    } catch (error) {
      logger.error('Failed to navigate to weekly plan creation', context, {
        error,
      });
      addError(error);
    }
  }, [router, versionInfo, addError]);

  const loadData = useCallback(async () => {
    if (!planId) {
      addError('No plan ID provided');
      return;
    }

    try {
      await Promise.all([loadPlanData(planId), loadVersionInfo(planId)]);
    } catch (error) {
      logger.error('Failed to load data', { error });
      addError(error);
    }
  }, [planId, loadPlanData, loadVersionInfo, addError]);

  return {
    data,
    versionInfo,
    parentInfo,
    errors,
    clearErrors,
    loadingState,
    handleParentClick,
    handleCreateWeekly,
    handleExport,
    loadData,
  } as const;
}
