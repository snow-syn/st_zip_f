import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/app/tp_ui/utils/logger';
import {
  ExcelProcessor,
  type ExcelConfig,
} from '@/app/tp_ui/utils/excel-processor';

interface UseExportOptions {
  onExportStart?: () => void;
  onExportSuccess?: (fileName: string, rowCount: number) => void;
  onExportError?: (error: string) => void;
  onExportComplete?: () => void;
  fileNamePrefix?: string;
}

export function useExport<T>(
  data: T[],
  excelConfig: ExcelConfig<T>,
  options?: UseExportOptions,
) {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const generateFileName = useCallback(() => {
    const prefix = options?.fileNamePrefix || 'Export';
    const date = new Date().toISOString().split('T')[0];
    return `${prefix}_${date}.xlsx`;
  }, [options?.fileNamePrefix]);

  const downloadFile = useCallback((blob: Blob, fileName: string) => {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }, []);

  const handleExport = useCallback(async () => {
    const context = {
      module: 'useExport',
      function: 'handleExport',
      dataLength: data.length,
    };

    if (isExporting || !data.length) {
      logger.warn('Export skipped', context, {
        reason: isExporting ? 'Already exporting' : 'No data',
      });
      return;
    }

    try {
      logger.group('Starting export', context);
      setIsExporting(true);
      options?.onExportStart?.();

      const excelProcessor = new ExcelProcessor(excelConfig);
      const blob = await excelProcessor.exportToExcel(data);
      const fileName = generateFileName();

      downloadFile(blob, fileName);

      logger.debug('Export successful', context, {
        fileName,
        rowCount: data.length,
      });

      toast({
        title: 'Export Successful',
        description: `${data.length} rows exported to ${fileName}`,
      });

      options?.onExportSuccess?.(fileName, data.length);
    } catch (error) {
      logger.error('Export failed', context, { error });
      const errorMessage =
        error instanceof Error ? error.message : 'Export failed';

      toast({
        variant: 'destructive',
        title: 'Export Failed',
        description: errorMessage,
      });

      options?.onExportError?.(errorMessage);
    } finally {
      setIsExporting(false);
      options?.onExportComplete?.();
      logger.groupEnd();
    }
  }, [
    data,
    isExporting,
    excelConfig,
    generateFileName,
    downloadFile,
    toast,
    options,
  ]);

  return {
    handleExport,
    isExporting,
  } as const;
}
