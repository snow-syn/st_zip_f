import { useState } from 'react';
import type { TankPlanDetailData, PlanType } from '@/app/tp_ui/types';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/app/tp_ui/utils/logger';
import DatabaseService from '@/app/tp_ui/services/DatabaseService';

interface SaveDataOptions {
  parentId?: string | null;
  versionNo?: number;
}

export function useSaveData() {
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const { toast } = useToast();

  const saveData = async (
    data: TankPlanDetailData[],
    planType: PlanType,
    options?: SaveDataOptions,
  ): Promise<boolean> => {
    const context = {
      module: 'useSaveData',
      function: 'saveData',
      requestId: `save-${Date.now()}`,
    };

    try {
      logger.group('Starting save operation', context);
      setIsSaving(true);

      const currentDate = new Date();
      const planVersion = currentDate.toISOString().split('T')[0];
      const versionMatch = currentDate
        .toISOString()
        .substring(0, 7)
        .replace('-', '');
      const versionNo = options?.versionNo || 1;

      // 构建 master 记录
      const masterInsertQuery = {
        sql: `
          INSERT INTO app_tank_plan_master (
            plan_version,
            plan_type,
            plan_official,
            plan_version_no,
            plan_version_parent,
            version_match,
            user_name
          ) 
          VALUES (?, ?, '', ?, ?, ?, 'system');
        `,
        params: [
          planVersion,
          planType,
          versionNo,
          options?.parentId || null,
          versionMatch,
        ],
      };

      const result = await DatabaseService.executeSQLQuery(
        masterInsertQuery.sql,
        masterInsertQuery.params,
      );

      if (result.status.state !== 'SUCCEEDED') {
        throw new Error('Failed to save data');
      }

      return true;
    } catch (error) {
      logger.error('Save operation failed', context, { error });
      setErrors([
        error instanceof Error ? error.message : 'Failed to save data',
      ]);
      return false;
    } finally {
      setIsSaving(false);
      logger.groupEnd();
    }
  };

  return {
    saveData,
    isSaving,
    errors,
  } as const;
}
