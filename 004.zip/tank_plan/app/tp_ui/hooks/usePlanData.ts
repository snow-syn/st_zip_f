import { useState, useCallback } from 'react';
import type { TankPlanDetailData } from '../types';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';

interface UsePlanDataOptions {
  onError?: (error: string) => void;
}

export function usePlanData(options?: UsePlanDataOptions) {
  const [data, setData] = useState<TankPlanDetailData[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadPlanData = useCallback(
    async (id: string | number) => {
      const context = {
        module: 'usePlanData',
        function: 'loadPlanData',
        planId: id,
      };

      try {
        logger.group('Loading plan data', context);
        setIsLoading(true);

        const result = await DatabaseService.getVersionData(Number(id));

        if (!result.success || !result.data) {
          throw new Error(result.error || 'Failed to load plan data');
        }

        setData(result.data);
        return result.data;
      } catch (error) {
        logger.error('Failed to load plan data', context, { error });
        const errorMessage =
          error instanceof Error ? error.message : 'Failed to load plan data';
        options?.onError?.(errorMessage);
        throw error;
      } finally {
        setIsLoading(false);
        logger.groupEnd();
      }
    },
    [options?.onError],
  );

  const clearData = useCallback(() => {
    setData([]);
  }, []);

  return {
    data,
    setData,
    isLoading,
    loadPlanData,
    clearData,
  } as const;
}
