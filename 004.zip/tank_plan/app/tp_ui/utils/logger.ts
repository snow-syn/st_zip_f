export enum LogLevel {
  NONE = 0,
  ERROR = 1,
  WARN = 2,
  INFO = 3,
  DEBUG = 4,
  TRACE = 5,
}

export type LogContext = {
  module?: string;
  function?: string;
  requestId?: string;
  [key: string]: any;
};

class Logger {
  private debugLevel: LogLevel;
  private static instance: Logger;
  private groupLevel: number = 0;
  private readonly MAX_STRING_LENGTH = 1000;

  private constructor() {
    this.debugLevel = Number(
      process.env.NEXT_PUBLIC_DEBUG_LEVEL || LogLevel.NONE,
    );
  }

  static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  private shouldLog(level: LogLevel): boolean {
    return this.debugLevel >= level;
  }

  error(message: string, context?: LogContext, data?: any) {
    this.logWithLevel(LogLevel.ERROR, 'ERROR', message, context, data);
  }

  warn(message: string, context?: LogContext, data?: any) {
    this.logWithLevel(LogLevel.WARN, 'WARN', message, context, data);
  }

  info(message: string, context?: LogContext, data?: any) {
    this.logWithLevel(LogLevel.INFO, 'INFO', message, context, data);
  }

  debug(message: string, context?: LogContext, data?: any) {
    this.logWithLevel(LogLevel.DEBUG, 'DEBUG', message, context, data);
  }

  trace(message: string, context?: LogContext, data?: any) {
    this.logWithLevel(LogLevel.TRACE, 'TRACE', message, context, data);
  }

  group(name: string, context?: LogContext, level: LogLevel = LogLevel.DEBUG) {
    if (this.shouldLog(level)) {
      console.group(this.formatMessage(LogLevel[level], name, context));
      this.groupLevel++;
    }
  }

  groupEnd(level: LogLevel = LogLevel.DEBUG) {
    if (this.shouldLog(level)) {
      console.groupEnd();
      this.groupLevel = Math.max(0, this.groupLevel - 1);
    }
  }

  startTimer(label: string) {
    if (this.shouldLog(LogLevel.DEBUG)) {
      console.time(label);
    }
  }

  endTimer(label: string) {
    if (this.shouldLog(LogLevel.DEBUG)) {
      console.timeEnd(label);
    }
  }

  private formatMessage(
    level: string,
    message: string,
    context?: LogContext,
    data?: any,
  ): string {
    const timestamp = new Date().toISOString();
    const indent = '  '.repeat(this.groupLevel);
    let formattedMessage = `${indent}[${timestamp}] [${level}]`;

    if (context) {
      if (context.module) formattedMessage += ` [${context.module}]`;
      if (context.function) formattedMessage += ` [${context.function}]`;
      if (context.requestId) formattedMessage += ` [REQ:${context.requestId}]`;
    }

    formattedMessage += ` ${message}`;

    if (data) {
      formattedMessage += `\n${indent}${JSON.stringify(data, null, 2)}`;
    }

    return formattedMessage;
  }

  private logWithLevel(
    level: LogLevel,
    levelName: string,
    message: string,
    context?: LogContext,
    data?: any,
  ) {
    if (this.shouldLog(level)) {
      const formattedMessage = this.formatMessage(
        levelName,
        message,
        context,
        data,
      );
      switch (level) {
        case LogLevel.ERROR:
          console.error(formattedMessage);
          break;
        case LogLevel.WARN:
          console.warn(formattedMessage);
          break;
        case LogLevel.INFO:
          console.info(formattedMessage);
          break;
        case LogLevel.DEBUG:
        case LogLevel.TRACE:
          console.log(formattedMessage);
          break;
      }
    }
  }
}

export const logger = Logger.getInstance();
