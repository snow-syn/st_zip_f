-- Tank Plan History Test Data
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (1, 1, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (2, 1, 
                     '7', 'T05',
                     'tank_life', '3.56', '4.38',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (3, 1, 
                     '25', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (4, 1, 
                     '16', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (5, 1, 
                     '21', 'T02',
                     'cold_idle', '1.32', '2.99',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (6, 2, 
                     '4', 'T08',
                     'drain_date', '2024-04-03', '2024-04-29',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (7, 2, 
                     '21', 'T06',
                     'drain_date', '2024-02-16', '2024-05-15',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (8, 2, 
                     '4', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (9, 2, 
                     '9', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (10, 2, 
                     '26', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (11, 2, 
                     '18', 'T10',
                     'repair_LT', '2.66', '2.04',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (12, 2, 
                     '19', 'T09',
                     'repair_date', '2024-06-25', '2024-09-19',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (13, 2, 
                     '13', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (14, 3, 
                     '19', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (15, 3, 
                     '19', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (16, 3, 
                     '9', 'T05',
                     'repair_date', '2024-03-19', '2024-04-06',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (17, 4, 
                     '24', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (18, 4, 
                     '11', 'T05',
                     'cold_idle', '2.36', '3.85',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (19, 4, 
                     '10', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (20, 4, 
                     '11', 'T05',
                     'tank_life', '2.14', '1.33',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (21, 4, 
                     '20', 'T10',
                     'GG_date', '2024-03-18', '2024-05-24',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (22, 5, 
                     '13', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (23, 5, 
                     '24', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (24, 5, 
                     '25', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (25, 5, 
                     '7', 'T07',
                     'GG_date', '2024-06-28', '2024-04-07',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (26, 5, 
                     '18', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (27, 6, 
                     '3', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (28, 6, 
                     '25', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (29, 6, 
                     '20', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (30, 6, 
                     '10', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (31, 6, 
                     '6', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (32, 6, 
                     '25', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (33, 6, 
                     '7', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (34, 6, 
                     '16', 'T03',
                     'RTL_LT', '3.23', '3.66',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (35, 7, 
                     '11', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (36, 7, 
                     '18', 'T08',
                     'TL_date', '2024-08-11', '2024-06-24',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (37, 7, 
                     '19', 'T08',
                     'RTL_LT', '3.69', '2.69',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (38, 7, 
                     '17', 'T06',
                     'tank_life', '4.4', '3.07',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (39, 8, 
                     '18', 'T07',
                     'cold_idle', '4.11', '3.2',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (40, 8, 
                     '3', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (41, 8, 
                     '19', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (42, 9, 
                     '20', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (43, 9, 
                     '4', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (44, 9, 
                     '1', 'T10',
                     'TL_date', '2024-03-21', '2024-09-04',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (45, 9, 
                     '20', 'T08',
                     'drain_date', '2024-03-28', '2023-12-29',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (46, 10, 
                     '5', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (47, 10, 
                     '20', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (48, 10, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (49, 10, 
                     '19', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (50, 10, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (51, 10, 
                     '9', 'T02',
                     'drain_date', '2024-02-20', '2024-09-25',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (52, 10, 
                     '15', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (53, 11, 
                     '21', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (54, 11, 
                     '16', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (55, 11, 
                     '22', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (56, 12, 
                     '18', 'T07',
                     'RTL_date', '2023-12-13', '2023-12-20',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (57, 12, 
                     '20', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (58, 12, 
                     '19', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (59, 13, 
                     '17', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (60, 13, 
                     '13', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (61, 13, 
                     '18', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (62, 13, 
                     '11', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (63, 14, 
                     '5', 'T03',
                     'drain_date', '2024-02-10', '2024-07-31',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (64, 14, 
                     '13', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (65, 14, 
                     '1', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (66, 14, 
                     '3', 'T02',
                     'tank_life', '3.67', '2.46',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (67, 14, 
                     '17', 'T08',
                     'tank_life', '1.71', '1.98',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (68, 14, 
                     '23', 'T01',
                     'RTL_date', '2024-09-01', '2024-04-26',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (69, 15, 
                     '18', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (70, 15, 
                     '10', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (71, 15, 
                     '9', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (72, 15, 
                     '26', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (73, 15, 
                     '6', 'T09',
                     'repair_date', '2024-04-19', '2023-12-12',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (74, 16, 
                     '23', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (75, 16, 
                     '16', 'T04',
                     'RTL_date', '2024-06-30', '2023-12-18',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (76, 16, 
                     '21', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (77, 16, 
                     '16', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (78, 16, 
                     '20', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (79, 17, 
                     '11', 'T10',
                     'RTL_LT', '2.06', '2.66',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (80, 17, 
                     '18', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (81, 17, 
                     '27', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (82, 17, 
                     '21', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (83, 17, 
                     '8', 'T05',
                     'RTL_date', '2024-07-25', '2024-02-10',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (84, 17, 
                     '29', 'T09',
                     'tank_life', '1.89', '4.43',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (85, 18, 
                     '22', 'T10',
                     'drain_date', '2024-02-29', '2024-08-27',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (86, 18, 
                     '25', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (87, 18, 
                     '14', 'T01',
                     'RTL_LT', '3.9', '2.04',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (88, 18, 
                     '6', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (89, 18, 
                     '19', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (90, 18, 
                     '25', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (91, 19, 
                     '19', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (92, 19, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (93, 19, 
                     '20', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (94, 19, 
                     '22', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (95, 20, 
                     '24', 'T10',
                     'cold_idle', '3.97', '3.1',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (96, 20, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (97, 20, 
                     '5', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (98, 20, 
                     '7', 'T01',
                     'repair_date', '2023-12-30', '2024-06-29',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (99, 20, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (100, 20, 
                     '11', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (101, 20, 
                     '1', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (102, 20, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (103, 21, 
                     '24', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (104, 21, 
                     '19', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (105, 21, 
                     '10', 'T05',
                     'drain_date', '2024-10-18', '2024-03-14',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (106, 21, 
                     '4', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (107, 21, 
                     '12', 'T02',
                     'TL_LT', '2.77', '4.59',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (108, 21, 
                     '9', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (109, 21, 
                     '8', 'T04',
                     'GG_date', '2024-04-08', '2024-04-24',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (110, 21, 
                     '14', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (111, 22, 
                     '5', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (112, 22, 
                     '26', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (113, 22, 
                     '22', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (114, 22, 
                     '25', 'T09',
                     'GG_date', '2024-02-10', '2024-03-28',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (115, 23, 
                     '14', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (116, 23, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (117, 23, 
                     '3', 'T09',
                     'TL_date', '2024-06-10', '2023-12-31',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (118, 23, 
                     '7', 'T02',
                     'repair_date', '2024-08-07', '2023-12-30',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (119, 23, 
                     '12', 'T09',
                     'drain_date', '2024-02-03', '2024-03-14',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (120, 24, 
                     '23', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (121, 24, 
                     '16', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (122, 24, 
                     '6', 'T08',
                     'TL_LT', '2.8', '2.92',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (123, 24, 
                     '6', 'T08',
                     'cold_idle', '3.93', '4.97',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (124, 24, 
                     '24', 'T02',
                     'GG_date', '2024-04-20', '2024-08-11',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (125, 24, 
                     '6', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (126, 24, 
                     '17', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (127, 24, 
                     '21', 'T07',
                     'TL_LT', '4.48', '4.79',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (128, 25, 
                     '7', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (129, 25, 
                     '8', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (130, 25, 
                     '20', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (131, 25, 
                     '10', 'T09',
                     'RTL_date', '2024-04-13', '2024-04-25',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (132, 25, 
                     '22', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (133, 25, 
                     '8', 'T08',
                     'drain_date', '2024-01-19', '2024-08-09',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (134, 25, 
                     '5', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (135, 25, 
                     '2', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (136, 26, 
                     '10', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (137, 26, 
                     '3', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (138, 26, 
                     '4', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (139, 27, 
                     '12', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (140, 27, 
                     '11', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (141, 27, 
                     '13', 'T06',
                     'cold_idle', '3.17', '2.59',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (142, 27, 
                     '16', 'T04',
                     'cold_idle', '2.41', '4.89',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (143, 27, 
                     '5', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (144, 27, 
                     '9', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (145, 27, 
                     '6', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (146, 27, 
                     '14', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (147, 28, 
                     '12', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (148, 28, 
                     '3', 'T05',
                     'RTL_date', '2024-01-16', '2024-02-02',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (149, 28, 
                     '11', 'T09',
                     'TL_LT', '4.14', '3.7',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (150, 28, 
                     '6', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (151, 28, 
                     '20', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (152, 28, 
                     '12', 'T03',
                     'RTL_date', '2024-07-05', '2024-07-22',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (153, 28, 
                     '18', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (154, 28, 
                     '21', 'T07',
                     'GG_date', '2024-10-01', '2024-06-11',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (155, 29, 
                     '15', 'T07',
                     'cold_idle', '4.01', '1.6',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (156, 29, 
                     '17', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (157, 29, 
                     '12', 'T10',
                     'RTL_date', '2024-07-24', '2024-09-20',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (158, 29, 
                     '12', 'T10',
                     'drain_date', '2024-10-14', '2023-12-14',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (159, 30, 
                     '3', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (160, 30, 
                     '20', 'T10',
                     'cold_idle', '2.91', '1.85',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (161, 30, 
                     '3', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (162, 31, 
                     '17', 'T07',
                     'repair_date', '2024-06-23', '2024-06-30',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (163, 31, 
                     '18', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (164, 31, 
                     '9', 'T10',
                     'drain_date', '2024-01-14', '2024-07-16',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (165, 32, 
                     '16', 'T08',
                     'TL_LT', '4.66', '1.57',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (166, 32, 
                     '18', 'T07',
                     'TL_date', '2024-04-17', '2024-06-26',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (167, 32, 
                     '14', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (168, 33, 
                     '14', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (169, 33, 
                     '12', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (170, 33, 
                     '15', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (171, 33, 
                     '2', 'T05',
                     'drain_date', '2024-10-10', '2024-07-06',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (172, 34, 
                     '3', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (173, 34, 
                     '3', 'T01',
                     'RTL_LT', '3.22', '1.36',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (174, 34, 
                     '1', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (175, 34, 
                     '17', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (176, 34, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (177, 34, 
                     '7', 'T06',
                     'drain_date', '2023-12-19', '2024-02-24',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (178, 35, 
                     '19', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (179, 35, 
                     '20', 'T10',
                     'repair_date', '2024-06-21', '2024-08-07',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (180, 35, 
                     '7', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (181, 35, 
                     '15', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (182, 35, 
                     '14', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (183, 35, 
                     '1', 'T04',
                     'TL_LT', '2.72', '2.81',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (184, 36, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (185, 36, 
                     '11', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (186, 36, 
                     '4', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (187, 36, 
                     '9', 'T01',
                     'drain_date', '2024-08-16', '2024-10-27',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (188, 36, 
                     '6', 'T10',
                     'cold_idle', '3.08', '1.21',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (189, 36, 
                     '15', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (190, 37, 
                     '13', 'T02',
                     'repair_LT', '2.72', '2.51',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (191, 37, 
                     '3', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (192, 37, 
                     '30', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (193, 37, 
                     '4', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (194, 37, 
                     '9', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (195, 37, 
                     '18', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (196, 38, 
                     '3', 'T03',
                     'RTL_LT', '3.07', '1.95',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (197, 38, 
                     '10', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (198, 38, 
                     '10', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (199, 38, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (200, 39, 
                     '20', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (201, 39, 
                     '7', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (202, 39, 
                     '4', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (203, 39, 
                     '17', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (204, 39, 
                     '14', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (205, 39, 
                     '9', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (206, 39, 
                     '12', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (207, 40, 
                     '17', 'T05',
                     'GG_date', '2024-05-17', '2024-03-07',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (208, 40, 
                     '14', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (209, 40, 
                     '5', 'T03',
                     'tank_life', '4.62', '3.25',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (210, 40, 
                     '23', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (211, 40, 
                     '2', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (212, 40, 
                     '4', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (213, 40, 
                     '20', 'T01',
                     'drain_date', '2024-08-16', '2024-10-06',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (214, 41, 
                     '6', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (215, 41, 
                     '2', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (216, 41, 
                     '1', 'T09',
                     'repair_date', '2024-08-10', '2024-08-29',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (217, 41, 
                     '22', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (218, 41, 
                     '1', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (219, 42, 
                     '12', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (220, 42, 
                     '9', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (221, 42, 
                     '1', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (222, 42, 
                     '5', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (223, 42, 
                     '10', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (224, 42, 
                     '27', 'T08',
                     'TL_date', '2024-03-10', '2023-12-17',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (225, 42, 
                     '21', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (226, 43, 
                     '27', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (227, 43, 
                     '30', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (228, 43, 
                     '21', 'T08',
                     'tank_life', '1.66', '1.75',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (229, 44, 
                     '23', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (230, 44, 
                     '17', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (231, 44, 
                     '3', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (232, 44, 
                     '12', 'T10',
                     'TL_LT', '2.27', '4.33',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (233, 44, 
                     '3', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (234, 45, 
                     '12', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (235, 45, 
                     '6', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (236, 45, 
                     '2', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (237, 45, 
                     '5', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (238, 45, 
                     '15', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (239, 45, 
                     '3', 'T08',
                     'RTL_date', '2024-06-05', '2023-12-12',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (240, 45, 
                     '3', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (241, 46, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (242, 46, 
                     '9', 'T07',
                     'repair_LT', '2.52', '4.58',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (243, 46, 
                     '3', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (244, 47, 
                     '14', 'T04',
                     'RTL_LT', '1.69', '1.44',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (245, 47, 
                     '20', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (246, 47, 
                     '3', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (247, 47, 
                     '22', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (248, 48, 
                     '14', 'T08',
                     'TL_date', '2024-05-01', '2023-12-03',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (249, 48, 
                     '18', 'T02',
                     'tank_life', '2.21', '1.9',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (250, 48, 
                     '15', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (251, 48, 
                     '16', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (252, 48, 
                     '11', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (253, 49, 
                     '5', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (254, 49, 
                     '7', 'T05',
                     'repair_LT', '4.33', '1.6',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (255, 49, 
                     '2', 'T08',
                     'cold_idle', '1.01', '4.91',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (256, 49, 
                     '1', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (257, 49, 
                     '22', 'T02',
                     'repair_LT', '2.31', '4.23',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (258, 49, 
                     '18', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (259, 49, 
                     '4', 'T05',
                     'TL_LT', '2.3', '3.21',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (260, 49, 
                     '18', 'T09',
                     'GG_date', '2024-06-14', '2024-07-10',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (261, 50, 
                     '24', 'T08',
                     'GG_date', '2024-05-19', '2024-02-24',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (262, 50, 
                     '11', 'T01',
                     'drain_date', '2023-12-12', '2023-12-15',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (263, 50, 
                     '3', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (264, 50, 
                     '23', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (265, 50, 
                     '17', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (266, 50, 
                     '9', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (267, 50, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (268, 51, 
                     '8', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (269, 51, 
                     '19', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (270, 51, 
                     '23', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (271, 51, 
                     '16', 'T04',
                     'RTL_date', '2023-12-30', '2024-08-25',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (272, 51, 
                     '15', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (273, 51, 
                     '14', 'T07',
                     'drain_date', '2024-06-21', '2024-06-21',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (274, 51, 
                     '24', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (275, 52, 
                     '22', 'T10',
                     'GG_date', '2024-09-29', '2024-05-30',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (276, 52, 
                     '13', 'T06',
                     'TL_date', '2023-12-15', '2023-12-25',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (277, 52, 
                     '12', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (278, 52, 
                     '1', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (279, 53, 
                     '25', 'T05',
                     'repair_LT', '2.51', '2.03',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (280, 53, 
                     '18', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (281, 53, 
                     '7', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (282, 53, 
                     '21', 'T07',
                     'TL_LT', '3.39', '4.05',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (283, 53, 
                     '18', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (284, 53, 
                     '6', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (285, 53, 
                     '2', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (286, 53, 
                     '21', 'T07',
                     'repair_LT', '3.78', '1.92',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (287, 54, 
                     '15', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (288, 54, 
                     '15', 'T06',
                     'RTL_date', '2024-08-10', '2024-10-16',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (289, 54, 
                     '18', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (290, 54, 
                     '20', 'T09',
                     'repair_LT', '4.49', '2.73',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (291, 54, 
                     '20', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (292, 54, 
                     '12', 'T02',
                     'cold_idle', '1.09', '3.58',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (293, 54, 
                     '10', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (294, 55, 
                     '22', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (295, 55, 
                     '13', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (296, 55, 
                     '21', 'T08',
                     'GG_date', '2024-05-11', '2024-07-31',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (297, 55, 
                     '3', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (298, 55, 
                     '16', 'T08',
                     'GG_date', '2024-07-25', '2024-03-20',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (299, 55, 
                     '10', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (300, 56, 
                     '13', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (301, 56, 
                     '22', 'T06',
                     'cold_idle', '4.16', '3.08',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (302, 56, 
                     '20', 'T08',
                     'GG_date', '2024-09-15', '2024-10-13',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (303, 57, 
                     '8', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (304, 57, 
                     '1', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (305, 57, 
                     '9', 'T03',
                     'cold_idle', '1.48', '2.43',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (306, 58, 
                     '6', 'T02',
                     'RTL_date', '2024-05-10', '2024-09-02',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (307, 58, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (308, 58, 
                     '22', 'T07',
                     'RTL_LT', '1.54', '3.03',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (309, 59, 
                     '7', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (310, 59, 
                     '9', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (311, 59, 
                     '13', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (312, 59, 
                     '16', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (313, 60, 
                     '25', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (314, 60, 
                     '27', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (315, 60, 
                     '7', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (316, 60, 
                     '7', 'T08',
                     'tank_life', '3.79', '2.78',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (317, 60, 
                     '14', 'T09',
                     'GG_date', '2024-02-06', '2024-07-27',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (318, 60, 
                     '21', 'T09',
                     'repair_date', '2024-06-19', '2024-09-02',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (319, 60, 
                     '24', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (320, 60, 
                     '29', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (321, 61, 
                     '4', 'T04',
                     'cold_idle', '1.67', '3.81',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (322, 61, 
                     '24', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (323, 61, 
                     '13', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (324, 62, 
                     '22', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (325, 62, 
                     '11', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (326, 62, 
                     '12', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (327, 63, 
                     '23', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (328, 63, 
                     '10', 'T07',
                     'repair_date', '2024-07-13', '2024-03-16',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (329, 63, 
                     '11', 'T04',
                     'TL_date', '2024-06-08', '2024-04-25',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (330, 63, 
                     '1', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (331, 63, 
                     '11', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (332, 64, 
                     '16', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (333, 64, 
                     '6', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (334, 64, 
                     '3', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (335, 64, 
                     '16', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (336, 64, 
                     '22', 'T04',
                     'GG_date', '2024-08-20', '2024-01-16',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (337, 64, 
                     '1', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (338, 65, 
                     '11', 'T10',
                     'repair_date', '2024-02-27', '2024-06-30',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (339, 65, 
                     '6', 'T08',
                     'repair_LT', '1.35', '1.45',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (340, 65, 
                     '6', 'T08',
                     'tank_life', '3.75', '2.46',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (341, 65, 
                     '26', 'T08',
                     'RTL_LT', '2.23', '1.68',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (342, 65, 
                     '15', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (343, 66, 
                     '23', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (344, 66, 
                     '25', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (345, 66, 
                     '12', 'T04',
                     'tank_life', '4.21', '1.64',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (346, 66, 
                     '17', 'T01',
                     'GG_date', '2024-08-09', '2024-05-23',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (347, 66, 
                     '21', 'T08',
                     'TL_LT', '3.94', '2.98',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (348, 67, 
                     '13', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (349, 67, 
                     '21', 'T09',
                     'drain_date', '2023-12-17', '2024-02-19',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (350, 67, 
                     '11', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (351, 68, 
                     '16', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (352, 68, 
                     '3', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (353, 68, 
                     '8', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (354, 68, 
                     '11', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (355, 68, 
                     '10', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (356, 68, 
                     '8', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (357, 68, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (358, 68, 
                     '6', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (359, 69, 
                     '8', 'T07',
                     'TL_LT', '1.65', '4.96',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (360, 69, 
                     '15', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (361, 69, 
                     '8', 'T07',
                     'cold_idle', '3.01', '4.41',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (362, 69, 
                     '19', 'T02',
                     'repair_date', '2024-02-27', '2024-10-11',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (363, 70, 
                     '24', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (364, 70, 
                     '18', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (365, 70, 
                     '16', 'T02',
                     'RTL_LT', '3.74', '2.65',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (366, 71, 
                     '13', 'T03',
                     'TL_date', '2024-07-01', '2023-12-15',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (367, 71, 
                     '15', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (368, 71, 
                     '14', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (369, 71, 
                     '23', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (370, 71, 
                     '22', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (371, 72, 
                     '22', 'T03',
                     'GG_date', '2024-08-26', '2024-04-12',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (372, 72, 
                     '28', 'T10',
                     'tank_life', '3.63', '4.69',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (373, 72, 
                     '26', 'T04',
                     'repair_date', '2023-12-29', '2024-04-22',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (374, 72, 
                     '6', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (375, 72, 
                     '17', 'T04',
                     'RTL_date', '2024-06-08', '2024-03-14',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (376, 72, 
                     '19', 'T02',
                     'RTL_date', '2023-12-12', '2024-06-07',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (377, 72, 
                     '8', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (378, 73, 
                     '18', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (379, 73, 
                     '14', 'T09',
                     'RTL_LT', '1.98', '1.29',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (380, 73, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (381, 73, 
                     '25', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (382, 74, 
                     '5', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (383, 74, 
                     '5', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (384, 74, 
                     '23', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (385, 74, 
                     '7', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (386, 74, 
                     '9', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (387, 74, 
                     '9', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (388, 75, 
                     '4', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (389, 75, 
                     '24', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (390, 75, 
                     '23', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (391, 75, 
                     '2', 'T06',
                     'repair_date', '2024-02-28', '2024-06-25',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (392, 76, 
                     '28', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (393, 76, 
                     '13', 'T03',
                     'RTL_LT', '2.98', '3.87',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (394, 76, 
                     '25', 'T08',
                     'TL_date', '2024-05-13', '2023-12-02',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (395, 76, 
                     '16', 'T02',
                     'repair_LT', '2.23', '2.76',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (396, 76, 
                     '20', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (397, 77, 
                     '4', 'T05',
                     'repair_date', '2024-05-09', '2024-07-22',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (398, 77, 
                     '12', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (399, 77, 
                     '4', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (400, 77, 
                     '9', 'T02',
                     'RTL_LT', '2.43', '4.43',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (401, 77, 
                     '22', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (402, 77, 
                     '25', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (403, 77, 
                     '13', 'T01',
                     'cold_idle', '2.02', '3.03',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (404, 77, 
                     '2', 'T02',
                     'repair_date', '2024-08-24', '2024-04-28',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (405, 78, 
                     '2', 'T10',
                     'drain_date', '2024-01-09', '2024-07-13',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (406, 78, 
                     '5', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (407, 78, 
                     '19', 'T03',
                     'cold_idle', '1.13', '3.48',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (408, 79, 
                     '20', 'T05',
                     'drain_date', '2023-12-27', '2024-06-09',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (409, 79, 
                     '19', 'T01',
                     'GG_date', '2024-06-24', '2023-12-20',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (410, 79, 
                     '2', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (411, 79, 
                     '3', 'T02',
                     'TL_LT', '2.17', '3.4',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (412, 80, 
                     '7', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (413, 80, 
                     '10', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (414, 80, 
                     '13', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (415, 80, 
                     '13', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (416, 81, 
                     '19', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (417, 81, 
                     '11', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (418, 81, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (419, 82, 
                     '7', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (420, 82, 
                     '23', 'T10',
                     'TL_date', '2024-04-11', '2024-08-25',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (421, 82, 
                     '11', 'T07',
                     'TL_date', '2024-09-06', '2024-05-08',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (422, 82, 
                     '7', 'T06',
                     'TL_LT', '4.65', '3.95',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (423, 82, 
                     '17', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (424, 83, 
                     '19', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (425, 83, 
                     '5', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (426, 83, 
                     '10', 'T03',
                     'drain_date', '2024-05-17', '2024-08-13',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (427, 83, 
                     '5', 'T08',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (428, 83, 
                     '20', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (429, 84, 
                     '21', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (430, 84, 
                     '9', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (431, 84, 
                     '22', 'T05',
                     'TL_date', '2024-07-08', '2024-05-27',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (432, 84, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (433, 84, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (434, 84, 
                     '16', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (435, 85, 
                     '9', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (436, 85, 
                     '4', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (437, 85, 
                     '19', 'T03',
                     'RTL_date', '2024-03-30', '2024-01-17',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (438, 85, 
                     '7', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (439, 85, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (440, 85, 
                     '21', 'T04',
                     'drain_date', '2024-04-20', '2024-09-23',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (441, 85, 
                     '10', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (442, 86, 
                     '13', 'T09',
                     'tank_life', '1.02', '4.25',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (443, 86, 
                     '7', 'T05',
                     'drain_date', '2024-04-26', '2024-07-20',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (444, 86, 
                     '23', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (445, 86, 
                     '23', 'T02',
                     'repair_LT', '4.96', '3.33',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (446, 86, 
                     '2', 'T05',
                     'cold_idle', '2.04', '4.78',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (447, 86, 
                     '21', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (448, 86, 
                     '10', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (449, 87, 
                     '13', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (450, 87, 
                     '10', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (451, 87, 
                     '5', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (452, 87, 
                     '23', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (453, 88, 
                     '23', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (454, 88, 
                     '6', 'T09',
                     'RTL_LT', '1.87', '3.67',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (455, 88, 
                     '6', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (456, 88, 
                     '5', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (457, 88, 
                     '15', 'T04',
                     'repair_date', '2024-03-04', '2024-07-24',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (458, 88, 
                     '3', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (459, 88, 
                     '11', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (460, 88, 
                     '9', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (461, 89, 
                     '11', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (462, 89, 
                     '2', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (463, 89, 
                     '4', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (464, 90, 
                     '21', 'T10',
                     'RTL_LT', '3.84', '4.76',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (465, 90, 
                     '22', 'T03',
                     'TL_date', '2024-02-22', '2024-04-08',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (466, 90, 
                     '2', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (467, 90, 
                     '10', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (468, 90, 
                     '29', 'T03',
                     'cold_idle', '1.56', '2.64',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (469, 91, 
                     '6', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (470, 91, 
                     '15', 'T10',
                     'TL_date', '2024-09-29', '2024-08-20',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (471, 91, 
                     '25', 'T09',
                     'tank_life', '1.32', '2.56',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (472, 91, 
                     '21', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (473, 91, 
                     '14', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (474, 92, 
                     '20', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (475, 92, 
                     '3', 'T10',
                     'RTL_LT', '4.99', '3.14',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (476, 92, 
                     '6', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (477, 92, 
                     '1', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (478, 92, 
                     '16', 'T05',
                     'drain_date', '2024-07-06', '2023-12-22',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (479, 93, 
                     '5', 'T01',
                     'RTL_LT', '3.93', '3.71',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (480, 93, 
                     '18', 'T06',
                     'TL_LT', '3.39', '4.08',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (481, 93, 
                     '24', 'T06',
                     'GG_date', '2024-02-21', '2024-06-18',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (482, 93, 
                     '4', 'T07',
                     'RTL_date', '2024-04-10', '2024-05-15',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (483, 93, 
                     '1', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (484, 94, 
                     '20', 'T07',
                     'RTL_LT', '4.38', '1.06',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (485, 94, 
                     '3', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (486, 94, 
                     '15', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (487, 94, 
                     '2', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (488, 94, 
                     '15', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (489, 94, 
                     '10', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (490, 94, 
                     '16', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (491, 94, 
                     '10', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (492, 95, 
                     '4', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (493, 95, 
                     '2', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (494, 95, 
                     '16', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (495, 95, 
                     '10', 'T08',
                     'RTL_LT', '3.13', '4.57',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (496, 96, 
                     '6', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (497, 96, 
                     '20', 'T05',
                     'repair_LT', '3.76', '1.94',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (498, 96, 
                     '4', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (499, 96, 
                     '11', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (500, 97, 
                     '21', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (501, 97, 
                     '29', 'T07',
                     'TL_LT', '3.88', '1.33',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (502, 97, 
                     '10', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (503, 98, 
                     '1', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (504, 98, 
                     '4', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (505, 98, 
                     '9', 'T06',
                     'TL_date', '2024-01-07', '2024-06-05',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (506, 98, 
                     '15', 'T08',
                     'cold_idle', '4.86', '3.38',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (507, 98, 
                     '7', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (508, 98, 
                     '4', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (509, 98, 
                     '5', 'T05',
                     'RTL_date', '2024-06-04', '2024-03-26',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (510, 98, 
                     '23', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (511, 99, 
                     '23', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (512, 99, 
                     '8', 'T08',
                     'repair_date', '2024-08-08', '2024-05-04',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (513, 99, 
                     '20', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (514, 99, 
                     '8', 'T08',
                     'cold_idle', '2.54', '3.99',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (515, 99, 
                     '9', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (516, 99, 
                     '21', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (517, 99, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (518, 100, 
                     '11', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (519, 100, 
                     '9', 'T02',
                     'RTL_LT', '2.0', '3.14',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (520, 100, 
                     '13', 'T08',
                     'TL_date', '2023-12-16', '2024-04-02',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (521, 101, 
                     '10', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (522, 101, 
                     '3', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (523, 101, 
                     '12', 'T04',
                     'repair_LT', '1.31', '2.41',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (524, 101, 
                     '1', 'T03',
                     'drain_date', '2024-09-28', '2024-01-27',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (525, 101, 
                     '18', 'T05',
                     'TL_date', '2024-10-26', '2024-07-01',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (526, 102, 
                     '19', 'T02',
                     'GG_date', '2024-06-02', '2024-10-13',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (527, 102, 
                     '14', 'T05',
                     'repair_LT', '2.7', '1.59',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (528, 102, 
                     '2', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (529, 102, 
                     '12', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (530, 102, 
                     '23', 'T01',
                     'tank_life', '1.06', '2.69',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (531, 102, 
                     '16', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (532, 102, 
                     '7', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (533, 103, 
                     '21', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (534, 103, 
                     '16', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (535, 103, 
                     '26', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (536, 103, 
                     '6', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (537, 103, 
                     '28', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (538, 103, 
                     '5', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (539, 103, 
                     '10', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (540, 104, 
                     '21', 'T06',
                     'TL_date', '2024-01-14', '2024-04-02',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (541, 104, 
                     '2', 'T05',
                     'repair_date', '2024-06-18', '2024-10-02',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (542, 104, 
                     '1', 'T09',
                     'GG_date', '2024-01-01', '2024-03-03',
                     'UPDATE', 'Tom');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (543, 105, 
                     '17', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (544, 105, 
                     '11', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (545, 105, 
                     '22', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (546, 106, 
                     '15', 'T09',
                     'drain_date', '2024-02-21', '2024-04-26',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (547, 106, 
                     '9', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (548, 106, 
                     '5', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (549, 106, 
                     '18', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (550, 106, 
                     '17', 'T08',
                     'repair_date', '2024-03-21', '2024-02-06',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (551, 106, 
                     '8', 'T06',
                     'repair_date', '2024-09-08', '2024-08-02',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (552, 107, 
                     '15', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (553, 107, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (554, 107, 
                     '23', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (555, 107, 
                     '2', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (556, 107, 
                     '15', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (557, 107, 
                     '6', 'T10',
                     'GG_date', '2024-07-08', '2024-01-03',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (558, 107, 
                     '24', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (559, 107, 
                     '17', 'T06',
                     'repair_date', '2024-02-03', '2024-03-07',
                     'UPDATE', 'David');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (560, 108, 
                     '19', 'T07',
                     'TL_date', '2024-04-19', '2024-02-15',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (561, 108, 
                     '21', 'T01',
                     'RTL_LT', '3.79', '2.67',
                     'UPDATE', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (562, 108, 
                     '5', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (563, 108, 
                     '15', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (564, 108, 
                     '7', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (565, 108, 
                     '8', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (566, 108, 
                     '3', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (567, 108, 
                     '10', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Sarah');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (568, 109, 
                     '1', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (569, 109, 
                     '10', 'T09',
                     'RTL_date', '2024-10-11', '2024-03-10',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (570, 109, 
                     '6', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (571, 109, 
                     '21', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (572, 109, 
                     '5', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (573, 109, 
                     '7', 'T10',
                     'drain_date', '2024-02-11', '2024-04-16',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (574, 110, 
                     '16', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (575, 110, 
                     '21', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (576, 110, 
                     '18', 'T09',
                     'repair_date', '2024-07-12', '2023-12-17',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (577, 110, 
                     '25', 'T10',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (578, 110, 
                     '22', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (579, 110, 
                     '24', 'T09',
                     'RTL_LT', '3.35', '4.16',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (580, 110, 
                     '22', 'T05',
                     'repair_LT', '1.77', '4.53',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (581, 110, 
                     '19', 'T08',
                     'tank_life', '3.54', '2.43',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (582, 111, 
                     '29', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (583, 111, 
                     '3', 'T05',
                     'drain_date', '2024-07-05', '2024-04-15',
                     'UPDATE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (584, 111, 
                     '3', 'T05',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mike');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (585, 112, 
                     '18', 'T10',
                     'repair_LT', '1.12', '3.5',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (586, 112, 
                     '20', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (587, 112, 
                     '13', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (588, 112, 
                     '9', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (589, 112, 
                     '14', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (590, 112, 
                     '11', 'T03',
                     'ALL', NULL, NULL,
                     'INSERT', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (591, 112, 
                     '13', 'T06',
                     'repair_date', '2024-01-12', '2024-05-08',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (592, 112, 
                     '16', 'T09',
                     'TL_LT', '1.66', '3.56',
                     'UPDATE', 'Mary');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (593, 113, 
                     '28', 'T03',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (594, 113, 
                     '7', 'T02',
                     'drain_date', '2024-04-03', '2024-07-31',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (595, 113, 
                     '11', 'T01',
                     'RTL_LT', '4.45', '2.0',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (596, 113, 
                     '21', 'T08',
                     'repair_date', '2024-05-09', '2023-12-28',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (597, 113, 
                     '12', 'T07',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (598, 113, 
                     '9', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (599, 114, 
                     '12', 'T08',
                     'TL_LT', '4.14', '3.82',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (600, 114, 
                     '9', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (601, 114, 
                     '9', 'T01',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (602, 114, 
                     '16', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (603, 114, 
                     '15', 'T09',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (604, 114, 
                     '7', 'T09',
                     'tank_life', '2.6', '4.91',
                     'UPDATE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (605, 114, 
                     '12', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (606, 114, 
                     '1', 'T10',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (607, 115, 
                     '15', 'T02',
                     'GG_date', '2024-08-17', '2024-07-29',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (608, 115, 
                     '3', 'T10',
                     'TL_date', '2024-05-30', '2024-08-25',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (609, 115, 
                     '16', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (610, 115, 
                     '21', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (611, 115, 
                     '3', 'T10',
                     'repair_LT', '3.97', '3.11',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (612, 115, 
                     '16', 'T07',
                     'RTL_LT', '1.47', '2.99',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (613, 116, 
                     '6', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (614, 116, 
                     '17', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (615, 116, 
                     '18', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Alice');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (616, 117, 
                     '17', 'T06',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (617, 117, 
                     '6', 'T10',
                     'GG_date', '2024-09-24', '2024-06-25',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (618, 117, 
                     '27', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (619, 117, 
                     '18', 'T04',
                     'ALL', NULL, NULL,
                     'INSERT', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (620, 117, 
                     '22', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (621, 117, 
                     '5', 'T01',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (622, 118, 
                     '19', 'T05',
                     'RTL_LT', '4.53', '4.04',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (623, 118, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (624, 118, 
                     '8', 'T08',
                     'TL_date', '2023-12-08', '2024-02-02',
                     'UPDATE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (625, 118, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Bob');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (626, 119, 
                     '18', 'T07',
                     'tank_life', '3.45', '1.52',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (627, 119, 
                     '5', 'T08',
                     'ALL', NULL, NULL,
                     'INSERT', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (628, 119, 
                     '14', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (629, 119, 
                     '30', 'T09',
                     'RTL_LT', '3.8', '2.69',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (630, 119, 
                     '25', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (631, 119, 
                     '20', 'T06',
                     'tank_life', '3.41', '4.29',
                     'UPDATE', 'Emma');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (632, 120, 
                     '14', 'T10',
                     'repair_LT', '1.59', '4.4',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (633, 120, 
                     '26', 'T07',
                     'RTL_date', '2024-02-29', '2024-07-16',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (634, 120, 
                     '1', 'T04',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (635, 120, 
                     '16', 'T07',
                     'tank_life', '2.26', '1.27',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (636, 120, 
                     '17', 'T08',
                     'cold_idle', '3.78', '3.95',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (637, 120, 
                     '11', 'T04',
                     'tank_life', '1.49', '1.79',
                     'UPDATE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (638, 120, 
                     '23', 'T02',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (639, 120, 
                     '10', 'T07',
                     'ALL', NULL, NULL,
                     'DELETE', 'Kate');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (640, 121, 
                     '28', 'T05',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (641, 121, 
                     '20', 'T08',
                     'repair_LT', '1.54', '2.23',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (642, 121, 
                     '29', 'T06',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (643, 121, 
                     '3', 'T02',
                     'ALL', NULL, NULL,
                     'INSERT', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (644, 121, 
                     '21', 'T02',
                     'RTL_LT', '2.71', '4.29',
                     'UPDATE', 'John');
INSERT INTO app_tank_plan_history 
                    (history_id, plan_master_id, plan_row_id, tank, 
                     field_name, old_value, new_value, change_type, user_name)
                    VALUES
                    (645, 121, 
                     '27', 'T09',
                     'ALL', NULL, NULL,
                     'DELETE', 'John');
