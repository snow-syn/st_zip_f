-- Tank Plan Master Test Data
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (1, '2023-11-29', 
                     'Weekly', '18MP', 
                     1, NULL, 
                     '202311', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (2, '2023-11-30', 
                     'Long-term', '', 
                     1, NULL, 
                     '202311', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (3, '2023-12-06', 
                     'Weekly', '18MP', 
                     1, 1, 
                     '202312', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (4, '2023-12-06', 
                     'Weekly', '18MP', 
                     2, 1, 
                     '202312', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (5, '2023-12-13', 
                     'Weekly', '', 
                     1, 4, 
                     '202312', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (6, '2023-12-20', 
                     'Weekly', '', 
                     1, 5, 
                     '202312', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (7, '2023-12-20', 
                     'Weekly', '', 
                     2, 5, 
                     '202312', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (8, '2023-12-27', 
                     'Weekly', '', 
                     1, 7, 
                     '202312', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (9, '2023-12-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202312', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (10, '2023-12-31', 
                     'Long-term', '', 
                     2, NULL, 
                     '202312', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (11, '2023-12-31', 
                     'Long-term', '', 
                     3, NULL, 
                     '202312', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (12, '2024-01-03', 
                     'Weekly', '', 
                     1, 8, 
                     '202401', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (13, '2024-01-10', 
                     'Weekly', '', 
                     1, 12, 
                     '202401', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (14, '2024-01-10', 
                     'Weekly', '', 
                     2, 12, 
                     '202401', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (15, '2024-01-17', 
                     'Weekly', '', 
                     1, 14, 
                     '202401', 'John');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (16, '2024-01-24', 
                     'Weekly', '18MP', 
                     1, 15, 
                     '202401', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (17, '2024-01-24', 
                     'Weekly', '18MP', 
                     2, 15, 
                     '202401', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (18, '2024-01-24', 
                     'Weekly', '18MP', 
                     3, 15, 
                     '202401', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (19, '2024-01-31', 
                     'Weekly', '', 
                     1, 18, 
                     '202401', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (20, '2024-01-31', 
                     'Weekly', '', 
                     2, 18, 
                     '202401', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (21, '2024-01-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202401', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (22, '2024-01-31', 
                     'Long-term', '', 
                     2, NULL, 
                     '202401', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (23, '2024-01-31', 
                     'Long-term', '', 
                     3, NULL, 
                     '202401', 'John');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (24, '2024-02-07', 
                     'Weekly', '18MP', 
                     1, 20, 
                     '202402', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (25, '2024-02-07', 
                     'Weekly', '18MP', 
                     2, 20, 
                     '202402', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (26, '2024-02-14', 
                     'Weekly', '', 
                     1, 25, 
                     '202402', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (27, '2024-02-14', 
                     'Weekly', '', 
                     2, 25, 
                     '202402', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (28, '2024-02-21', 
                     'Weekly', '', 
                     1, 27, 
                     '202402', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (29, '2024-02-28', 
                     'Weekly', '', 
                     1, 28, 
                     '202402', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (30, '2024-02-29', 
                     'Long-term', '', 
                     1, NULL, 
                     '202402', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (31, '2024-02-29', 
                     'Long-term', '', 
                     2, NULL, 
                     '202402', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (32, '2024-03-06', 
                     'Weekly', '', 
                     1, 29, 
                     '202403', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (33, '2024-03-06', 
                     'Weekly', '', 
                     2, 29, 
                     '202403', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (34, '2024-03-06', 
                     'Weekly', '', 
                     3, 29, 
                     '202403', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (35, '2024-03-13', 
                     'Weekly', '', 
                     1, 34, 
                     '202403', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (36, '2024-03-20', 
                     'Weekly', '', 
                     1, 35, 
                     '202403', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (37, '2024-03-27', 
                     'Weekly', '18MP', 
                     1, 36, 
                     '202403', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (38, '2024-03-27', 
                     'Weekly', '18MP', 
                     2, 36, 
                     '202403', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (39, '2024-03-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202403', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (40, '2024-03-31', 
                     'Long-term', '', 
                     2, NULL, 
                     '202403', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (41, '2024-04-03', 
                     'Weekly', '', 
                     1, 38, 
                     '202404', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (42, '2024-04-03', 
                     'Weekly', '', 
                     2, 38, 
                     '202404', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (43, '2024-04-03', 
                     'Weekly', '', 
                     3, 38, 
                     '202404', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (44, '2024-04-10', 
                     'Weekly', '', 
                     1, 43, 
                     '202404', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (45, '2024-04-10', 
                     'Weekly', '', 
                     2, 43, 
                     '202404', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (46, '2024-04-17', 
                     'Weekly', '', 
                     1, 45, 
                     '202404', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (47, '2024-04-24', 
                     'Weekly', '18MP', 
                     1, 46, 
                     '202404', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (48, '2024-04-24', 
                     'Weekly', '18MP', 
                     2, 46, 
                     '202404', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (49, '2024-04-30', 
                     'Long-term', '', 
                     1, NULL, 
                     '202404', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (50, '2024-05-01', 
                     'Weekly', '', 
                     1, 48, 
                     '202405', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (51, '2024-05-01', 
                     'Weekly', '', 
                     2, 48, 
                     '202405', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (52, '2024-05-01', 
                     'Weekly', '', 
                     3, 48, 
                     '202405', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (53, '2024-05-08', 
                     'Weekly', '', 
                     1, 52, 
                     '202405', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (54, '2024-05-15', 
                     'Weekly', '', 
                     1, 53, 
                     '202405', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (55, '2024-05-15', 
                     'Weekly', '', 
                     2, 53, 
                     '202405', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (56, '2024-05-22', 
                     'Weekly', '18MP', 
                     1, 55, 
                     '202405', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (57, '2024-05-22', 
                     'Weekly', '18MP', 
                     2, 55, 
                     '202405', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (58, '2024-05-22', 
                     'Weekly', '18MP', 
                     3, 55, 
                     '202405', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (59, '2024-05-29', 
                     'Weekly', '', 
                     1, 58, 
                     '202405', 'John');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (60, '2024-05-29', 
                     'Weekly', '', 
                     2, 58, 
                     '202405', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (61, '2024-05-29', 
                     'Weekly', '', 
                     3, 58, 
                     '202405', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (62, '2024-05-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202405', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (63, '2024-05-31', 
                     'Long-term', '', 
                     2, NULL, 
                     '202405', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (64, '2024-06-05', 
                     'Weekly', '', 
                     1, 61, 
                     '202406', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (65, '2024-06-12', 
                     'Weekly', '', 
                     1, 64, 
                     '202406', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (66, '2024-06-19', 
                     'Weekly', '', 
                     1, 65, 
                     '202406', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (67, '2024-06-19', 
                     'Weekly', '', 
                     2, 65, 
                     '202406', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (68, '2024-06-26', 
                     'Weekly', '18MP', 
                     1, 67, 
                     '202406', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (69, '2024-06-26', 
                     'Weekly', '18MP', 
                     2, 67, 
                     '202406', 'John');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (70, '2024-06-30', 
                     'Long-term', '', 
                     1, NULL, 
                     '202406', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (71, '2024-06-30', 
                     'Long-term', '', 
                     2, NULL, 
                     '202406', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (72, '2024-06-30', 
                     'Long-term', '', 
                     3, NULL, 
                     '202406', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (73, '2024-07-03', 
                     'Weekly', '', 
                     1, 69, 
                     '202407', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (74, '2024-07-03', 
                     'Weekly', '', 
                     2, 69, 
                     '202407', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (75, '2024-07-10', 
                     'Weekly', '', 
                     1, 74, 
                     '202407', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (76, '2024-07-10', 
                     'Weekly', '', 
                     2, 74, 
                     '202407', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (77, '2024-07-17', 
                     'Weekly', '18MP', 
                     1, 76, 
                     '202407', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (78, '2024-07-17', 
                     'Weekly', '18MP', 
                     2, 76, 
                     '202407', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (79, '2024-07-17', 
                     'Weekly', '18MP', 
                     3, 76, 
                     '202407', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (80, '2024-07-24', 
                     'Weekly', '', 
                     1, 79, 
                     '202407', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (81, '2024-07-24', 
                     'Weekly', '', 
                     2, 79, 
                     '202407', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (82, '2024-07-31', 
                     'Weekly', '', 
                     1, 81, 
                     '202407', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (83, '2024-07-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202407', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (84, '2024-07-31', 
                     'Long-term', '', 
                     2, NULL, 
                     '202407', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (85, '2024-08-07', 
                     'Weekly', '', 
                     1, 82, 
                     '202408', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (86, '2024-08-07', 
                     'Weekly', '', 
                     2, 82, 
                     '202408', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (87, '2024-08-14', 
                     'Weekly', '', 
                     1, 86, 
                     '202408', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (88, '2024-08-21', 
                     'Weekly', '18MP', 
                     1, 87, 
                     '202408', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (89, '2024-08-28', 
                     'Weekly', '', 
                     1, 88, 
                     '202408', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (90, '2024-08-28', 
                     'Weekly', '', 
                     2, 88, 
                     '202408', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (91, '2024-08-28', 
                     'Weekly', '', 
                     3, 88, 
                     '202408', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (92, '2024-08-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202408', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (93, '2024-09-04', 
                     'Weekly', '', 
                     1, 91, 
                     '202409', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (94, '2024-09-04', 
                     'Weekly', '', 
                     2, 91, 
                     '202409', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (95, '2024-09-04', 
                     'Weekly', '', 
                     3, 91, 
                     '202409', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (96, '2024-09-11', 
                     'Weekly', '', 
                     1, 95, 
                     '202409', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (97, '2024-09-11', 
                     'Weekly', '', 
                     2, 95, 
                     '202409', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (98, '2024-09-11', 
                     'Weekly', '', 
                     3, 95, 
                     '202409', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (99, '2024-09-18', 
                     'Weekly', '', 
                     1, 98, 
                     '202409', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (100, '2024-09-18', 
                     'Weekly', '', 
                     2, 98, 
                     '202409', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (101, '2024-09-25', 
                     'Weekly', '18MP', 
                     1, 100, 
                     '202409', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (102, '2024-09-30', 
                     'Long-term', 'GB', 
                     1, NULL, 
                     '202409', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (103, '2024-09-30', 
                     'Long-term', 'GB', 
                     2, NULL, 
                     '202409', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (104, '2024-09-30', 
                     'Long-term', 'GB', 
                     3, NULL, 
                     '202409', 'Tom');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (105, '2024-10-02', 
                     'Weekly', '18MP', 
                     1, 101, 
                     '202410', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (106, '2024-10-02', 
                     'Weekly', '18MP', 
                     2, 101, 
                     '202410', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (107, '2024-10-09', 
                     'Weekly', '', 
                     1, 106, 
                     '202410', 'David');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (108, '2024-10-16', 
                     'Weekly', '', 
                     1, 107, 
                     '202410', 'Sarah');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (109, '2024-10-16', 
                     'Weekly', '', 
                     2, 107, 
                     '202410', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (110, '2024-10-23', 
                     'Weekly', '', 
                     1, 109, 
                     '202410', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (111, '2024-10-23', 
                     'Weekly', '', 
                     2, 109, 
                     '202410', 'Mike');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (112, '2024-10-23', 
                     'Weekly', '', 
                     3, 109, 
                     '202410', 'Mary');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (113, '2024-10-30', 
                     'Weekly', '', 
                     1, 112, 
                     '202410', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (114, '2024-10-30', 
                     'Weekly', '', 
                     2, 112, 
                     '202410', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (115, '2024-10-31', 
                     'Long-term', '', 
                     1, NULL, 
                     '202410', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (116, '2024-10-31', 
                     'Long-term', '', 
                     2, NULL, 
                     '202410', 'Alice');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (117, '2024-11-06', 
                     'Weekly', '', 
                     1, 114, 
                     '202411', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (118, '2024-11-13', 
                     'Weekly', '', 
                     1, 117, 
                     '202411', 'Bob');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (119, '2024-11-20', 
                     'Weekly', '18MP', 
                     1, 118, 
                     '202411', 'Emma');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (120, '2024-11-20', 
                     'Weekly', '18MP', 
                     2, 118, 
                     '202411', 'Kate');
INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    (121, '2024-11-20', 
                     'Weekly', '18MP', 
                     3, 118, 
                     '202411', 'John');
