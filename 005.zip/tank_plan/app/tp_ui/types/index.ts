export type OperationLogAction =
  | 'Uploaded'
  | 'Created'
  | 'Updated'
  | 'Exported'
  | 'Deleted';
export type ChangeType = 'INSERT' | 'UPDATE' | 'DELETE' | 'all';

export interface OperationLog {
  operation_id: number;
  action: OperationLogAction;
  user_name: string;
  plan_version: string;
  plan_version_no: number;
  create_timestamp: string;
}

export interface HistoryRecord {
  history_id: number;
  change_type: ChangeType;
  tank: string;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  user_name: string;
  plan_version: string;
  create_timestamp: string;
}

export interface BaseTankPlanData {
  plan_row_id: string;
  tank: string;
  iso: string;
  glass_type: string;
  gen: string;
  RT: string;
  RC: string;
  platform: string;
  design_asis: string;
  tank_life: string;
  last_tank_light_date: string;
  drain_date: string;
  repair_date: string;
  RTL_date: string;
  TL_date: string;
  GG_date: string;
  cold_idle: string;
  repair_LT: string;
  RTL_LT: string;
  TL_LT: string;
  remark_category: string;
  remark: string;
  comment: string;
}

export interface TankPlanDetailData extends BaseTankPlanData {
  [key: string]: string;
}

export type PlanType = 'Long-term' | 'Weekly';

export type PlanTag = 'GB' | '18MP' | '';

export interface PlanVersion {
  plan_master_id: number;
  plan_version: string;
  plan_type: PlanType;
  plan_official: PlanTag;
  plan_version_no: number;
  plan_version_parent: string | null;
  version_match: string;
  create_timestamp: string;
  update_timestamp: string;
  user_name: string;
  row_count?: number;
}

export interface TankPlanDataWithVersion extends BaseTankPlanData {
  plan_master_id: number;
  create_timestamp: string;
  update_timestamp: string;
  user_name: string;
}

export interface VersionNode {
  id: number;
  version: string;
  type: PlanType;
  status: PlanTag;
  versionNo: number;
  parentId: number | null;
  children: VersionNode[];
  metadata: {
    createdAt: string;
    updatedAt: string;
    createdBy: string;
    rowCount: number;
    hasChanges: boolean;
  };
}

export interface VersionTree {
  nodes: VersionNode[];
  rootIds: number[];
}

export interface VersionDiff {
  sourceVersion: PlanVersion;
  targetVersion: PlanVersion;
  changes: {
    added: TankPlanDetailData[];
    modified: Array<{
      rowId: string;
      tank: string;
      field: keyof TankPlanDetailData;
      oldValue: string;
      newValue: string;
    }>;
    deleted: TankPlanDetailData[];
  };
  stats: {
    totalChanges: number;
    addedCount: number;
    modifiedCount: number;
    deletedCount: number;
  };
}

export interface PlanFilter {
  type?: PlanType[];
  status?: PlanTag[];
  dateRange?: {
    start: string;
    end: string;
  };
  user?: string[];
  search?: string;
}

export interface PlanListResult {
  versions: PlanVersion[];
  total: number;
  pageSize: number;
  currentPage: number;
  filters: PlanFilter;
}

export interface VersionOperationResult {
  success: boolean;
  message?: string;
  version?: PlanVersion;
  error?: {
    code: string;
    details: string;
  };
}

export type VersionRelationType = 'parent' | 'child' | 'branch' | 'merge';

export interface VersionRelation {
  sourceId: number;
  targetId: number;
  type: VersionRelationType;
  createdAt: string;
  metadata?: Record<string, unknown>;
}

export interface VersionChangeLog {
  id: number;
  versionId: number;
  action: 'create' | 'update' | 'status_change' | 'merge' | 'branch';
  timestamp: string;
  user: string;
  details: {
    field?: string;
    oldValue?: string;
    newValue?: string;
    description?: string;
  };
}

export interface DatabricksResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  errors?: string[];
  debug?: {
    queryTime?: number;
    transformTime?: number;
    rowCount?: number;
    timestamp?: string;
    stage?: string;
    details?: unknown;
  };
}

export interface PlanVersionResponse extends DatabricksResponse<PlanVersion[]> {
  debug?: {
    queryTime?: number;
    transformTime?: number;
    rowCount?: number;
    timestamp?: string;
    stage?: string;
    details?: {
      filters?: PlanFilter;
      treeDepth?: number;
      relationCount?: number;
    };
  };
}

export interface ExcelProcessResult {
  data: TankPlanDetailData[];
  errors: string[];
}

export interface RowValidationResult {
  isValid: boolean;
  errors: string[];
}

export interface ExportResult {
  success: boolean;
  fileName?: string;
  error?: Error | string;
  rowCount?: number;
}

export type ValidationStepStatus =
  | 'pending'
  | 'processing'
  | 'success'
  | 'error';

export interface PlanHistoryRecord {
  history_id: number;
  plan_master_id: number;
  plan_row_id: string;
  tank: string;
  field_name: string;
  old_value: string | null;
  new_value: string | null;
  change_type: 'UPDATE' | 'INSERT' | 'DELETE';
  create_timestamp: string;
  user_name: string;
  plan_version?: string;
  plan_type?: string;
}

export interface HistoryChange {
  field_name: string;
  old_value: string | null;
  new_value: string | null;
}

export interface HistoryGroup {
  plan_master_id: number;
  plan_row_id: string;
  tank: string;
  changes: HistoryChange[];
  change_type: 'UPDATE' | 'INSERT' | 'DELETE';
  create_timestamp: string;
  user_name: string;
}
