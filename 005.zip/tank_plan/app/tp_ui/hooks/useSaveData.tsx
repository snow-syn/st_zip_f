import { useState } from 'react';
import type {
  TankPlanDetailData,
  PlanType,
  PlanHistoryRecord,
} from '@/app/tp_ui/types';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/app/tp_ui/utils/logger';
import DatabaseService from '@/app/tp_ui/services/DatabaseService';

interface SaveDataOptions {
  parentId?: string | null;
  versionNo?: number;
}

export function useSaveData() {
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const { toast } = useToast();

  const saveData = async (
    data: TankPlanDetailData[],
    planType: PlanType,
    options?: SaveDataOptions,
  ): Promise<boolean> => {
    const context = {
      module: 'useSaveData',
      function: 'saveData',
      requestId: `save-${Date.now()}`,
    };

    try {
      logger.group('Starting save operation', context);
      setIsSaving(true);

      const currentDate = new Date();
      const planVersion = currentDate.toISOString().split('T')[0];
      const versionMatch = currentDate
        .toISOString()
        .substring(0, 7)
        .replace('-', '');

      // 构建 master 记录
      const masterInsertQuery = {
        sql: `
          INSERT INTO app_tank_plan_master (
            plan_version,
            plan_type,
            plan_official,
            plan_version_no,
            plan_version_parent,
            version_match,
            user_name
          ) 
          VALUES (?, ?, '', ?, ?, ?, 'system');
        `,
        params: [
          planVersion,
          planType,
          options?.versionNo || 1,
          options?.parentId || null,
          versionMatch,
        ],
      };

      logger.debug('Executing master insert query', context, {
        sql: masterInsertQuery.sql,
        params: masterInsertQuery.params,
      });

      const masterResponse = await DatabaseService.executeSQLQuery(
        masterInsertQuery.sql,
        masterInsertQuery.params,
      );

      if (masterResponse.status.state !== 'SUCCEEDED') {
        throw new Error('Failed to insert master record');
      }

      const planMasterId = masterResponse.result?.data_array?.[0]?.[1];

      // 构建 detail 记录
      const detailInsertValues = data
        .map((row) => [
          planMasterId,
          row.plan_row_id,
          row.tank,
          row.iso,
          row.glass_type,
          row.gen,
          row.RT,
          row.RC,
          row.platform,
          row.design_asis,
          row.tank_life,
          row.last_tank_light_date,
          row.drain_date,
          row.repair_date,
          row.RTL_date,
          row.TL_date,
          row.GG_date,
          row.cold_idle,
          row.repair_LT,
          row.RTL_LT,
          row.TL_LT,
          row.remark_category,
          row.remark,
          row.comment,
          'system',
        ])
        .flat();

      const detailInsertQuery = {
        sql: `
          INSERT INTO app_tank_plan_detail (
            plan_master_id, plan_row_id, tank, iso, glass_type,
            gen, RT, RC, platform, design_asis, tank_life,
            last_tank_light_date, drain_date, repair_date, RTL_date,
            TL_date, GG_date, cold_idle, repair_LT, RTL_LT,
            TL_LT, remark_category, remark, comment, user_name
          )
          VALUES ${data.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(',')};
        `,
        params: detailInsertValues,
      };

      const detailResponse = await DatabaseService.executeSQLQuery(
        detailInsertQuery.sql,
        detailInsertQuery.params,
      );

      if (detailResponse.status.state !== 'SUCCEEDED') {
        throw new Error('Failed to insert detail records');
      }

      // 记录操作日志
      const action =
        planType === 'Long-term'
          ? options?.versionNo === 1
            ? 'Uploaded'
            : 'Updated'
          : options?.versionNo === 1
            ? 'Created'
            : 'Updated';

      await DatabaseService.saveOperationLog(
        planMasterId,
        action,
        'system',
        `${planType} plan saved with ${data.length} rows`,
      );

      logger.debug('Save operation completed', context, {
        planMasterId,
        rowCount: data.length,
      });

      // 如果有parentId，说明是基于现有版本的修改，需要获取原版本数据进行比较
      if (options?.parentId) {
        const parentData = await DatabaseService.getVersionData(
          Number(options.parentId),
        );

        if (parentData.success && parentData.data) {
          const parentDataMap = new Map(
            parentData.data.map((row) => [row.plan_row_id, row]),
          );

          // 收集需要记录的历史变更
          const historyRecords: PlanHistoryRecord[] = [];
          const columnsToCompare = [
            'tank',
            'iso',
            'glass_type',
            'gen',
            'RT',
            'RC',
            'platform',
            'design_asis',
            'tank_life',
            'last_tank_light_date',
            'drain_date',
            'repair_date',
            'RTL_date',
            'TL_date',
            'GG_date',
            'cold_idle',
            'repair_LT',
            'RTL_LT',
            'TL_LT',
            'remark_category',
            'remark',
            'comment',
          ];

          // 修改比较函数的实现
          const compareValues = (
            oldValue: string | null,
            newValue: string | null,
          ): boolean => {
            // 将 undefined、null、空字符串统一处理
            const normalizeValue = (value: string | null) => {
              if (value === undefined || value === null) {
                return '';
              }
              return value.trim();
            };

            const normalizedOld = normalizeValue(oldValue);
            const normalizedNew = normalizeValue(newValue);

            // 直接比较标准化后的值
            return normalizedOld !== normalizedNew;
          };

          // 处理新增和修改的记录
          data.forEach((newRow) => {
            const oldRow = parentDataMap.get(newRow.plan_row_id);

            if (!oldRow) {
              // 新增记录
              historyRecords.push({
                plan_master_id: planMasterId,
                plan_row_id: newRow.plan_row_id,
                tank: newRow.tank,
                field_name: 'ALL',
                old_value: null,
                new_value: JSON.stringify(newRow),
                change_type: 'INSERT',
                user_name: 'system',
              });
            } else {
              // 修改字段比较部分
              columnsToCompare.forEach((field) => {
                const oldValue = oldRow[field as keyof TankPlanDetailData];
                const newValue = newRow[field as keyof TankPlanDetailData];

                if (compareValues(oldValue, newValue)) {
                  historyRecords.push({
                    plan_master_id: planMasterId,
                    plan_row_id: newRow.plan_row_id,
                    tank: newRow.tank,
                    field_name: field,
                    old_value: oldValue || null,
                    new_value: newValue || null,
                    change_type: 'UPDATE',
                    user_name: 'system',
                  });
                }
              });
            }
          });

          // 处理删除的记录
          parentData.data.forEach((oldRow) => {
            if (!data.find((row) => row.plan_row_id === oldRow.plan_row_id)) {
              historyRecords.push({
                plan_master_id: planMasterId,
                plan_row_id: oldRow.plan_row_id,
                tank: oldRow.tank,
                field_name: 'ALL',
                old_value: JSON.stringify(oldRow),
                new_value: null,
                change_type: 'DELETE',
                user_name: 'system',
              });
            }
          });

          // 保存历史记录
          if (historyRecords.length > 0) {
            logger.debug('Saving history records', context, {
              recordCount: historyRecords.length,
              sampleRecord: historyRecords[0],
            });

            const historyResult =
              await DatabaseService.saveHistoryRecords(historyRecords);

            if (!historyResult.success) {
              logger.error('Failed to save history records', context, {
                error: historyResult.error,
              });
            }
          }
        }
      }

      return true;
    } catch (error) {
      logger.error('Save operation failed', context, {
        error,
        message: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
        data: {
          rowCount: data.length,
          sampleRow: data[0],
        },
      });

      setErrors([
        error instanceof Error ? error.message : 'Failed to save data',
      ]);
      return false;
    } finally {
      setIsSaving(false);
      logger.groupEnd();
    }
  };

  return {
    saveData,
    isSaving,
    errors,
  } as const;
}
