import { useState } from 'react';
import type { PlanVersion } from '../types';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';

interface UseVersionInfoOptions {
  loadParentInfo?: boolean;
  onError?: (error: string) => void;
}

export function useVersionInfo(options?: UseVersionInfoOptions) {
  const [versionInfo, setVersionInfo] = useState<PlanVersion | null>(null);
  const [parentInfo, setParentInfo] = useState<PlanVersion | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const loadVersionInfo = async (id: string | number) => {
    const context = {
      module: 'useVersionInfo',
      function: 'loadVersionInfo',
      versionId: id,
    };

    try {
      logger.group('Loading version info', context);
      setIsLoading(true);

      const result = await DatabaseService.getVersionInfo(Number(id));

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load version info');
      }

      setVersionInfo(result.data);

      if (options?.loadParentInfo && result.data.plan_version_parent) {
        const parentResult = await DatabaseService.getVersionInfo(
          Number(result.data.plan_version_parent),
        );
        if (parentResult.success && parentResult.data) {
          setParentInfo(parentResult.data);
        }
      }

      return result.data;
    } catch (error) {
      logger.error('Failed to load version info', context, { error });
      const errorMessage =
        error instanceof Error ? error.message : 'Failed to load version info';
      options?.onError?.(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
      logger.groupEnd();
    }
  };

  const clearVersionInfo = () => {
    setVersionInfo(null);
    setParentInfo(null);
  };

  return {
    versionInfo,
    parentInfo,
    isLoading,
    loadVersionInfo,
    clearVersionInfo,
  } as const;
}
