import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { logger } from '../utils/logger';
import type { DateRange } from 'react-day-picker';

interface UseDataListProps<T> {
  loadData: () => Promise<{
    success: boolean;
    data?: T[];
    error?: string;
  }>;
  context: {
    module: string;
    function: string;
  };
  refreshTrigger?: boolean;
  filterFn?: (item: T, searchTerm: string) => boolean;
}

export interface UseDataListReturn<T> {
  data: T[];
  loading: boolean;
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  refresh: () => Promise<void>;
}

export function useDataList<T>({
  loadData,
  context,
  refreshTrigger,
  filterFn,
}: UseDataListProps<T>): UseDataListReturn<T> {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const handleLoad = async () => {
    try {
      logger.group('Loading data', context);
      setLoading(true);

      const result = await loadData();

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load data');
      }

      setData(result.data);
      logger.debug('Data loaded successfully', context, {
        count: result.data.length,
      });
    } catch (error) {
      logger.error('Failed to load data', context, { error });
      toast({
        variant: 'destructive',
        title: 'Error',
        description:
          error instanceof Error ? error.message : 'Failed to load data',
      });
    } finally {
      setLoading(false);
      logger.groupEnd();
    }
  };

  useEffect(() => {
    handleLoad();
  }, []);

  useEffect(() => {
    if (refreshTrigger) {
      handleLoad();
    }
  }, [refreshTrigger]);

  const filteredData = filterFn
    ? data.filter((item) => filterFn(item, searchTerm))
    : data;

  return {
    data: filteredData,
    loading,
    searchTerm,
    setSearchTerm,
    refresh: handleLoad,
  };
}
