import { useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useErrorState } from './useErrorState';
import { usePlanData } from './usePlanData';
import { useVersionInfo } from './useVersionInfo';
import { useExport } from './useExport';
import { useLoadingState } from './useLoadingState';
import { usePlanSave } from './usePlanSave';
import { ltPlanExcelConfig } from '../config/excel-config';
import { logger } from '../utils/logger';

export function useWeeklyPlan(planId: string | null) {
  const router = useRouter();
  const { errors, addError, clearErrors } = useErrorState();

  const {
    data,
    setData,
    isLoading: isLoadingData,
    loadPlanData,
  } = usePlanData({
    onError: addError,
  });

  const {
    versionInfo,
    isLoading: isLoadingVersion,
    loadVersionInfo,
  } = useVersionInfo({
    onError: addError,
  });

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);

  const {
    showValidateDialog,
    setShowValidateDialog,
    showConfirmSave,
    setShowConfirmSave,
    validationSteps,
    validationErrors,
    isValidating,
    isSaving,
    handleSave,
    handleConfirmSave,
  } = usePlanSave({
    onSaveSuccess: () => {
      router.push('/tp_ui');
      window.dispatchEvent(new CustomEvent('refreshPlanList'));
    },
    onSaveError: addError,
  });

  const loadingState = useLoadingState({
    isLoadingData,
    isLoadingVersion,
    isExporting,
    isValidating,
    isSaving,
  });

  const loadData = useCallback(async () => {
    if (!planId) {
      addError('No plan ID provided');
      return;
    }

    try {
      await Promise.all([loadPlanData(planId), loadVersionInfo(planId)]);
    } catch (error) {
      logger.error('Failed to load data', { error });
      addError(error);
    }
  }, [planId, loadPlanData, loadVersionInfo, addError]);

  const handleSaveClick = useCallback(async () => {
    try {
      await handleSave(data);
    } catch (error) {
      addError(error);
    }
  }, [data, handleSave, addError]);

  const handleConfirmSaveClick = useCallback(async () => {
    try {
      await handleConfirmSave(data, 'Weekly');
    } catch (error) {
      addError(error);
    }
  }, [data, handleConfirmSave, addError]);

  return {
    data,
    setData,
    versionInfo,
    errors,
    clearErrors,
    loadingState,
    handleExport,
    loadData,
    showValidateDialog,
    setShowValidateDialog,
    showConfirmSave,
    setShowConfirmSave,
    validationSteps,
    validationErrors,
    handleSaveClick,
    handleConfirmSaveClick,
  } as const;
}
