import { useState } from 'react';
import { ExcelProcessor } from '../utils/excel-processor';
import type { ExcelConfig } from '../utils/excel-processor';
import { logger } from '../utils/logger';

interface UseFileUploadOptions<T> {
  onSuccess?: (data: T[]) => void;
  onError?: (errors: string[]) => void;
  onLoadStart?: () => void;
  onLoadEnd?: () => void;
}

export function useFileUpload<T>(
  excelConfig: ExcelConfig<T>,
  options?: UseFileUploadOptions<T>,
) {
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);

  const handleFileUpload = async (file: File) => {
    const context = {
      module: 'useFileUpload',
      function: 'handleFileUpload',
      fileName: file.name,
    };

    try {
      logger.group('Processing file upload', context);
      setIsLoading(true);
      setErrors([]);
      options?.onLoadStart?.();

      const excelProcessor = new ExcelProcessor(excelConfig);
      const { data: processedData, errors: importErrors } =
        await excelProcessor.processFile(file);

      if (importErrors.length > 0) {
        setErrors(importErrors);
        options?.onError?.(importErrors);
        if (processedData.length === 0) {
          return;
        }
      }

      if (processedData.length > 0) {
        logger.debug('File processed successfully', context, {
          rowCount: processedData.length,
        });
        options?.onSuccess?.(processedData);
      }
    } catch (error) {
      logger.error('File processing failed', context, { error });
      const errorMessage =
        error instanceof Error ? error.message : 'Failed to process file';
      setErrors([errorMessage]);
      options?.onError?.([errorMessage]);
    } finally {
      setIsLoading(false);
      options?.onLoadEnd?.();
      logger.groupEnd();
    }
  };

  return {
    handleFileUpload,
    isLoading,
    errors,
    setErrors,
  } as const;
}
