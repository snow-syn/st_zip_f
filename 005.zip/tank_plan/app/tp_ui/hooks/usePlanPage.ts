import { useCallback } from 'react';
import { useRouter } from 'next/navigation';
import type { PlanType } from '../types';
import { useErrorState } from './useErrorState';
import { usePlanData } from './usePlanData';
import { useVersionInfo } from './useVersionInfo';
import { useExport } from './useExport';
import { useLoadingState } from './useLoadingState';
import { usePlanSave } from './usePlanSave';
import { useSaveData } from './useSaveData';
import { ltPlanExcelConfig } from '../config/excel-config';
import { logger } from '../utils/logger';

interface UsePlanPageOptions {
  planId: string | null;
  planType: PlanType;
  loadParentInfo?: boolean;
}

export function usePlanPage({
  planId,
  planType,
  loadParentInfo,
}: UsePlanPageOptions) {
  const router = useRouter();
  const { errors, addError, clearErrors } = useErrorState();
  const { saveData } = useSaveData();

  const {
    data,
    setData,
    isLoading: isLoadingData,
    loadPlanData,
  } = usePlanData({
    onError: addError,
  });

  const {
    versionInfo,
    parentInfo,
    isLoading: isLoadingVersion,
    loadVersionInfo,
  } = useVersionInfo({
    loadParentInfo,
    onError: addError,
  });

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);

  const {
    showValidateDialog,
    setShowValidateDialog,
    showConfirmSave,
    setShowConfirmSave,
    validationSteps,
    validationErrors,
    isValidating,
    isSaving,
    handleSave,
    handleConfirmSave: handleValidationConfirm,
  } = usePlanSave({
    onSaveSuccess: () => {
      window.dispatchEvent(new CustomEvent('refreshPlanList'));
    },
    onSaveError: addError,
  });

  const loadingState = useLoadingState({
    isLoadingData,
    isLoadingVersion,
    isExporting,
    isValidating,
    isSaving,
  });

  const handleParentClick = useCallback(
    (parentId: number) => {
      const context = {
        module: 'usePlanPage',
        function: 'handleParentClick',
        parentId,
      };

      try {
        logger.debug('Navigating to parent plan', context);
        router.replace(`/tp_ui/plan-view?id=${parentId}`);
      } catch (error) {
        logger.error('Failed to navigate to parent plan', context, { error });
        addError(error);
      }
    },
    [router, addError],
  );

  const handleCreateWeekly = useCallback(() => {
    if (!versionInfo) return;

    const context = {
      module: 'usePlanPage',
      function: 'handleCreateWeekly',
      sourceVersionId: versionInfo.plan_master_id,
    };

    try {
      logger.debug('Navigating to weekly plan creation', context);
      router.push(`/tp_ui/weekly?id=${versionInfo.plan_master_id}`);
    } catch (error) {
      logger.error('Failed to navigate to weekly plan creation', context, {
        error,
      });
      addError(error);
    }
  }, [router, versionInfo, addError]);

  const handleSaveClick = useCallback(() => {
    handleSave(data);
  }, [data, handleSave]);

  const loadData = useCallback(async () => {
    if (!planId) {
      addError('No plan ID provided');
      return;
    }

    try {
      await Promise.all([loadPlanData(planId), loadVersionInfo(planId)]);
    } catch (error) {
      logger.error('Failed to load data', { error });
      addError(error);
    }
  }, [planId, loadPlanData, loadVersionInfo, addError]);

  const handleConfirmSave = useCallback(async () => {
    try {
      const versionNo = versionInfo?.plan_version_no || 1;
      
      const success = await saveData(data, planType, { 
        parentId: planId,
        versionNo,
      });
      
      if (success) {
        router.push('/tp_ui');
        window.dispatchEvent(new CustomEvent('refreshPlanList'));
      }
    } catch (error) {
      logger.error('Failed to save data', { error });
      addError(error);
    }
  }, [data, planType, planId, saveData, addError, router, versionInfo]);

  return {
    data,
    setData,
    versionInfo,
    parentInfo,
    errors,
    clearErrors,
    loadingState,
    handleParentClick,
    handleCreateWeekly,
    handleExport,
    handleSaveClick,
    loadData,
    showValidateDialog,
    setShowValidateDialog,
    showConfirmSave,
    setShowConfirmSave,
    validationSteps,
    validationErrors,
    isValidating,
    isSaving,
    handleConfirmSave,
  } as const;
}
