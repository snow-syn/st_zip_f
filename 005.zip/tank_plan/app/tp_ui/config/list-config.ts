import type { FilterOption } from '../components/data-list-card';
import type { PlanType } from '../types';

type ChangeType = 'INSERT' | 'UPDATE' | 'DELETE' | 'all';

export const planTypeOptions: FilterOption<PlanType | 'all'>[] = [
  { value: 'all', label: 'All Types' },
  { value: 'Long-term', label: 'Long-term' },
  { value: 'Weekly', label: 'Weekly' },
];

export const planTagOptions: FilterOption[] = [
  { value: 'all', label: 'All Tags' },
  { value: 'GB', label: 'GB' },
  { value: '18MP', label: '18MP' },
];

export const changeTypeOptions: FilterOption<ChangeType>[] = [
  { value: 'all', label: 'All Types' },
  { value: 'INSERT', label: 'Insert' },
  { value: 'UPDATE', label: 'Update' },
  { value: 'DELETE', label: 'Delete' },
];

export const operationTypeOptions = [
  { value: 'all', label: 'All Actions' },
  { value: 'Uploaded', label: 'Uploaded' },
  { value: 'Created', label: 'Created' },
  { value: 'Updated', label: 'Updated' },
  { value: 'Exported', label: 'Exported' },
  { value: 'Deleted', label: 'Deleted' },
];
