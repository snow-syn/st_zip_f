'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { ErrorDisplay } from '@/app/tp_ui/components/error-display';
import type { TankPlanDetailData, PlanVersion } from '../types';
import { useExport } from '../hooks/useExport';
import { ltPlanExcelConfig } from '../config/excel-config';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarRange } from 'lucide-react';
import { DataTable } from '@/app/tp_ui/components/DataTable';
import { createTableColumns } from '../config/table-columns';
import { VersionInfoCard } from '../components/version-info-card';
import { DateUtils } from '../utils';
import { DATE_COLUMNS } from '../config/config';
import { Button } from '@/components/ui/button';
import { CalendarPlus, FileDown } from 'lucide-react';
import { cn } from '@/lib/utils';

function PlanViewContent() {
  const [data, setData] = useState<TankPlanDetailData[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const planId = searchParams.get('id');

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);

  const [versionInfo, setVersionInfo] = useState<PlanVersion | null>(null);
  const [parentInfo, setParentInfo] = useState<PlanVersion | null>(null);

  const loadPlanData = async (id: string) => {
    const context = {
      module: 'PlanView',
      function: 'loadPlanData',
      planId: id,
    };

    try {
      logger.group('Loading plan data', context);
      setIsLoading(true);
      setErrors([]);

      const result = await DatabaseService.getVersionData(Number(id));

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load plan data');
      }

      setData(result.data);
    } catch (error) {
      logger.error('Failed to load plan', context, { error });
      setErrors([
        error instanceof Error ? error.message : 'Failed to load plan data',
      ]);
    } finally {
      setIsLoading(false);
      logger.groupEnd();
    }
  };

  const loadVersionInfo = async (id: string) => {
    const context = {
      module: 'PlanView',
      function: 'loadVersionInfo',
      planId: id,
    };

    try {
      logger.group('Loading version info', context);
      const result = await DatabaseService.getVersionInfo(Number(id));

      if (!result.success || !result.data) {
        throw new Error(result.error || '加载版本信息失败');
      }

      setVersionInfo(result.data);

      if (result.data.plan_version_parent) {
        const parentResult = await DatabaseService.getVersionInfo(
          Number(result.data.plan_version_parent),
        );

        if (parentResult.success && parentResult.data) {
          setParentInfo(parentResult.data);
        } else {
          logger.warn('Failed to load parent version info', context, {
            error: parentResult.error,
          });
        }
      }
    } catch (error) {
      logger.error('Failed to load version info', context, { error });
      setErrors((prev) => [
        ...prev,
        error instanceof Error ? error.message : '加载版本信息失败',
      ]);
    } finally {
      logger.groupEnd();
    }
  };

  const handleParentClick = (parentId: number) => {
    const context = {
      module: 'PlanView',
      function: 'handleParentClick',
      parentId,
    };

    try {
      logger.debug('Navigating to parent plan', context);
      router.replace(`/tp_ui/plan-view?id=${parentId}`);
    } catch (error) {
      logger.error('Failed to navigate to parent plan', context, { error });
    }
  };

  const handleCreateWeekly = () => {
    if (!versionInfo) return;

    const context = {
      module: 'PlanView',
      function: 'handleCreateWeekly',
      sourceVersionId: versionInfo.plan_master_id,
    };

    try {
      logger.debug('Navigating to weekly plan creation', context);
      router.push(`/tp_ui/weekly?id=${versionInfo.plan_master_id}`);
    } catch (error) {
      logger.error('Failed to navigate to weekly plan creation', context, {
        error,
      });
    }
  };

  useEffect(() => {
    if (planId) {
      Promise.all([loadPlanData(planId), loadVersionInfo(planId)]);
    } else {
      setErrors(['No plan ID provided']);
    }
  }, [planId]);

  const columns = createTableColumns({
    allowEdit: false,
    formatValue: (value, columnId) => {
      const isDateColumn = DATE_COLUMNS.includes(columnId as any);
      return isDateColumn ? DateUtils.format(value) : value;
    },
  });

  const ActionButtons = () => (
    <div className="flex items-center gap-3">
      <Button
        variant="outline"
        size="sm"
        onClick={handleCreateWeekly}
        disabled={isLoading}
      >
        <CalendarPlus className="mr-2 h-4 w-4" />
        Create Weekly Plan
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={handleExport}
        disabled={isLoading || !data.length || isExporting}
      >
        <FileDown
          className={cn('mr-2 h-4 w-4', isExporting && 'animate-pulse')}
        />
        {isExporting ? 'Exporting...' : 'Export Excel'}
      </Button>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
      className="flex h-full flex-col"
    >
      <div className="flex-none px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <CalendarRange className="h-4 w-4 text-primary" />
            </div>
            <h1 className="text-xl font-semibold tracking-tight">Plan View</h1>
          </div>
          <ActionButtons />
        </div>
      </div>

      <div className="flex-none px-4">
        <AnimatePresence mode="wait">
          {versionInfo && (
            <motion.div
              key={versionInfo.plan_master_id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <VersionInfoCard
                version={versionInfo}
                parentInfo={parentInfo}
                onParentClick={handleParentClick}
                showParentInfo
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="flex-none px-4">
        <ErrorDisplay
          errors={errors}
          title="Error"
          description="Failed to load plan data"
          variant="error"
          onClose={() => setErrors([])}
        />
      </div>

      <div className="min-h-0 flex-1 p-4">
        <AnimatePresence mode="wait">
          {data.length > 0 && (
            <motion.div
              key={planId}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-full w-full"
            >
              <DataTable
                data={data}
                columns={columns}
                editConfig={{
                  allowEdit: false,
                }}
                className="h-full w-full"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default function PlanView() {
  return (
    <Suspense
      fallback={
        <div className="flex h-full items-center justify-center">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span className="text-sm text-muted-foreground">Loading...</span>
          </div>
        </div>
      }
    >
      <PlanViewContent />
    </Suspense>
  );
}
