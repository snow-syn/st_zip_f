import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { MoreHorizontal, Eye, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/app/tp_ui/utils/logger';
import DatabaseService from '@/app/tp_ui/services/DatabaseService';
import type { PlanVersion, PlanType } from '@/app/tp_ui/types';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { DateRange } from 'react-day-picker';
import { DataListCard } from './data-list-card';
import { planTypeOptions, planTagOptions } from '../config/list-config';
import { getDefaultDateRange } from '../utils';
import { useDataList } from '../hooks/useDataList';
import { useRouter } from 'next/navigation';

interface PlanListProps {
  refreshing: boolean;
  onRefresh: () => void;
}

export function PlanList({ refreshing, onRefresh }: PlanListProps) {
  const [selectedType, setSelectedType] = useState<PlanType | 'all'>('all');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [date, setDate] = useState<DateRange | undefined>(
    getDefaultDateRange(),
  );
  const router = useRouter();
  const { toast } = useToast();

  const {
    data: plans,
    loading,
    searchTerm,
    setSearchTerm,
    refresh,
  } = useDataList<PlanVersion>({
    loadData: async () => {
      const result = await DatabaseService.getPlanVersions();
      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load plan versions');
      }
      return {
        success: true,
        data: result.data,
      };
    },
    context: {
      module: 'PlanList',
      function: 'loadPlanList',
    },
    refreshTrigger: refreshing,
    filterFn: (plan: PlanVersion, term: string): boolean => {
      if (selectedType !== 'all' && plan.plan_type !== selectedType) {
        return false;
      }
      if (selectedTag !== 'all' && plan.plan_official !== selectedTag) {
        return false;
      }
      if (date?.from && date?.to) {
        const planDate = new Date(plan.create_timestamp);
        if (planDate < date.from || planDate > date.to) return false;
      }
      if (term && term.length > 0) {
        const searchLower = term.toLowerCase();
        return (
          plan.plan_version.toLowerCase().includes(searchLower) ||
          plan.user_name.toLowerCase().includes(searchLower)
        );
      }
      return true;
    },
  });

  const handleViewPlan = (plan: PlanVersion) => {
    const context = {
      module: 'PlanList',
      function: 'handleViewPlan',
      planId: plan.plan_master_id,
    };

    try {
      logger.debug('Navigating to plan view', context);
      router.push(`/tp_ui/plan-view?id=${plan.plan_master_id}`);
    } catch (error) {
      logger.error('Navigation failed', context, { error });
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to navigate to plan view',
      });
    }
  };

  return (
    <DataListCard<PlanType | 'all'>
      title="Plan Version List"
      loading={loading}
      onRefresh={refresh}
      searchPlaceholder="Search plans..."
      onSearch={setSearchTerm}
      filterOptions={{
        type: planTypeOptions,
        tag: planTagOptions,
      }}
      onFilterChange={{
        type: setSelectedType,
        tag: setSelectedTag,
      }}
      selectedFilters={{
        type: selectedType,
        tag: selectedTag,
      }}
      dateRange={date}
      onDateRangeChange={setDate}
    >
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Plan Version</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Created By</TableHead>
            <TableHead>Created At</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {plans.map((plan) => (
            <TableRow key={plan.plan_master_id}>
              <TableCell>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{plan.plan_version}</span>
                  {plan.plan_official && (
                    <Badge
                      variant="outline"
                      className={cn(
                        'h-5 px-2 text-xs font-medium',
                        plan.plan_official === 'GB'
                          ? 'border-purple-300 bg-purple-50/50 text-purple-700 hover:bg-purple-100 dark:border-purple-800 dark:bg-purple-950/20 dark:text-purple-400'
                          : plan.plan_official === '18MP'
                            ? 'border-amber-300 bg-amber-50/50 text-amber-700 hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-400'
                            : '',
                      )}
                    >
                      {plan.plan_official}
                    </Badge>
                  )}
                  {plan.plan_version_no > 1 && (
                    <Badge variant="outline" className="h-5 px-1 text-xs">
                      v{plan.plan_version_no}
                    </Badge>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <Badge
                  variant="outline"
                  className={cn(
                    'h-5 px-2 text-xs font-medium',
                    plan.plan_type === 'Long-term'
                      ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950/30 dark:text-blue-400'
                      : 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400',
                  )}
                >
                  {plan.plan_type}
                </Badge>
              </TableCell>
              <TableCell>{plan.user_name}</TableCell>
              <TableCell className="text-muted-foreground">
                {format(new Date(plan.create_timestamp), 'PPp')}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-7 w-7">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-[160px]">
                    <DropdownMenuItem
                      onClick={() => handleViewPlan(plan)}
                      className="cursor-pointer"
                    >
                      <Eye className="mr-2 h-4 w-4" />
                      <span>View Details</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => handleViewPlan(plan)}
                      className="cursor-pointer"
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      <span>View Plan</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </DataListCard>
  );
}
