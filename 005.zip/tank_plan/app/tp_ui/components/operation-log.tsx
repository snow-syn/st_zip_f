import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Upload, FileDown, History } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { DateRange } from 'react-day-picker';
import DatabaseService from '../services/DatabaseService';
import { getDefaultDateRange } from '../utils';
import { DataListCard } from './data-list-card';
import { operationTypeOptions } from '../config/list-config';
import { useDataList } from '../hooks/useDataList';
import type { OperationLog } from '../types';

interface OperationLogProps {
  refreshing: boolean;
  onRefresh: () => void;
}

const actionIcons = {
  Uploaded: Upload,
  Created: History,
  Updated: History,
  Exported: FileDown,
  Deleted: History,
};

const actionColors = {
  Uploaded: 'text-blue-500',
  Created: 'text-green-500',
  Updated: 'text-amber-500',
  Exported: 'text-purple-500',
  Deleted: 'text-red-500',
};

export function OperationLog({ refreshing, onRefresh }: OperationLogProps) {
  const [selectedAction, setSelectedAction] = useState<string>('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>(
    getDefaultDateRange(),
  );

  const {
    data: logs,
    loading,
    searchTerm,
    setSearchTerm,
    refresh,
  } = useDataList<OperationLog>({
    loadData: async () => {
      const result = await DatabaseService.getOperationLogs(
        dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : undefined,
        dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : undefined,
      );
      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load operation logs');
      }
      return {
        success: result.success,
        data: result.data.map((log) => ({
          ...log,
          plan_version: log.plan_version || '',
          plan_version_no: log.plan_version_no || 0,
        })),
        error: result.error,
      };
    },
    context: {
      module: 'OperationLog',
      function: 'loadOperationLogs',
    },
    refreshTrigger: refreshing,
    filterFn: (record: OperationLog, term: string): boolean => {
      // 首先检查日期范围
      if (dateRange?.from || dateRange?.to) {
        const recordDate = new Date(record.create_timestamp);
        if (dateRange.from && recordDate < dateRange.from) return false;
        if (dateRange.to && recordDate > dateRange.to) return false;
      }

      // 检查操作类型筛选
      if (selectedAction !== 'all' && record.action !== selectedAction) {
        return false;
      }

      // 搜索词筛选
      if (term) {
        const searchLower = term.toLowerCase();
        return (
          record.user_name.toLowerCase().includes(searchLower) ||
          record.action.toLowerCase().includes(searchLower) ||
          record.plan_version.toLowerCase().includes(searchLower)
        );
      }

      return true;
    },
  });

  return (
    <DataListCard<string>
      title="Operation Log"
      loading={loading}
      onRefresh={refresh}
      searchPlaceholder="Search logs..."
      onSearch={setSearchTerm}
      filterOptions={{
        type: operationTypeOptions,
      }}
      onFilterChange={{
        type: setSelectedAction,
      }}
      selectedFilters={{
        type: selectedAction,
      }}
      dateRange={dateRange}
      onDateRangeChange={setDateRange}
    >
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Action</TableHead>
            <TableHead>User</TableHead>
            <TableHead>Plan Version</TableHead>
            <TableHead>Time</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {logs.map((log) => {
            const Icon = actionIcons[log.action];
            return (
              <TableRow key={log.operation_id}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Icon className={cn('h-4 w-4', actionColors[log.action])} />
                    <span>{log.action}</span>
                  </div>
                </TableCell>
                <TableCell>{log.user_name}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <span>{log.plan_version}</span>
                    {log.plan_version_no > 1 && (
                      <span className="text-xs text-muted-foreground">
                        (v{log.plan_version_no})
                      </span>
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {format(new Date(log.create_timestamp), 'PPp')}
                </TableCell>
              </TableRow>
            );
          })}
          {!logs.length && (
            <TableRow>
              <TableCell colSpan={4} className="h-24 text-center">
                No operation logs found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </DataListCard>
  );
}
