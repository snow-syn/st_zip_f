import * as React from 'react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { TypeBadge, TagBadge } from './badges';
import { format } from 'date-fns';
import { User, Clock, Table, GitBranch } from 'lucide-react';
import type { PlanVersion } from '../types';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';

interface VersionInfoCardProps {
  version: PlanVersion;
  parentInfo?: PlanVersion | null;
  onParentClick?: (parentId: number) => void;
  showParentInfo?: boolean;
  className?: string;
}

function VersionMeta({
  icon: Icon,
  value,
}: {
  icon: React.ElementType;
  value: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="h-3.5 w-3.5" />
      <span>{value}</span>
    </div>
  );
}

function ParentInfo({
  parent,
  onParentClick,
}: {
  parent: PlanVersion;
  onParentClick?: (parentId: number) => void;
}) {
  return (
    <div className="space-y-3 p-3">
      <div className="space-y-1.5">
        <div className="flex items-center gap-2">
          <span className="text-base font-semibold">{parent.plan_version}</span>
          <TypeBadge type={parent.plan_type} />
          {parent.plan_official && <TagBadge tag={parent.plan_official} />}
        </div>
        <div className="text-xs text-muted-foreground">
          Version {parent.plan_version_no}
        </div>
      </div>

      <div className="space-y-2 rounded-md bg-muted/50 p-2 text-sm text-muted-foreground">
        <VersionMeta icon={User} value={parent.user_name} />
        <VersionMeta
          icon={Clock}
          value={format(new Date(parent.create_timestamp), 'PPp')}
        />
        <VersionMeta icon={Table} value={`${parent.row_count ?? 0} rows`} />
      </div>

      {onParentClick && (
        <Button
          variant="default"
          size="sm"
          className="group mt-2 w-full justify-center"
          onClick={() => onParentClick(parent.plan_master_id)}
        >
          <span className="flex items-center gap-2">
            View Parent Plan
            <GitBranch className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </span>
        </Button>
      )}
    </div>
  );
}

export function VersionInfoCard({
  version,
  parentInfo,
  onParentClick,
  showParentInfo = false,
  className,
}: VersionInfoCardProps) {
  const showParent =
    showParentInfo && version.plan_version_parent && parentInfo;

  return (
    <div
      className={cn(
        'overflow-hidden rounded-lg border bg-card shadow-sm',
        className,
      )}
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-semibold tracking-tight">
                  {version.plan_version}
                </h2>
                <TypeBadge type={version.plan_type} />
                {version.plan_official && (
                  <TagBadge tag={version.plan_official} />
                )}
                {version.plan_version_no > 1 && (
                  <Badge variant="outline" className="h-5 px-1.5">
                    v{version.plan_version_no}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <VersionMeta icon={User} value={version.user_name} />
                <div>•</div>
                <VersionMeta
                  icon={Clock}
                  value={format(new Date(version.create_timestamp), 'PPp')}
                />
                <div>•</div>
                <VersionMeta
                  icon={Table}
                  value={`${version.row_count ?? 0} rows`}
                />
              </div>
            </div>

            {showParent && (
              <>
                <div className="h-10 w-px bg-border" />
                <div className="flex items-center">
                  <TooltipProvider delayDuration={200}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="link"
                          size="sm"
                          className="group flex items-center gap-2 px-0 text-sm font-medium text-primary hover:text-primary/80"
                        >
                          <GitBranch className="h-3.5 w-3.5 transition-transform duration-200 group-hover:-translate-y-0.5" />
                          <span>
                            Parent: {parentInfo.plan_version}-v
                            {parentInfo.plan_version_no}
                          </span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent
                        side="bottom"
                        align="start"
                        className="w-72 p-0 shadow-lg"
                      >
                        <ParentInfo
                          parent={parentInfo}
                          onParentClick={onParentClick}
                        />
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
