'use client';

import { DataTable } from '@/app/tp_ui/components/DataTable';
import { ErrorDisplay } from '@/app/tp_ui/components/error-display';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { AnimatePresence, motion } from 'framer-motion';
import {
  CalendarRange,
  FileDown,
  FileText,
  History,
  Loader2,
  Save,
  Upload,
} from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useEffect, useState } from 'react';
import { ValidationDialog } from '../components/validation-dialog';
import { VersionInfoCard } from '../components/version-info-card';
import { DATE_COLUMNS } from '../config/config';
import { ltPlanExcelConfig } from '../config/excel-config';
import { createTableColumns } from '../config/table-columns';
import { useErrorState } from '../hooks/useErrorState';
import { useExport } from '../hooks/useExport';
import { useFileUpload } from '../hooks/useFileUpload';
import { useLatestPlan } from '../hooks/useLatestPlan';
import { usePlanData } from '../hooks/usePlanData';
import { usePlanSave } from '../hooks/usePlanSave';
import { useVersionInfo } from '../hooks/useVersionInfo';
import { DateUtils, ValidationUtils } from '../utils';

function LongTermPlanContent() {
  const router = useRouter();
  const { errors, setErrors, clearErrors } = useErrorState();
  const [showTable, setShowTable] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const searchParams = useSearchParams();
  const planId = searchParams.get('id');

  const {
    data,
    setData,
    isLoading: isLoadingData,
    loadPlanData,
  } = usePlanData({
    onError: (error) => setErrors((prev) => [...prev, error]),
  });

  const {
    versionInfo,
    isLoading: isLoadingVersion,
    loadVersionInfo,
  } = useVersionInfo({
    onError: (error) => setErrors((prev) => [...prev, error]),
  });

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);

  const {
    showValidateDialog,
    setShowValidateDialog,
    showConfirmSave,
    setShowConfirmSave,
    validationSteps,
    validationErrors,
    isValidating,
    isSaving,
    handleSave,
    handleConfirmSave,
  } = usePlanSave({
    onSaveSuccess: () => {
      router.push('/tp_ui');
      window.dispatchEvent(new CustomEvent('refreshPlanList'));
    },
    onSaveError: (error) => setErrors((prev) => [...prev, error]),
  });

  const {
    handleFileUpload,
    isLoading: isUploading,
    errors: uploadErrors,
  } = useFileUpload(ltPlanExcelConfig, {
    onSuccess: (processedData) => {
      setIsTransitioning(true);
      setTimeout(() => {
        setData(processedData);
        setShowTable(true);
        requestAnimationFrame(() => {
          setTimeout(() => {
            setIsTransitioning(false);
          }, 50);
        });
      }, 150);
    },
    onError: (errors) => {
      setErrors(errors);
    },
  });

  const { isLoading: isLoadingLatest, loadLatestPlan } = useLatestPlan({
    onLoadStart: () => {
      setErrors([]);
      setIsTransitioning(true);
    },
    onSuccess: (latestData) => {
      setTimeout(() => {
        setData(latestData);
        setShowTable(true);
        requestAnimationFrame(() => {
          setTimeout(() => {
            setIsTransitioning(false);
          }, 50);
        });
      }, 150);
    },
    onError: (error) => {
      setErrors([error]);
    },
    onLoadEnd: () => {
      setIsTransitioning(false);
    },
  });

  const isLoading =
    isUploading ||
    isTransitioning ||
    isLoadingLatest ||
    isLoadingData ||
    isLoadingVersion;

  const columns = createTableColumns({
    allowEdit: true,
    formatValue: (value, columnId) => {
      const isDateColumn = DATE_COLUMNS.includes(columnId as any);
      return isDateColumn ? DateUtils.format(value) : value;
    },
    validateCell: (value, columnId) => {
      const isDateColumn = DATE_COLUMNS.includes(columnId as any);
      return isDateColumn
        ? ValidationUtils.validateDate(value, columnId)
        : null;
    },
  });

  const handleSaveClick = () => {
    handleSave(data);
  };

  const ActionButtons = () => (
    <div className="flex items-center gap-3">
      <Button
        variant="outline"
        size="sm"
        onClick={handleSaveClick}
        disabled={isLoading || !data.length || isSaving}
      >
        {isSaving ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          <>
            <Save className="mr-2 h-4 w-4" />
            Validate & Save
          </>
        )}
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          setShowTable(false);
          setData([]);
        }}
        disabled={isLoading}
      >
        <Upload className="mr-2 h-4 w-4" />
        Re-upload
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={handleExport}
        disabled={isLoading || !data.length || isExporting}
      >
        <FileDown
          className={cn('mr-2 h-4 w-4', isExporting && 'animate-pulse')}
        />
        {isExporting ? 'Exporting...' : 'Export Excel'}
      </Button>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
      className="flex h-full flex-col"
    >
      <div className="flex-none px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <CalendarRange className="h-4 w-4 text-primary" />
            </div>
            <h1 className="text-xl font-semibold tracking-tight">
              Long-term Plan
            </h1>
          </div>
          {showTable && <ActionButtons />}
        </div>
      </div>

      <div className="min-h-0 flex-1">
        <AnimatePresence mode="wait">
          {!showTable ? (
            <UploadZone
              onFileSelect={handleFileUpload}
              onLoadLatest={loadLatestPlan}
              isLoading={isLoading}
              isLoadingLatest={isLoadingLatest}
              errors={errors}
              onErrorClose={clearErrors}
            />
          ) : (
            <div className="flex h-full flex-col gap-4">
              {versionInfo && (
                <div className="flex-none px-4">
                  <VersionInfoCard
                    version={versionInfo}
                    parentInfo={null}
                    showParentInfo={false}
                    className="mb-4"
                  />
                </div>
              )}

              <div className="min-h-0 flex-1 p-4">
                <DataTable
                  data={data}
                  columns={columns}
                  errors={errors}
                  onDataChange={setData}
                  editConfig={{
                    allowEdit: true,
                    validateCell: (value, columnId) => {
                      const column = columns.find(
                        (col) => col.key === columnId,
                      );
                      return column?.validateValue?.(value) ?? null;
                    },
                    formatValue: (value, columnId) => {
                      const column = columns.find(
                        (col) => col.key === columnId,
                      );
                      return column?.formatValue?.(value) ?? value;
                    },
                  }}
                  className="h-full w-full"
                />
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>

      <ValidationDialog
        open={showValidateDialog}
        onOpenChange={(open) => {
          setShowValidateDialog(open);
          if (!open) {
            setShowConfirmSave(false);
          }
        }}
        validationSteps={validationSteps}
        errors={validationErrors}
        isValidating={isValidating}
        isSaving={isSaving}
        onConfirmSave={
          showConfirmSave
            ? () => handleConfirmSave(data, 'Long-term')
            : undefined
        }
      />
    </motion.div>
  );
}

export default function LongTermPlan() {
  return (
    <Suspense
      fallback={
        <div className="flex h-full items-center justify-center">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span className="text-sm text-muted-foreground">Loading...</span>
          </div>
        </div>
      }
    >
      <LongTermPlanContent />
    </Suspense>
  );
}

const TransitionContainer = ({
  children,
  show,
  appear = false,
}: {
  children: React.ReactNode;
  show: boolean;
  appear?: boolean;
}) => {
  return (
    <div
      className={cn(
        'h-full transition-all duration-300',
        show
          ? 'animate-in fade-in-0 zoom-in-95'
          : 'animate-out fade-out-0 zoom-out-95',
        appear && 'opacity-0',
      )}
    >
      {children}
    </div>
  );
};

const UploadZone = ({
  onFileSelect,
  onLoadLatest,
  isLoading,
  isLoadingLatest,
  errors = [],
  onErrorClose,
}: {
  onFileSelect: (file: File) => void;
  onLoadLatest: () => void;
  isLoading: boolean;
  isLoadingLatest: boolean;
  errors?: string[];
  onErrorClose?: () => void;
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [appear, setAppear] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setAppear(false), 50);
    return () => clearTimeout(timer);
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) onFileSelect(file);
  };

  const importSteps = [
    { label: 'Reading file...', delay: 0 },
    { label: 'Validating format...', delay: 1000 },
    { label: 'Processing data...', delay: 2000 },
    { label: 'Checking fields...', delay: 3000 },
  ];

  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (isLoading) {
      let stepIndex = 0;
      const timers = importSteps.map((step, index) => {
        return setTimeout(() => {
          setCurrentStep(index);
        }, step.delay);
      });

      return () => {
        timers.forEach((timer) => clearTimeout(timer));
        setCurrentStep(0);
      };
    }
  }, [isLoading]);

  return (
    <TransitionContainer show={true} appear={appear}>
      <div className="flex h-full flex-col items-center justify-start">
        {errors.length > 0 && (
          <div className="mb-4 w-full max-w-2xl">
            <ErrorDisplay
              errors={errors}
              title="Import Error"
              description="Please check your file and try again"
              onClose={onErrorClose}
              variant="error"
            />
          </div>
        )}

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={cn(
            'relative w-full max-w-2xl rounded-xl border-2 border-dashed bg-card/50 transition-all duration-200',
            'before:absolute before:inset-0 before:rounded-xl before:bg-gradient-to-b before:from-muted/50 before:to-transparent before:opacity-50',
            isDragging
              ? 'scale-[0.99] border-primary bg-primary/5 before:opacity-0'
              : 'border-border/50 hover:border-border hover:bg-card/80',
            isLoading && 'pointer-events-none',
          )}
        >
          <div className="relative flex flex-col items-center gap-6 px-6 py-12">
            <div
              className={cn(
                'rounded-full p-6 ring-8 ring-background/50 transition-all duration-200',
                isDragging ? 'scale-110 bg-primary/20' : 'bg-primary/10',
              )}
            >
              {isLoading ? (
                <div className="relative">
                  <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  <div className="absolute inset-0 animate-pulse rounded-full bg-primary/10" />
                </div>
              ) : (
                <Upload className="h-10 w-10 text-primary" />
              )}
            </div>

            <div className="space-y-2 text-center">
              <h3 className="text-2xl font-semibold tracking-tight">
                {isLoading ? (
                  <span className="inline-flex items-center gap-3">
                    {importSteps[currentStep].label}
                    <span className="inline-flex gap-1">
                      {[...Array(3)].map((_, i) => (
                        <span
                          key={i}
                          className={cn(
                            'h-1 w-1 rounded-full bg-primary',
                            'animate-bounce',
                            { 'animation-delay-200': i === 1 },
                            { 'animation-delay-400': i === 2 },
                          )}
                        />
                      ))}
                    </span>
                  </span>
                ) : (
                  'Upload Long-term Excel File'
                )}
              </h3>
              <p className="text-base text-muted-foreground">
                {isDragging
                  ? 'Release to Upload'
                  : isLoading
                    ? 'Please wait while we process your file'
                    : 'Drag & drop file here, or click the button below'}
              </p>
            </div>

            {isLoading && (
              <div className="w-full max-w-xs space-y-2">
                <div className="h-1 w-full overflow-hidden rounded-full bg-primary/10">
                  <div
                    className="h-full bg-primary transition-all duration-500"
                    style={{
                      width: `${((currentStep + 1) / importSteps.length) * 100}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Progress</span>
                  <span>
                    {Math.round(((currentStep + 1) / importSteps.length) * 100)}
                    %
                  </span>
                </div>
              </div>
            )}

            {!isLoading && (
              <div className="flex items-center gap-2">
                <label className="group cursor-pointer">
                  <div className="overflow-hidden rounded-lg">
                    <div
                      className={cn(
                        'relative inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground shadow-sm',
                        'before:absolute before:inset-0 before:bg-white before:opacity-0 before:transition-opacity hover:before:opacity-10',
                        'active:scale-95',
                        'transition-all duration-200',
                        isLoading && 'pointer-events-none opacity-70',
                      )}
                    >
                      <Upload className="h-4 w-4" />
                      Select File
                    </div>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept=".xlsx,.xls,.csv"
                    onChange={(e) =>
                      e.target.files?.[0] && onFileSelect(e.target.files[0])
                    }
                    disabled={isLoading}
                  />
                </label>

                <div className="mx-1.5 h-6 w-[1px] bg-border/50" />

                <button
                  onClick={onLoadLatest}
                  disabled={isLoading || isLoadingLatest}
                  className={cn(
                    'group relative inline-flex items-center gap-2 rounded-lg px-6 py-3 font-medium',
                    'bg-card/60 text-muted-foreground shadow-sm ring-1 ring-border/50',
                    'hover:bg-card hover:text-foreground hover:ring-border',
                    'active:scale-95',
                    'transition-all duration-200',
                    (isLoading || isLoadingLatest) &&
                      'pointer-events-none opacity-70',
                  )}
                >
                  <div className="relative">
                    {isLoadingLatest ? (
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    ) : (
                      <>
                        <History
                          className={cn(
                            'h-4 w-4 transition-transform duration-200',
                            'group-hover:rotate-[-30deg]',
                          )}
                        />
                        <div
                          className={cn(
                            'absolute inset-0 opacity-0 transition-opacity duration-200',
                            'group-hover:opacity-100',
                          )}
                        >
                          <div className="absolute inset-0 animate-ping rounded-full bg-primary/20" />
                        </div>
                      </>
                    )}
                  </div>
                  <span>
                    {isLoadingLatest ? 'Loading...' : 'Load Latest Plan'}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>

        {!isLoading && (
          <div className="mt-8 grid grid-cols-3 gap-6">
            {[
              {
                step: '1',
                title: 'Prepare',
                icon: FileText,
                desc: 'Prepare Excel file',
                steps: [
                  'Use worksheet "sheet1"',
                  'Match required columns',
                  'Fill in data correctly',
                ],
                color: 'from-blue-500/5 to-blue-500/0',
                iconColor: 'text-blue-500',
                iconBg: 'bg-blue-500/10',
                ringColor: 'ring-blue-500/10',
              },
              {
                step: '2',
                title: 'Import',
                icon: Upload,
                desc: 'Import Excel file',
                steps: ['Drop or click to Import', 'Review any issues'],
                color: 'from-violet-500/5 to-violet-500/0',
                iconColor: 'text-violet-500',
                iconBg: 'bg-violet-500/10',
                ringColor: 'ring-violet-500/10',
              },
              {
                step: '3',
                title: 'Save',
                icon: Save,
                desc: 'Save the data',
                steps: ['Validate the data', 'Fix if needed', 'Save & Notify'],
                color: 'from-emerald-500/5 to-emerald-500/0',
                iconColor: 'text-emerald-500',
                iconBg: 'bg-emerald-500/10',
                ringColor: 'ring-emerald-500/10',
              },
            ].map(
              ({
                step,
                title,
                icon: Icon,
                desc,
                steps,
                color,
                iconColor,
                iconBg,
                ringColor,
              }) => (
                <div
                  key={step}
                  className={cn(
                    'group relative overflow-hidden rounded-xl border shadow-sm',
                    'bg-gradient-to-b from-card to-card/50',
                    'transition duration-300 hover:shadow-md',
                    'dark:shadow-none',
                  )}
                >
                  <div
                    className={cn(
                      'absolute inset-0 bg-gradient-to-b opacity-0 transition-opacity duration-300',
                      'group-hover:opacity-100',
                      color,
                    )}
                  />

                  <div className="relative p-5">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                          'transition-all duration-300 group-hover:scale-110',
                          'ring-2 ring-offset-2 ring-offset-background',
                          iconBg,
                          ringColor,
                        )}
                      >
                        <Icon className={cn('h-5 w-5', iconColor)} />
                      </div>
                      <div>
                        <h4 className="flex items-center gap-2 text-lg font-semibold tracking-tight">
                          {title}
                        </h4>
                        <p className="mt-1.5 text-sm text-muted-foreground">
                          {desc}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 space-y-2 pl-8">
                      {steps.map((text, index) => (
                        <div
                          key={index}
                          className={cn(
                            'relative flex items-center gap-3',
                            'text-sm text-muted-foreground',
                          )}
                        >
                          <div
                            className={cn(
                              'h-1.5 w-1.5 shrink-0 rounded-full',
                              'bg-muted-foreground/30',
                              'group-hover:bg-muted-foreground/50',
                            )}
                          />
                          <span>{text}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ),
            )}
          </div>
        )}
      </div>
    </TransitionContainer>
  );
};
