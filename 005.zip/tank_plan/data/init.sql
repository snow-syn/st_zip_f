-- 删除已存在的表
DROP TABLE IF EXISTS app_tank_plan_detail;
DROP TABLE IF EXISTS app_tank_plan_master;
DROP TABLE IF EXISTS app_tank_plan_history;

-- 创建主表
CREATE TABLE app_tank_plan_master (
    plan_master_id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_version VARCHAR(50) NOT NULL,
    plan_type VARCHAR(20) NOT NULL,
    plan_official VARCHAR(20),
    plan_version_no INTEGER NOT NULL,
    plan_version_parent VARCHAR(50),
    version_match VARCHAR(50),
    create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_name VARCHAR(50) NOT NULL
);

-- 创建明细表
CREATE TABLE app_tank_plan_detail (
    plan_detail_id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_master_id INTEGER NOT NULL,
    plan_row_id INTEGER NOT NULL,
    tank VARCHAR(20) NOT NULL,
    iso VARCHAR(50),
    glass_type VARCHAR(50),
    gen VARCHAR(20),
    RT VARCHAR(20),
    RC VARCHAR(20),
    platform VARCHAR(50),
    design_asis VARCHAR(100),
    tank_life FLOAT,
    last_tank_light_date DATE,
    drain_date DATE,
    repair_date DATE,
    RTL_date DATE,
    TL_date DATE,
    GG_date DATE,
    cold_idle FLOAT,
    repair_LT FLOAT,
    RTL_LT FLOAT,
    TL_LT FLOAT,
    remark_category VARCHAR(50),
    remark TEXT,
    comment TEXT,
    create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_name VARCHAR(50) NOT NULL,
    FOREIGN KEY (plan_master_id) REFERENCES app_tank_plan_master(plan_master_id)
);

-- 创建变更历史表
CREATE TABLE IF NOT EXISTS app_tank_plan_history (
    history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_master_id INTEGER NOT NULL,
    plan_row_id VARCHAR(50) NOT NULL,
    tank VARCHAR(20) NOT NULL,
    field_name VARCHAR(50) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    change_type VARCHAR(20) NOT NULL, -- 'UPDATE', 'INSERT', 'DELETE'
    create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_name VARCHAR(50) NOT NULL,
    FOREIGN KEY (plan_master_id) REFERENCES app_tank_plan_master(plan_master_id)
);

-- 创建操作日志表
CREATE TABLE IF NOT EXISTS app_tank_plan_operation_log (
    operation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_master_id INTEGER NOT NULL,
    action VARCHAR(20) NOT NULL CHECK (action IN ('Uploaded', 'Created', 'Updated', 'Exported', 'Deleted')),
    user_name VARCHAR(50) NOT NULL,
    create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    FOREIGN KEY (plan_master_id) REFERENCES app_tank_plan_master(plan_master_id)
);

-- 创建索引
CREATE INDEX idx_plan_version ON app_tank_plan_master(plan_version);
CREATE INDEX idx_plan_type ON app_tank_plan_master(plan_type);
CREATE INDEX idx_plan_master_id ON app_tank_plan_detail(plan_master_id);
CREATE INDEX idx_tank ON app_tank_plan_detail(tank);
CREATE INDEX IF NOT EXISTS idx_history_plan_master_id ON app_tank_plan_history(plan_master_id);
CREATE INDEX IF NOT EXISTS idx_history_plan_row_id ON app_tank_plan_history(plan_row_id);
CREATE INDEX IF NOT EXISTS idx_history_create_timestamp ON app_tank_plan_history(create_timestamp);
CREATE INDEX IF NOT EXISTS idx_operation_plan_master_id ON app_tank_plan_operation_log(plan_master_id);
CREATE INDEX IF NOT EXISTS idx_operation_create_timestamp ON app_tank_plan_operation_log(create_timestamp);

-- 导入测试数据（如果存在）
.print 'Checking for test data files...'

.print 'Attempting to import master test data...'
.read test_master_data.sql

.print 'Attempting to import detail test data...'
.read test_detail_data.sql

.print 'Attempting to import history test data...'
.read test_history_data.sql

.print 'Attempting to import operation log test data...'
.read test_operation_data.sql

.print 'Database initialization completed.'