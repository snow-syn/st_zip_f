-- Tank Plan Operation Log Test Data
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (1, 1, 
                     'Created', 'Mike',
                     'Weekly plan 2023-11-29 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (2, 2, 
                     'Uploaded', 'Emma',
                     'Long-term plan 2023-11-30 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (3, 3, 
                     'Created', 'Kate',
                     'Weekly plan 2023-12-06 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (4, 4, 
                     'Updated', 'Emma',
                     'Weekly plan 2023-12-06 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (5, 4, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2023-12-06');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (6, 5, 
                     'Created', 'Sarah',
                     'Weekly plan 2023-12-13 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (7, 6, 
                     'Created', 'Bob',
                     'Weekly plan 2023-12-20 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (8, 6, 
                     'Exported', 'Bob',
                     'Exported Weekly plan 2023-12-20');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (9, 7, 
                     'Updated', 'Kate',
                     'Weekly plan 2023-12-20 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (10, 8, 
                     'Created', 'David',
                     'Weekly plan 2023-12-27 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (11, 9, 
                     'Uploaded', 'Kate',
                     'Long-term plan 2023-12-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (12, 10, 
                     'Updated', 'Tom',
                     'Long-term plan 2023-12-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (13, 11, 
                     'Updated', 'Kate',
                     'Long-term plan 2023-12-31 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (14, 12, 
                     'Created', 'David',
                     'Weekly plan 2024-01-03 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (15, 13, 
                     'Created', 'Mike',
                     'Weekly plan 2024-01-10 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (16, 14, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-01-10 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (17, 15, 
                     'Created', 'John',
                     'Weekly plan 2024-01-17 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (18, 16, 
                     'Created', 'David',
                     'Weekly plan 2024-01-24 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (19, 17, 
                     'Updated', 'David',
                     'Weekly plan 2024-01-24 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (20, 17, 
                     'Exported', 'David',
                     'Exported Weekly plan 2024-01-24');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (21, 18, 
                     'Updated', 'Mike',
                     'Weekly plan 2024-01-24 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (22, 19, 
                     'Created', 'David',
                     'Weekly plan 2024-01-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (23, 20, 
                     'Updated', 'Mike',
                     'Weekly plan 2024-01-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (24, 21, 
                     'Uploaded', 'Emma',
                     'Long-term plan 2024-01-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (25, 22, 
                     'Updated', 'Sarah',
                     'Long-term plan 2024-01-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (26, 23, 
                     'Updated', 'John',
                     'Long-term plan 2024-01-31 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (27, 24, 
                     'Created', 'Bob',
                     'Weekly plan 2024-02-07 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (28, 25, 
                     'Updated', 'Tom',
                     'Weekly plan 2024-02-07 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (29, 26, 
                     'Created', 'Emma',
                     'Weekly plan 2024-02-14 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (30, 26, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-02-14');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (31, 27, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-02-14 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (32, 28, 
                     'Created', 'Mary',
                     'Weekly plan 2024-02-21 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (33, 29, 
                     'Created', 'Sarah',
                     'Weekly plan 2024-02-28 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (34, 30, 
                     'Uploaded', 'Kate',
                     'Long-term plan 2024-02-29 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (35, 31, 
                     'Updated', 'Emma',
                     'Long-term plan 2024-02-29 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (36, 31, 
                     'Exported', 'Emma',
                     'Exported Long-term plan 2024-02-29');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (37, 32, 
                     'Created', 'Emma',
                     'Weekly plan 2024-03-06 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (38, 32, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-03-06');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (39, 33, 
                     'Updated', 'Sarah',
                     'Weekly plan 2024-03-06 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (40, 34, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-03-06 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (41, 34, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-03-06');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (42, 35, 
                     'Created', 'Kate',
                     'Weekly plan 2024-03-13 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (43, 36, 
                     'Created', 'Kate',
                     'Weekly plan 2024-03-20 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (44, 37, 
                     'Created', 'David',
                     'Weekly plan 2024-03-27 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (45, 37, 
                     'Exported', 'David',
                     'Exported Weekly plan 2024-03-27');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (46, 38, 
                     'Updated', 'Alice',
                     'Weekly plan 2024-03-27 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (47, 39, 
                     'Uploaded', 'Mary',
                     'Long-term plan 2024-03-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (48, 40, 
                     'Updated', 'Kate',
                     'Long-term plan 2024-03-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (49, 41, 
                     'Created', 'Tom',
                     'Weekly plan 2024-04-03 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (50, 42, 
                     'Updated', 'Sarah',
                     'Weekly plan 2024-04-03 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (51, 43, 
                     'Updated', 'Alice',
                     'Weekly plan 2024-04-03 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (52, 44, 
                     'Created', 'Alice',
                     'Weekly plan 2024-04-10 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (53, 44, 
                     'Exported', 'Alice',
                     'Exported Weekly plan 2024-04-10');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (54, 45, 
                     'Updated', 'Tom',
                     'Weekly plan 2024-04-10 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (55, 45, 
                     'Exported', 'Tom',
                     'Exported Weekly plan 2024-04-10');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (56, 46, 
                     'Created', 'Alice',
                     'Weekly plan 2024-04-17 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (57, 47, 
                     'Created', 'Alice',
                     'Weekly plan 2024-04-24 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (58, 48, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-04-24 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (59, 48, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-04-24');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (60, 49, 
                     'Uploaded', 'Kate',
                     'Long-term plan 2024-04-30 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (61, 50, 
                     'Created', 'Mary',
                     'Weekly plan 2024-05-01 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (62, 51, 
                     'Updated', 'Kate',
                     'Weekly plan 2024-05-01 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (63, 51, 
                     'Exported', 'Kate',
                     'Exported Weekly plan 2024-05-01');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (64, 52, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-05-01 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (65, 53, 
                     'Created', 'Sarah',
                     'Weekly plan 2024-05-08 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (66, 53, 
                     'Exported', 'Sarah',
                     'Exported Weekly plan 2024-05-08');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (67, 54, 
                     'Created', 'Kate',
                     'Weekly plan 2024-05-15 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (68, 54, 
                     'Exported', 'Kate',
                     'Exported Weekly plan 2024-05-15');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (69, 55, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-05-15 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (70, 56, 
                     'Created', 'Bob',
                     'Weekly plan 2024-05-22 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (71, 57, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-05-22 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (72, 57, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-05-22');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (73, 58, 
                     'Updated', 'Sarah',
                     'Weekly plan 2024-05-22 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (74, 59, 
                     'Created', 'John',
                     'Weekly plan 2024-05-29 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (75, 60, 
                     'Updated', 'Kate',
                     'Weekly plan 2024-05-29 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (76, 60, 
                     'Exported', 'Kate',
                     'Exported Weekly plan 2024-05-29');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (77, 61, 
                     'Updated', 'Bob',
                     'Weekly plan 2024-05-29 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (78, 62, 
                     'Uploaded', 'Tom',
                     'Long-term plan 2024-05-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (79, 63, 
                     'Updated', 'Emma',
                     'Long-term plan 2024-05-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (80, 64, 
                     'Created', 'Emma',
                     'Weekly plan 2024-06-05 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (81, 64, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-06-05');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (82, 65, 
                     'Created', 'Mike',
                     'Weekly plan 2024-06-12 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (83, 66, 
                     'Created', 'Mary',
                     'Weekly plan 2024-06-19 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (84, 67, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-06-19 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (85, 68, 
                     'Created', 'Tom',
                     'Weekly plan 2024-06-26 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (86, 68, 
                     'Exported', 'Tom',
                     'Exported Weekly plan 2024-06-26');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (87, 69, 
                     'Updated', 'John',
                     'Weekly plan 2024-06-26 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (88, 70, 
                     'Uploaded', 'Tom',
                     'Long-term plan 2024-06-30 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (89, 71, 
                     'Updated', 'Kate',
                     'Long-term plan 2024-06-30 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (90, 72, 
                     'Updated', 'Emma',
                     'Long-term plan 2024-06-30 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (91, 73, 
                     'Created', 'Tom',
                     'Weekly plan 2024-07-03 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (92, 73, 
                     'Exported', 'Tom',
                     'Exported Weekly plan 2024-07-03');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (93, 74, 
                     'Updated', 'Alice',
                     'Weekly plan 2024-07-03 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (94, 74, 
                     'Exported', 'Alice',
                     'Exported Weekly plan 2024-07-03');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (95, 75, 
                     'Created', 'Mike',
                     'Weekly plan 2024-07-10 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (96, 75, 
                     'Exported', 'Mike',
                     'Exported Weekly plan 2024-07-10');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (97, 76, 
                     'Updated', 'Bob',
                     'Weekly plan 2024-07-10 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (98, 77, 
                     'Created', 'Mary',
                     'Weekly plan 2024-07-17 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (99, 78, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-07-17 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (100, 79, 
                     'Updated', 'Kate',
                     'Weekly plan 2024-07-17 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (101, 80, 
                     'Created', 'Kate',
                     'Weekly plan 2024-07-24 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (102, 81, 
                     'Updated', 'David',
                     'Weekly plan 2024-07-24 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (103, 81, 
                     'Exported', 'David',
                     'Exported Weekly plan 2024-07-24');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (104, 82, 
                     'Created', 'Mary',
                     'Weekly plan 2024-07-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (105, 82, 
                     'Exported', 'Mary',
                     'Exported Weekly plan 2024-07-31');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (106, 83, 
                     'Uploaded', 'Sarah',
                     'Long-term plan 2024-07-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (107, 84, 
                     'Updated', 'Emma',
                     'Long-term plan 2024-07-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (108, 85, 
                     'Created', 'Mary',
                     'Weekly plan 2024-08-07 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (109, 86, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-08-07 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (110, 87, 
                     'Created', 'Mike',
                     'Weekly plan 2024-08-14 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (111, 88, 
                     'Created', 'Sarah',
                     'Weekly plan 2024-08-21 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (112, 89, 
                     'Created', 'Mike',
                     'Weekly plan 2024-08-28 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (113, 90, 
                     'Updated', 'Sarah',
                     'Weekly plan 2024-08-28 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (114, 90, 
                     'Exported', 'Sarah',
                     'Exported Weekly plan 2024-08-28');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (115, 91, 
                     'Updated', 'Alice',
                     'Weekly plan 2024-08-28 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (116, 91, 
                     'Exported', 'Alice',
                     'Exported Weekly plan 2024-08-28');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (117, 92, 
                     'Uploaded', 'Kate',
                     'Long-term plan 2024-08-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (118, 93, 
                     'Created', 'Mike',
                     'Weekly plan 2024-09-04 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (119, 94, 
                     'Updated', 'David',
                     'Weekly plan 2024-09-04 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (120, 95, 
                     'Updated', 'Mike',
                     'Weekly plan 2024-09-04 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (121, 96, 
                     'Created', 'David',
                     'Weekly plan 2024-09-11 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (122, 97, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-09-11 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (123, 97, 
                     'Exported', 'Mary',
                     'Exported Weekly plan 2024-09-11');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (124, 98, 
                     'Updated', 'Emma',
                     'Weekly plan 2024-09-11 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (125, 99, 
                     'Created', 'Bob',
                     'Weekly plan 2024-09-18 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (126, 100, 
                     'Updated', 'Kate',
                     'Weekly plan 2024-09-18 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (127, 101, 
                     'Created', 'Alice',
                     'Weekly plan 2024-09-25 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (128, 101, 
                     'Exported', 'Alice',
                     'Exported Weekly plan 2024-09-25');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (129, 102, 
                     'Uploaded', 'Mary',
                     'Long-term plan 2024-09-30 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (130, 103, 
                     'Updated', 'Bob',
                     'Long-term plan 2024-09-30 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (131, 104, 
                     'Updated', 'Tom',
                     'Long-term plan 2024-09-30 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (132, 104, 
                     'Exported', 'Tom',
                     'Exported Long-term plan 2024-09-30');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (133, 105, 
                     'Created', 'Mike',
                     'Weekly plan 2024-10-02 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (134, 106, 
                     'Updated', 'Sarah',
                     'Weekly plan 2024-10-02 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (135, 107, 
                     'Created', 'David',
                     'Weekly plan 2024-10-09 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (136, 108, 
                     'Created', 'Sarah',
                     'Weekly plan 2024-10-16 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (137, 108, 
                     'Exported', 'Sarah',
                     'Exported Weekly plan 2024-10-16');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (138, 109, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-10-16 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (139, 110, 
                     'Created', 'Bob',
                     'Weekly plan 2024-10-23 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (140, 111, 
                     'Updated', 'Mike',
                     'Weekly plan 2024-10-23 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (141, 111, 
                     'Exported', 'Mike',
                     'Exported Weekly plan 2024-10-23');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (142, 112, 
                     'Updated', 'Mary',
                     'Weekly plan 2024-10-23 updated to version 3');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (143, 113, 
                     'Created', 'Bob',
                     'Weekly plan 2024-10-30 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (144, 114, 
                     'Updated', 'Alice',
                     'Weekly plan 2024-10-30 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (145, 115, 
                     'Uploaded', 'Kate',
                     'Long-term plan 2024-10-31 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (146, 115, 
                     'Exported', 'Kate',
                     'Exported Long-term plan 2024-10-31');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (147, 116, 
                     'Updated', 'Alice',
                     'Long-term plan 2024-10-31 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (148, 116, 
                     'Exported', 'Alice',
                     'Exported Long-term plan 2024-10-31');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (149, 117, 
                     'Created', 'Kate',
                     'Weekly plan 2024-11-06 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (150, 118, 
                     'Created', 'Bob',
                     'Weekly plan 2024-11-13 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (151, 118, 
                     'Exported', 'Bob',
                     'Exported Weekly plan 2024-11-13');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (152, 119, 
                     'Created', 'Emma',
                     'Weekly plan 2024-11-20 created');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (153, 119, 
                     'Exported', 'Emma',
                     'Exported Weekly plan 2024-11-20');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (154, 120, 
                     'Updated', 'Kate',
                     'Weekly plan 2024-11-20 updated to version 2');
INSERT INTO app_tank_plan_operation_log 
                    (operation_id, plan_master_id, action, user_name, details)
                    VALUES
                    (155, 121, 
                     'Updated', 'John',
                     'Weekly plan 2024-11-20 updated to version 3');
