#!/bin/bash

for dir in "app" "hooks"; do
    if [ -d "$dir" ]; then
        echo "Scanning directory: $dir"
        find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" \) | while read -r file; do
            echo "Processing: $file"
            
            temp_file=$(mktemp)
            
            # 删除单行注释和 React 注释
            sed -E '
                # 删除以 // 开头的单行注释，但保留 URL 中的 //
                s/([^:])\/\/.*$/\1/g
                s/^\/\/.*$//g
                
                # 删除 React 注释 {/* */}
                s/\{\/\*.*?\*\/\}//g
            ' "$file" > "$temp_file"
            
            mv "$temp_file" "$file"
        done
    else
        echo "Directory not found: $dir"
    fi
done

echo "Completed removing comments from TypeScript files in app and hooks directories"