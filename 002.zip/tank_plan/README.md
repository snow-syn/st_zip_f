# Excel Plan Management System

> An enterprise-level Excel plan data management platform built on Next.js 14, providing powerful data processing, tracking, and collaboration features.

<div align="center">

![Node.js Version](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)
![Next.js Version](https://img.shields.io/badge/next.js-14.0.0-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0.0-blue)

</div>

## 📋 Project Overview

This system focuses on enterprise-level plan data management, supporting:

- 📊 5-year long-term plan management
- 📈 18-month medium-term plan management
- 🔄 Real-time editing and data synchronization
- 🌐 English interface, internationalization-friendly

## 🎯 Core Features

### Data Management

- Excel file import/export
- Smart data validation
- Real-time collaborative editing
- Version control and tracking

### Plan Features

- **5-Year Long-term Plan**
  - Excel file data import
  - Smart warning alerts
  - Automated report generation
- **18-Month Medium-term Plan**
  - Historical version management
  - Row-level change tracking
  - Real-time data synchronization

### System Features

- 📨 Email notification system
- 📊 Data visualization
- 📱 Responsive interface design

## 🛠️ Technology Stack

### Frontend

- Next.js 14
- React 18
- TailwindCSS
- ShadCN UI
- React Table

### Backend

- Next.js API Routes
- SQLite
- Prisma ORM

- **Toolchain**
  - TypeScript
  - ESLint
  - Prettier

## 🚀 Quick Start

### Requirements

- Node.js ≥ 18.0.0
- pnpm ≥ 8.0.0

### Installation & Deployment

1. **Clone Project**

```bash
git clone https://github.com/your-username/excel-management-system.git
cd excel-management-system
```

2. **Install Dependencies**

```bash
pnpm install
```

3. **Environment Configuration**

```bash
cp .env.example .env.local
```

Configure necessary environment variables:

```env
# Database Configuration
DATABASE_URL="sqlite://./data.db"

# Email Service
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your-email@example.com
SMTP_PASS=your-password

# Application Configuration
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

4. **Start Development Server**

```bash
pnpm dev
```

## 📖 Detailed Documentation

- [Tank 5-Year Long-term Plan](./docs/Tank5Year.md)
- [Tank 18-Month Medium-term Plan](./docs/Tank18Month.md)
- [Tank 18-Month Medium-term Plan History Data List And Load Function](./docs/Tank18List.md)
- [Tank Change History](./docs/TankChangeHistory.md)
- [Tank Details](./docs/TankDetails.md)
