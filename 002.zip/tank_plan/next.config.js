/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: true,
  },
  // 添加端口配置
  serverOptions: {
    port: 8080,
  },
};

module.exports = nextConfig;
