# Tank 5-Year Long-term Plan Detailed Design

## 1. Overview

This module is designed for managing Tank 5-year long-term plan data, supporting Excel import/export, online editing, and version control.

## 2. Data Structure

### 2.1 Data Fields

```typescript
interface TankPlanData {
  plan_version: string;
  plan_type: string;
  plan_version_no: string;
  plan_row_id: string;
  tank: string;
  iso: string;
  glass_type: string;
  gen: string;
  RT: string;
  RC: string;
  platform: string;
  tank_life: string;
  last_tank_light_date: string;
  drain_date: string;
  repair_date: string;
  RTL_date: string;
  TL_date: string;
  GG_date: string;
  cold_idle: string;
  repair_LT: string;
  RTL_LT: string;
  TL_LT: string;
  remark_category: string;
  remark: string;
  create_timestamp: string;
  update_timestamp: string;
}
```

### 2.2 Date Format Fields

The following fields must conform to the `YYYY-MM-DD` format:

- plan_version
- last_tank_light_date
- drain_date
- repair_date
- RTL_date
- TL_date
- GG_date
- create_timestamp
- update_timestamp

## 3. Detailed Feature Design

### 3.1 Excel Import

#### Import Rules

- Supports `.xlsx`, `.xls`, and `.csv` formats only
- Only reads from `Sheet1` sheet
- Column names must exactly match data fields

#### Validation Logic

1. Column Name Completeness Check

   - Display error message for missing columns
   - Indicate specific missing column names
   - No error if column exists but content is empty

2. Date Format Validation

   - Check all date field formats
   - Display specific error row numbers and field names

3. Replace 'NULL' with Empty String

   - Replace all cells containing 'NULL' with empty strings

### 3.2 Data Table

#### Table Configuration

- Uses React Table component
- No pagination, displays all data in table
- Sorting disabled
- Fixed header always visible
- Automatic scrollbars
- Left-click drag to move table

#### Style Guidelines

- Excel-like styling
- Gray cell borders
- Compact layout
- Smaller font for column names to reduce table width, ellipsis for long names
- Minimum column width 32px

#### Interactive Features

- Double-click cell to edit
- Keyboard navigation support
- Copy/paste support
- Multi-column filtering

### 3.3 Data Saving

#### Version Control

- Version number format: `GB_YYYYMMDD`
- New version generated on each save

#### Data Validation

- Validate all date formats before saving
- Display specific error messages for validation failures

### 3.4 Excel Export

- Export format: `.xlsx`
- Export all data
- Maintain original format and headers

## 4. Technical Implementation

### Frontend Tech Stack

- React Table - Table component
- shadcn - UI components
- xlsx - Excel processing

## Tank 5-Year Plan UI/UX Design

### Interface Layout

#### 1. Main Layout Architecture

- Two-tier Responsive Layout:
  - Command Bar (Top)
    - Primary action buttons with clear visual hierarchy
    - Status indicators and notifications
  - Content Area (Main)
    - Context-aware display area (upload zone or data grid)
    - Maximized workspace utilization
    - Smooth state transitions
    - Data Grid Design:
      - Fixed semi-transparent header, always visible during scrolling
      - Integrated information panel as part of the table:
        - Displayed at the bottom of the table
        - Contains row count, filter count, edited row count
      - Adaptive height, maximizing available space
      - Elegant scrolling effects and shadow hints
    - Visual Hierarchy
      - Create depth using subtle shadows and spacing
      - Maintain clean and crisp visual aesthetics

#### 2. File Upload Interface

- Enterprise-grade upload zone:
  - Large drop target area with dynamic visual feedback
  - Upload methods:
    - Traditional button selection
    - Drag-and-drop with visual guides
  - Comprehensive file information:
    - Clear step-by-step instructions
      - Prepare Excel file
        - Prepare a Excel file with the required format
        - Ensure data is in 'Sheet1' worksheet
        - Verify all required columns are present and correctly named
        - Fill in data following the column format requirements
      - Upload & Edit
        - Drag & drop file or click upload button
        - System performs automatic format validation
        - Make any necessary edits directly in the interface
        - Re-upload if needed
      - Save
        - Click "Validate & Save" button
        - Review validation results and fix any errors
        - Click "Save" to commit changes
        - Confirm successful save notification
    - Real-time validation status
    - Progress tracking with speed indication

### Enhanced Interaction Design

#### 1. Data Grid Experience

- Professional Excel-like Operations:
  - Smart cell editing
    - Double-click to edit
    - Data validation while typing
  - Advanced keyboard navigation
    - Tab/Arrow keys navigation
- Intelligent Column Management:
  - Automatically adapts to different screen sizes
  - Efficient vertical space allocation
- Interaction Optimization
  - Full-screen scrolling support for table area
  - 60% opacity for fixed header
  - Smooth gradient effects during scrolling
  - Seamless integration of bottom information panel with table

#### 2. Smart Validation System

- Multi-level Validation:
  - Real-time field validation
    - Immediate format checking
    - Context-aware validation rules
    - Visual error indicators
  - Batch validation
    - Progress visualization
    - Detailed error reporting

### User Feedback System

#### 1. Interactive Feedback

- Visual Response System:
  - Micro-interactions
    - Button state animations
    - Loading indicators
    - Progress visualizations
  - Status Communications
    - Context-sensitive tooltips
    - Status badges
    - System notifications
- Result Communication:
  - Success/Error states
    - Toast notifications
    - Status banners
    - Confirmation dialogs
  - Progress tracking
    - Operation progress bars
    - Background task indicators
    - Completion notifications

#### 2. Error Management

- Hierarchical Error Handling:
  - Warning Level
    - Yellow indicators
    - Non-blocking notifications
  - Error Level
    - Red indicators
    - Blocking notifications
    - Guided resolution steps
  - Critical Level
    - Modal dialogs
    - Immediate attention required

### Performance Optimization

#### 2. Response Optimization

- UI Performance:
  - Component lazy loading
  - Throttle/Debounce implementation
  - Priority rendering

### Initial Interface State

- Displays file upload area only
- Provides two upload methods:
  1. Click button to select file
  2. Drag & drop file to designated area
- Shows operation guidelines:
  1. "Supported file formats: .xlsx, .xls, .csv"
  2. "System will read data from 'Sheet1' worksheet"
  3. "Please ensure column names match system requirements"
- Do not show Data table

### Post-Upload Interface State

After uploading a file:

- File upload area minimized to top
- Progress bar animation displayed
- Data table displayed
- Operation toolbar shows:
  1. "Upload another file" button to upload another file
  2. "Export to Excel" button
  3. "Validate Data & Save" button
- Import error messages displayed if any

### Data Validation & Save Process

1. After clicking "Validate Data & Save":
   - System checks all data formats:
     - Date format validation
     - Required field validation
   - Validation result dialog:
     - If errors found:
       - Displays specific errors (row numbers and fields)
       - Save button disabled
       - Provide cancel button or click outside to return to data table
     - If validation passes:
       - Shows "Data format valid" message
       - Displays save button
2. After clicking "Save":
   - Shows loading indicator
   - Success:
     - Displays success toast message (auto-dismiss after 3s)
     - Updates version number
   - Failure:
     - Shows error message
     - Provides retry option

### Export Functionality

- Click "Export to Excel":
  - Shows export progress indicator
  - Success:
    1. Displays success toast message (auto-dismiss after 3s)
    2. Initiates file download automatically
  - Failure:
    - Shows error message
    - Provides retry option

### User Interaction Flow

1. User enters page -> Shows upload interface with guidelines
2. User uploads file -> Processes data -> Displays table and operation buttons
3. Available actions:
   - Click "Upload another File" to restart upload process
   - Click "Validate Data" to check data format
   - Click "Save" after validation passes
   - Click "Export to Excel" to download current data

### State Transitions

- Initial State -> File Upload -> Data Display State
- Data Display State -> New Upload -> Restart Upload Process
- Data Display State -> Validate -> Save State

### Error Handling

- File format errors
- Data validation errors
- Network errors
- Server errors
  All errors display user-friendly messages with clear resolution steps

### Performance Considerations

- Large file handling (pagination for tables over 1000 rows)
- Optimized validation process
- Responsive design for all screen sizes
