'use client';

import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';

export default function TankDetails() {
  const router = useRouter();

  const modules = [
    {
      title: 'GB Plan',
      description: 'Upload GB planning data',
      href: '/tp_ui/gb-plan',
    },
    {
      title: '18MP',
      description: 'Manage 18-month medium-term planning',
      href: '/tp_ui/18mp',
    },
    {
      title: 'Plan List',
      description: 'View and manage planning history',
      href: '/tp_ui/plan-list',
    },
    {
      title: 'Tank Detail',
      description: 'View detailed tank information',
      href: '/tp_ui/tank-detail',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="mx-auto max-w-5xl space-y-12"
    >
      <div className="text-center">
        <h1 className="text-4xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
          Tank Plan UI
        </h1>
        <p className="mt-4 text-sm leading-6 text-slate-500 dark:text-slate-400">
          Welcome to the Tank Plan Management System. Select a module to begin.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        {modules.map(({ title, description, href }, index) => (
          <motion.div
            key={title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.35,
              delay: 0.15 + index * 0.1,
              ease: [0.4, 0, 0.2, 1],
            }}
            onClick={() => router.push(href)}
            className="group relative cursor-pointer overflow-hidden rounded-xl border border-slate-200/50 bg-white/40 p-6 backdrop-blur-sm transition-all hover:bg-white/60 hover:shadow-lg dark:border-slate-800/50 dark:bg-zinc-900/40 dark:hover:bg-zinc-900/60"
          >
            <div className="relative z-10">
              <h3 className="text-lg font-medium tracking-tight text-slate-900 dark:text-slate-100">
                {title}
              </h3>
              <div className="mt-3 text-sm text-slate-500 dark:text-slate-400">
                {description}
              </div>
            </div>

            <div className="absolute inset-0 bg-gradient-to-br from-slate-50/50 to-transparent opacity-0 transition-all duration-500 ease-out group-hover:opacity-100 dark:from-slate-800/50" />
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
