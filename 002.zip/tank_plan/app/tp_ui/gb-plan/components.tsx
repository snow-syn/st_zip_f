import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  Columns,
  FileText,
  Loader2,
  MousePointerClick,
  PenLine,
  Save,
  Table,
  Upload,
  WrenchIcon,
  History,
  X,
  CalendarRange,
} from 'lucide-react';
import { useEffect, useState } from 'react';

export const TransitionContainer = ({
  children,
  show,
  appear = false,
}: {
  children: React.ReactNode;
  show: boolean;
  appear?: boolean;
}) => {
  return (
    <div
      className={cn(
        'h-full transition-all duration-300',
        show
          ? 'animate-in fade-in-0 zoom-in-95'
          : 'animate-out fade-out-0 zoom-out-95',
        appear && 'opacity-0',
      )}
    >
      {children}
    </div>
  );
};

export const UploadZone = ({
  onFileSelect,
  onLoadLatest,
  isLoading,
  isLoadingLatest,
}: {
  onFileSelect: (file: File) => void;
  onLoadLatest: () => void;
  isLoading: boolean;
  isLoadingLatest: boolean;
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [appear, setAppear] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setAppear(false), 50);
    return () => clearTimeout(timer);
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) onFileSelect(file);
  };

  const importSteps = [
    { label: 'Reading file...', delay: 0 },
    { label: 'Validating format...', delay: 1000 },
    { label: 'Processing data...', delay: 2000 },
    { label: 'Checking fields...', delay: 3000 },
  ];

  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (isLoading) {
      let stepIndex = 0;
      const timers = importSteps.map((step, index) => {
        return setTimeout(() => {
          setCurrentStep(index);
        }, step.delay);
      });

      return () => {
        timers.forEach((timer) => clearTimeout(timer));
        setCurrentStep(0);
      };
    }
  }, [isLoading]);

  return (
    <TransitionContainer show={true} appear={appear}>
      <div className="flex h-full flex-col items-center justify-start">
        {/* Main upload area */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={cn(
            'relative w-full max-w-2xl rounded-xl border-2 border-dashed bg-card/50 transition-all duration-200',
            'before:absolute before:inset-0 before:rounded-xl before:bg-gradient-to-b before:from-muted/50 before:to-transparent before:opacity-50',
            isDragging
              ? 'scale-[0.99] border-primary bg-primary/5 before:opacity-0'
              : 'border-border/50 hover:border-border hover:bg-card/80',
            isLoading && 'pointer-events-none',
          )}
        >
          <div className="relative flex flex-col items-center gap-6 px-6 py-12">
            {/* Icon area with loading animation */}
            <div
              className={cn(
                'rounded-full p-6 ring-8 ring-background/50 transition-all duration-200',
                isDragging ? 'scale-110 bg-primary/20' : 'bg-primary/10',
              )}
            >
              {isLoading ? (
                <div className="relative">
                  <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  <div className="absolute inset-0 animate-pulse rounded-full bg-primary/10" />
                </div>
              ) : (
                <Upload className="h-10 w-10 text-primary" />
              )}
            </div>

            {/* Text area with loading states */}
            <div className="space-y-2 text-center">
              <h3 className="text-2xl font-semibold tracking-tight">
                {isLoading ? (
                  <span className="inline-flex items-center gap-3">
                    {importSteps[currentStep].label}
                    <span className="inline-flex gap-1">
                      {[...Array(3)].map((_, i) => (
                        <span
                          key={i}
                          className={cn(
                            'h-1 w-1 rounded-full bg-primary',
                            'animate-bounce',
                            { 'animation-delay-200': i === 1 },
                            { 'animation-delay-400': i === 2 },
                          )}
                        />
                      ))}
                    </span>
                  </span>
                ) : (
                  'Upload GB Excel File'
                )}
              </h3>
              <p className="text-base text-muted-foreground">
                {isDragging
                  ? 'Release to Upload'
                  : isLoading
                    ? 'Please wait while we process your file'
                    : 'Drag & drop file here, or click the button below'}
              </p>
            </div>

            {/* Progress indicator */}
            {isLoading && (
              <div className="w-full max-w-xs space-y-2">
                <div className="h-1 w-full overflow-hidden rounded-full bg-primary/10">
                  <div
                    className="h-full bg-primary transition-all duration-500"
                    style={{
                      width: `${((currentStep + 1) / importSteps.length) * 100}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Progress</span>
                  <span>
                    {Math.round(((currentStep + 1) / importSteps.length) * 100)}
                    %
                  </span>
                </div>
              </div>
            )}

            {!isLoading && (
              <div className="flex items-center gap-2">
                <label className="group cursor-pointer">
                  <div className="overflow-hidden rounded-lg">
                    <div
                      className={cn(
                        'relative inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground shadow-sm',
                        'before:absolute before:inset-0 before:bg-white before:opacity-0 before:transition-opacity hover:before:opacity-10',
                        'active:scale-95',
                        'transition-all duration-200',
                        isLoading && 'pointer-events-none opacity-70',
                      )}
                    >
                      <Upload className="h-4 w-4" />
                      Select File
                    </div>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept=".xlsx,.xls,.csv"
                    onChange={(e) =>
                      e.target.files?.[0] && onFileSelect(e.target.files[0])
                    }
                    disabled={isLoading}
                  />
                </label>

                <div className="mx-1.5 h-6 w-[1px] bg-border/50" />

                <button
                  onClick={onLoadLatest}
                  disabled={isLoading || isLoadingLatest}
                  className={cn(
                    'group relative inline-flex items-center gap-2 rounded-lg px-6 py-3 font-medium',
                    'bg-card/60 text-muted-foreground shadow-sm ring-1 ring-border/50',
                    'hover:bg-card hover:text-foreground hover:ring-border',
                    'active:scale-95',
                    'transition-all duration-200',
                    (isLoading || isLoadingLatest) &&
                      'pointer-events-none opacity-70',
                  )}
                >
                  <div className="relative">
                    {isLoadingLatest ? (
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    ) : (
                      <>
                        <History
                          className={cn(
                            'h-4 w-4 transition-transform duration-200',
                            'group-hover:rotate-[-30deg]',
                          )}
                        />
                        <div
                          className={cn(
                            'absolute inset-0 opacity-0 transition-opacity duration-200',
                            'group-hover:opacity-100',
                          )}
                        >
                          <div className="absolute inset-0 animate-ping rounded-full bg-primary/20" />
                        </div>
                      </>
                    )}
                  </div>
                  <span>
                    {isLoadingLatest ? 'Loading...' : 'Load Latest Plan'}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>

        {!isLoading && (
          <div className="mt-8 grid grid-cols-3 gap-6">
            {[
              {
                step: '1',
                title: 'Prepare',
                icon: FileText,
                desc: 'Prepare Excel file',
                steps: [
                  'Use worksheet "sheet1"',
                  'Match required columns',
                  'Fill in data correctly',
                ],
                color: 'from-blue-500/5 to-blue-500/0',
                iconColor: 'text-blue-500',
                iconBg: 'bg-blue-500/10',
                ringColor: 'ring-blue-500/10',
              },
              {
                step: '2',
                title: 'Import',
                icon: Upload,
                desc: 'Import Excel file',
                steps: ['Drop or click to Import', 'Review any issues'],
                color: 'from-violet-500/5 to-violet-500/0',
                iconColor: 'text-violet-500',
                iconBg: 'bg-violet-500/10',
                ringColor: 'ring-violet-500/10',
              },
              {
                step: '3',
                title: 'Save',
                icon: Save,
                desc: 'Save the data',
                steps: ['Validate the data', 'Fix if needed', 'Save & Notify'],
                color: 'from-emerald-500/5 to-emerald-500/0',
                iconColor: 'text-emerald-500',
                iconBg: 'bg-emerald-500/10',
                ringColor: 'ring-emerald-500/10',
              },
            ].map(
              ({
                step,
                title,
                icon: Icon,
                desc,
                steps,
                color,
                iconColor,
                iconBg,
                ringColor,
              }) => (
                <div
                  key={step}
                  className={cn(
                    'group relative overflow-hidden rounded-xl border shadow-sm',
                    'bg-gradient-to-b from-card to-card/50',
                    'transition duration-300 hover:shadow-md',
                    'dark:shadow-none',
                  )}
                >
                  {/* Hover effect gradient */}
                  <div
                    className={cn(
                      'absolute inset-0 bg-gradient-to-b opacity-0 transition-opacity duration-300',
                      'group-hover:opacity-100',
                      color,
                    )}
                  />

                  {/* Content */}
                  <div className="relative p-5">
                    {/* Header */}
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                          'transition-all duration-300 group-hover:scale-110',
                          'ring-2 ring-offset-2 ring-offset-background',
                          iconBg,
                          ringColor,
                        )}
                      >
                        <Icon className={cn('h-5 w-5', iconColor)} />
                      </div>
                      <div>
                        <h4 className="flex items-center gap-2 text-lg font-semibold tracking-tight">
                          {title}
                        </h4>
                        <p className="mt-1.5 text-sm text-muted-foreground">
                          {desc}
                        </p>
                      </div>
                    </div>

                    {/* Steps - 优化的列表样式 */}
                    <div className="mt-4 space-y-2 pl-8">
                      {steps.map((text, index) => (
                        <div
                          key={index}
                          className={cn(
                            'relative flex items-center gap-3',
                            'text-sm text-muted-foreground',
                          )}
                        >
                          <div
                            className={cn(
                              'h-1.5 w-1.5 shrink-0 rounded-full',
                              'bg-muted-foreground/30',
                              'group-hover:bg-muted-foreground/50',
                            )}
                          />
                          <span>{text}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ),
            )}
          </div>
        )}
      </div>
    </TransitionContainer>
  );
};

export const ErrorDisplay = ({ errors }: { errors: string[] }) => {
  const [show, setShow] = useState(true);

  useEffect(() => {
    if (errors.length > 0) {
      setShow(true);
    }
  }, [errors]);

  if (!errors.length || !show) return null;

  return (
    <div className="fixed left-1/2 top-6 z-50 -translate-x-1/2">
      <div
        className={cn(
          'w-[600px] rounded-lg',
          'border border-destructive/30',
          'bg-destructive/5 backdrop-blur-lg',
          'shadow-lg',
          'duration-300 animate-in slide-in-from-top-4',
          'supports-[backdrop-filter]:bg-destructive/[0.03]',
        )}
      >
        <div className="relative p-4">
          {/* 关闭按钮 */}
          <button
            onClick={() => setShow(false)}
            className={cn(
              'absolute right-2 top-2',
              'rounded-md p-1',
              'text-destructive/50 hover:text-destructive',
              'transition-colors duration-200',
            )}
          >
            <X className="h-4 w-4" />
          </button>

          {/* 标题 */}
          <div className="flex items-center gap-2">
            <div className="rounded-full bg-destructive/10 p-1">
              <AlertCircle className="h-4 w-4 text-destructive" />
            </div>
            <h4 className="font-medium text-destructive">
              Import Validation Failed
            </h4>
          </div>

          {/* 错误列表 */}
          <ScrollArea
            className={cn(
              'mt-3 max-h-[240px] pr-4',
              'scrollbar-thin scrollbar-track-destructive/5 scrollbar-thumb-destructive/20',
            )}
          >
            <ul className="space-y-2 pl-6 text-sm text-destructive/90">
              {errors.map((error, index) => (
                <li
                  key={index}
                  className={cn(
                    'list-disc leading-relaxed',
                    'animate-in fade-in slide-in-from-bottom-1',
                    'duration-300',
                  )}
                >
                  {error}
                </li>
              ))}
            </ul>
          </ScrollArea>

          {/* 提示信息 */}
          <div className="mt-3 flex items-center justify-between border-t border-destructive/10 pt-3 text-xs text-destructive/70">
            <div>
              {errors.length} {errors.length === 1 ? 'error' : 'errors'} found
            </div>
            <div>Please fix the errors and try again</div>
          </div>
        </div>
      </div>
    </div>
  );
};
