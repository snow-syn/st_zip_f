import { read, utils, write, type WorkSheet } from 'xlsx';
import type { TankPlanData, ExcelProcessResult } from './types';
import {
  COLUMNS,
  getExcelHeaders,
  getExcelHeaderMap,
  validateField,
} from './config';
import { DateUtils, DataUtils } from './utils';

// 添加错误类型定义
export type ProcessingErrorCode =
  | 'MISSING_HEADERS'
  | 'MISSING_COLUMNS'
  | 'INVALID_SHEET'
  | 'EMPTY_FILE'
  | 'ROW_ERROR';

export class ExcelProcessingError extends Error {
  constructor(
    message: string,
    public code: ProcessingErrorCode,
  ) {
    super(message);
    this.name = 'ExcelProcessingError';
  }
}

export class ExcelProcessor {
  private static validateWorksheet(worksheet: WorkSheet): string[] {
    const errors: string[] = [];

    try {
      const headers = utils.sheet_to_json(worksheet, {
        header: 1,
      })[0] as string[];

      if (!headers?.length) {
        throw new ExcelProcessingError(
          'Excel file is missing headers',
          'MISSING_HEADERS',
        );
      }

      // 使用 excelHeader 进行匹配
      const requiredHeaders = getExcelHeaders();
      const missingHeaders = requiredHeaders.filter(
        (header) => !headers.includes(header),
      );

      if (missingHeaders.length) {
        throw new ExcelProcessingError(
          `Excel file is missing required columns: ${missingHeaders.join(', ')}`,
          'MISSING_COLUMNS',
        );
      }
    } catch (error) {
      if (error instanceof ExcelProcessingError) {
        errors.push(error.message);
      } else {
        errors.push('Error validating worksheet structure');
      }
    }

    return errors;
  }

  private static processRow(rawRow: Record<string, unknown>): TankPlanData {
    if (!rawRow || typeof rawRow !== 'object') {
      throw new Error('Invalid row data');
    }

    // 初始化所有字段为空字符串
    const processedRow = Object.keys(COLUMNS).reduce((acc, key) => {
      acc[key as keyof TankPlanData] = '';
      return acc;
    }, {} as TankPlanData);

    // 获取 Excel 列名到内部 key 的映射
    const headerMap = getExcelHeaderMap();

    // 遍历每个 Excel 列名，将数据映射到对应的内部 key
    Object.entries(rawRow).forEach(([excelHeader, value]) => {
      const internalKey = headerMap.get(excelHeader);
      if (internalKey) {
        const column = COLUMNS[internalKey];
        let processedValue = DataUtils.cleanString(value);

        // 处理日期字段
        if (column.type === 'date' && processedValue) {
          processedValue = DateUtils.format(processedValue);
          if (!processedValue) {
            throw new Error(
              `Invalid date format for ${column.label}: ${value}`,
            );
          }
        }

        processedRow[internalKey as keyof TankPlanData] = processedValue;
      }
    });

    return processedRow;
  }

  private static validateRow(row: TankPlanData, rowIndex: number): string[] {
    const errors: string[] = [];
    const rowNum = rowIndex + 1;

    try {
      // 验证每个字段
      Object.entries(COLUMNS).forEach(([key, column]) => {
        if (!column.validation) return;

        const value = row[key as keyof TankPlanData];
        const error = validateField(value, column);
        if (error) {
          errors.push(`Row ${rowNum}: ${error}`);
        }
      });

      // 验证日期字段的顺序（如果需要）
      if (row.drain && row.start) {
        const drainDate = new Date(row.drain);
        const startDate = new Date(row.start);
        if (drainDate > startDate) {
          errors.push(`Row ${rowNum}: Drain date must be before Start date`);
        }
      }
    } catch (error) {
      errors.push(
        `Row ${rowNum} validation failed: ${
          error instanceof Error ? error.message : 'Unknown error'
        }`,
      );
    }

    return errors;
  }

  static async processExcelFile(file: File): Promise<ExcelProcessResult> {
    const result: ExcelProcessResult = { data: [], errors: [] };

    try {
      // 读取工作簿
      const workbook = read(await file.arrayBuffer());

      // 验证工作表
      if (!workbook.SheetNames.includes('sheet1')) {
        throw new ExcelProcessingError(
          'Excel file must contain sheet1 worksheet',
          'INVALID_SHEET',
        );
      }

      const worksheet = workbook.Sheets['sheet1'];
      const worksheetErrors = this.validateWorksheet(worksheet);

      if (worksheetErrors.length) {
        return { ...result, errors: worksheetErrors };
      }

      // 转换数据
      const jsonData = utils.sheet_to_json(worksheet, {
        raw: false, // 确保所有值都是字符串
        defval: '', // 空单元格使用空字符串
      });

      if (!jsonData.length) {
        throw new ExcelProcessingError(
          'Excel file is empty or invalid',
          'EMPTY_FILE',
        );
      }

      // 处理每一行数据
      for (let i = 0; i < jsonData.length; i++) {
        try {
          const processedRow = this.processRow(
            jsonData[i] as Record<string, unknown>,
          );
          const rowErrors = this.validateRow(processedRow, i);

          if (rowErrors.length === 0) {
            result.data.push(processedRow);
          } else {
            result.errors.push(...rowErrors);
          }
        } catch (error) {
          result.errors.push(
            `Error processing row ${i + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`,
          );
        }
      }

      return result;
    } catch (error) {
      if (error instanceof ExcelProcessingError) {
        throw error;
      }
      throw new Error(
        `Excel import failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      );
    }
  }

  static async exportToExcel(data: TankPlanData[]): Promise<Blob> {
    try {
      const workbook = utils.book_new();

      // 使用 Excel 列名作为表头
      const headers = getExcelHeaders();

      // 准备数据，使用 Excel 列名
      const rows = data.map((row) => {
        return headers.map((excelHeader) => {
          const internalKey = getExcelHeaderMap().get(excelHeader);
          if (!internalKey) return '';

          const value = row[internalKey as keyof TankPlanData];
          const column = COLUMNS[internalKey];

          // 对日期字段进行特殊处理
          if (column.type === 'date' && value) {
            return DateUtils.format(value) || ''; // 确保格式化失败时返回空字符串
          }
          return value || '';
        });
      });

      // 创建工作表数据（含表头）
      const wsData = [headers, ...rows];
      const worksheet = utils.aoa_to_sheet(wsData);

      // 设置列宽
      const colWidths = headers.map((header) => ({
        wch: Math.max(
          header.length,
          ...rows.map(
            (row) => String(row[headers.indexOf(header)] || '').length,
          ),
          15, // 最小列宽
        ),
      }));

      worksheet['!cols'] = colWidths;

      // 设置单元格样式
      const range = utils.decode_range(worksheet['!ref'] || 'A1');
      for (let R = range.s.r; R <= range.e.r; R++) {
        for (let C = range.s.c; C <= range.e.c; C++) {
          const cell_address = utils.encode_cell({ r: R, c: C });
          const cell = worksheet[cell_address];

          if (!cell) continue;

          // 设置单元格格式
          cell.s = {
            font: { name: 'Arial', sz: 11 },
            alignment: {
              vertical: 'center',
              horizontal: R === 0 ? 'center' : 'left',
              wrapText: true,
            },
            border: {
              top: { style: 'thin' },
              bottom: { style: 'thin' },
              left: { style: 'thin' },
              right: { style: 'thin' },
            },
          };

          // 表头样式
          if (R === 0) {
            cell.s = {
              ...cell.s,
              font: {
                name: 'Arial',
                sz: 11,
                bold: true,
                color: { rgb: '000000' },
              },
              fill: {
                fgColor: { rgb: 'F3F4F6' },
              },
            };
          }
        }
      }

      // 将工作表添加到工作簿
      utils.book_append_sheet(workbook, worksheet, 'sheet1');

      // 修改导出文件名
      const fileName = `GB_Plan_${new Date().toISOString().split('T')[0]}.xlsx`;
      const excelBuffer = write(workbook, {
        bookType: 'xlsx',
        type: 'array',
        cellStyles: true,
      });

      // 转换为 Blob
      return new Blob([excelBuffer], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
    } catch (error) {
      throw new Error(
        `Excel export failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      );
    }
  }
}
