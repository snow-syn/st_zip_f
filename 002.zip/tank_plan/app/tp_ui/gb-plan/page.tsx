'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ErrorDisplay, UploadZone, TransitionContainer } from './components';
import { ExcelProcessor } from './excel-processor';
import type { TankPlanData } from './types';
import { cn } from '@/lib/utils';
import { Info, Save, Upload, FileDown, CalendarRange } from 'lucide-react';
import { DataTable } from './components/DataTable/DataTable';
import { useToast } from '@/hooks/use-toast';
import { Toaster } from '@/components/ui/toaster';
import { useExport } from './hooks/useExport';
import { ValidationDialog } from './components/ValidationDialog';
import { useValidation } from './hooks/useValidation';
import { useToasts } from './hooks/useToasts';
import { motion, AnimatePresence } from 'framer-motion';
import { DatabaseService } from './services/DatabaseService';
import { useLoadData } from './hooks/useLoadData';

const PageTransition = ({
  children,
  show,
}: {
  children: React.ReactNode;
  show: boolean;
}) => (
  <motion.div
    initial={false}
    animate={{
      opacity: show ? 1 : 0,
      y: show ? 0 : 10,
      scale: show ? 1 : 0.98,
    }}
    transition={{
      duration: 0.2,
      ease: [0.32, 0.72, 0, 1],
    }}
  >
    {children}
  </motion.div>
);

const ContentTransition = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 10, scale: 0.98 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    exit={{ opacity: 0, y: -10, scale: 0.98 }}
    transition={{
      duration: 0.2,
      ease: [0.32, 0.72, 0, 1],
    }}
  >
    {children}
  </motion.div>
);

export default function GBPlan() {
  const [data, setData] = useState<TankPlanData[]>([]);
  const [currentData, setCurrentData] = useState<TankPlanData[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showTable, setShowTable] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();
  const { handleExport, isExporting } = useExport(currentData);
  const [showValidateDialog, setShowValidateDialog] = useState(false);
  const {
    validationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
  } = useValidation();
  const { showSaveToast } = useToasts();
  const { loadLatestPlan, isLoading: isLoadingLatest } = useLoadData();

  const handleFileUpload = async (file: File) => {
    try {
      setIsLoading(true);
      setErrors([]);

      const { data: processedData, errors: importErrors } =
        await ExcelProcessor.processExcelFile(file);

      if (importErrors.length > 0) {
        setErrors(importErrors);
        if (processedData.length === 0) {
          return;
        }
      }

      if (importErrors.length === 0) {
        setIsTransitioning(true);
        await new Promise((resolve) => setTimeout(resolve, 150));

        setData(processedData);
        setCurrentData(processedData);

        requestAnimationFrame(() => {
          setShowTable(true);
          setTimeout(() => {
            setIsTransitioning(false);
          }, 50);
        });
      }
    } catch (err) {
      console.error('Excel import error:', err);
      setErrors((prev) => [
        ...prev,
        err instanceof Error ? err.message : 'Failed to import Excel file',
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSwitchToUpload = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setShowTable(false);
      setTimeout(() => {
        setIsTransitioning(false);
      }, 50);
    }, 150);
  };

  const handleSave = async () => {
    try {
      setShowValidateDialog(true);
      setIsValidating(true);
      setValidationErrors([]);

      // 重置验证步骤状态
      updateStepStatus('format', 'pending');
      updateStepStatus('required', 'pending');
      updateStepStatus('business', 'pending');
      updateStepStatus('save', 'pending');

      const errors = await validateData(currentData);

      if (errors.length > 0) {
        setValidationErrors(errors);
        return;
      }

      setIsValidating(false);
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to validate data',
      });
      setIsValidating(false);
    }
  };

  // 添加新的保存确认处理函数
  const handleConfirmSave = async () => {
    try {
      updateStepStatus('save', 'processing');
      setIsSaving(true);

      await new Promise((resolve) => setTimeout(resolve, 1000));

      updateStepStatus('save', 'success');
      showSaveToast('success', new Date().toLocaleTimeString());

      setTimeout(() => {
        setShowValidateDialog(false);
      }, 1000);
    } catch (error) {
      console.error('Save error:', error);
      updateStepStatus('save', 'error', 'Failed to save data');
      showSaveToast('error', new Date().toLocaleTimeString());
    } finally {
      setIsSaving(false);
    }
  };

  const handleLoadLatest = async () => {
    console.group('🔄 Load Latest Plan Flow');
    const startTime = performance.now();

    try {
      console.log('Starting load process...', {
        currentState: {
          hasData: data.length > 0,
          showTable,
          isTransitioning,
        },
      });

      setErrors([]);

      const result = await loadLatestPlan();
      console.log('Load result:', {
        success: result.success,
        dataLength: result.data?.length,
        error: result.error,
        debug: result.debug,
      });

      if (!result.success) {
        throw new Error(result.error);
      }

      setIsTransitioning(true);
      console.log('Starting transition...');
      await new Promise((resolve) => setTimeout(resolve, 150));

      setData(result.data!);
      setCurrentData(result.data!);
      console.log('Data updated', {
        rowCount: result.data!.length,
        sampleRow: result.data![0],
      });

      requestAnimationFrame(() => {
        setShowTable(true);
        console.log('Table visibility updated');

        setTimeout(() => {
          setIsTransitioning(false);
          console.log('Transition completed');
        }, 50);
      });

      toast({
        title: 'Data Loaded Successfully',
        description: `Loaded ${result.data!.length} rows from the latest plan`,
      });

      const totalTime = performance.now() - startTime;
      console.log('Load process completed', {
        totalTime: `${totalTime.toFixed(2)}ms`,
        finalState: {
          dataLength: result.data!.length,
          showTable,
          isTransitioning,
        },
      });
    } catch (err) {
      console.error('Load error:', {
        error: err,
        message: err instanceof Error ? err.message : 'Unknown error',
        stack: err instanceof Error ? err.stack : undefined,
      });

      setErrors((prev) => [
        ...prev,
        err instanceof Error ? err.message : 'Failed to load latest plan',
      ]);
    } finally {
      console.groupEnd();
    }
  };

  const ExportButton = ({
    onExport,
    isExporting,
    disabled,
  }: {
    onExport: () => Promise<void>;
    isExporting: boolean;
    disabled: boolean;
  }) => (
    <Button
      variant="outline"
      size="sm"
      onClick={onExport}
      disabled={disabled || isExporting}
    >
      <FileDown
        className={cn('mr-2 h-4 w-4', isExporting && 'animate-pulse')}
      />
      {isExporting ? 'Exporting...' : 'Export Excel'}
    </Button>
  );

  const SaveButton = () => (
    <Button
      variant="outline"
      size="sm"
      onClick={handleSave}
      disabled={isLoading || isTransitioning || isSaving || data.length === 0}
    >
      <Save className={cn('mr-2 h-4 w-4', isSaving && 'animate-pulse')} />
      {isSaving ? 'Saving...' : 'Validate & Save'}
    </Button>
  );

  const UploadButton = () => (
    <Button
      variant="outline"
      size="sm"
      onClick={handleSwitchToUpload}
      disabled={isLoading || isTransitioning}
    >
      <Upload className="mr-2 h-4 w-4" />
      Re-upload
    </Button>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="flex h-full flex-col"
    >
      <div className="min-h-0 flex-1">
        <ErrorDisplay errors={errors} />

        <PageTransition show={!isTransitioning}>
          <AnimatePresence mode="wait">
            {!showTable ? (
              <ContentTransition key="upload">
                <div className="h-full">
                  <div className="mb-6 px-6">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                        <CalendarRange className="h-4 w-4 text-primary" />
                      </div>
                      <h1 className="text-xl font-semibold tracking-tight">
                        GB Plan
                      </h1>
                    </div>
                  </div>

                  <UploadZone
                    onFileSelect={handleFileUpload}
                    onLoadLatest={handleLoadLatest}
                    isLoading={isLoading}
                    isLoadingLatest={isLoadingLatest}
                  />
                </div>
              </ContentTransition>
            ) : (
              <ContentTransition key="table">
                <div className="flex h-full flex-col gap-4">
                  <motion.div
                    className="flex-none"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2, duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between rounded-lg px-4 py-2">
                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                            <CalendarRange className="h-4 w-4 text-primary" />
                          </div>
                          <h1 className="text-xl font-semibold tracking-tight">
                            GB Plan
                          </h1>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Info className="h-4 w-4" />
                            {`${data.length} rows loaded`}
                          </div>
                          {errors.length > 0 && (
                            <>
                              <div className="h-4 w-[1px] bg-border/50" />
                              <div className="flex items-center gap-2 text-sm text-yellow-500">
                                <div className="h-1.5 w-1.5 rounded-full bg-yellow-500" />
                                {errors.length} warnings
                              </div>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <SaveButton />
                        <UploadButton />
                        <ExportButton
                          onExport={handleExport}
                          isExporting={isExporting}
                          disabled={isLoading || data.length === 0}
                        />
                      </div>
                    </div>
                  </motion.div>

                  <motion.div
                    className="min-h-0 flex-1 overflow-auto"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.2 }}
                  >
                    <DataTable
                      data={data}
                      errors={errors}
                      isTransitioning={isTransitioning}
                      onDataChange={setCurrentData}
                    />
                  </motion.div>
                </div>
              </ContentTransition>
            )}
          </AnimatePresence>
        </PageTransition>
      </div>

      <ValidationDialog
        open={showValidateDialog}
        onOpenChange={setShowValidateDialog}
        isValidating={isValidating}
        isSaving={isSaving}
        validationErrors={validationErrors}
        validationSteps={validationSteps}
        onConfirmSave={handleConfirmSave}
      />

      <Toaster />
    </motion.div>
  );
}
