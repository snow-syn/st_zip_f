import { useState } from 'react';
import type { TankPlanData } from '../types';
import { DatabaseService } from '../services/DatabaseService';
import { useToasts } from './useToasts';

interface LoadResult {
  success: boolean;
  data?: TankPlanData[];
  error?: string;
  debug?: {
    stage: string;
    details: unknown;
    queryTime?: number;
    transformTime?: number;
    rowCount?: number;
    timestamp?: string;
  };
}

export function useLoadData() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [debugInfo, setDebugInfo] = useState<Record<string, unknown>>({});
  const { showToast } = useToasts();

  const logDebug = (stage: string, details: unknown) => {
    console.group(`🔍 Load Debug - ${stage}`);
    console.log('Details:', details);
    console.groupEnd();

    setDebugInfo((prev) => ({
      ...prev,
      [stage]: details,
    }));
  };

  const handleError = (error: unknown, stage: string) => {
    const message = error instanceof Error ? error.message : 'Unknown error';
    logDebug(`Error-${stage}`, { error, message });
    setError(message);
    showToast('error', { message });
    return {
      success: false,
      error: message,
      debug: {
        stage,
        details: error,
      },
    } as const;
  };

  const validateResponse = (result: LoadResult): boolean => {
    const loadResult: LoadResult = {
      success: result.success,
      data: result.data,
      error: result.error,
      debug: result.debug && {
        stage: result.debug.stage || 'unknown',
        details: result.debug.details || {},
        queryTime: result.debug.queryTime,
        transformTime: result.debug.transformTime,
        rowCount: result.debug.rowCount,
        timestamp: result.debug.timestamp,
      },
    };

    logDebug('ValidateResponse', {
      success: loadResult.success,
      hasData: !!loadResult.data?.length,
      dataLength: loadResult.data?.length,
      error: loadResult.error,
    });

    if (!loadResult.success || !loadResult.data?.length) {
      const message = loadResult.error || 'No data available';
      setError(message);
      showToast('error', { message });
      return false;
    }
    return true;
  };

  const loadLatestPlan = async (): Promise<LoadResult> => {
    if (isLoading) {
      logDebug('LoadBlocked', { reason: 'Loading already in progress' });
      return {
        success: false,
        error: 'Loading in progress',
        debug: {
          stage: 'LoadBlocked',
          details: { isLoading },
        },
      };
    }

    try {
      setIsLoading(true);
      setError(null);
      logDebug('LoadStart', { timestamp: new Date().toISOString() });

      const result = await DatabaseService.getLatestPlanData();
      logDebug('DatabaseResponse', {
        success: result.success,
        dataLength: result.data?.length,
        error: result.error,
        timestamp: new Date().toISOString(),
        isMockData: process.env.NODE_ENV === 'development',
      });

      const normalizedResult: LoadResult = {
        ...result,
        debug: result.debug
          ? {
              stage: result.debug.stage || 'DatabaseResponse',
              details: result.debug.details || {},
              queryTime: result.debug.queryTime,
              transformTime: result.debug.transformTime,
              rowCount: result.debug.rowCount,
              timestamp: result.debug.timestamp,
            }
          : undefined,
      };

      if (!validateResponse(normalizedResult)) {
        return {
          success: false,
          error: result.error || 'No data available',
          debug: {
            stage: 'ValidationFailed',
            details: result,
          },
        };
      }

      // 数据完整性检查
      const dataIntegrityCheck = result.data?.every((row) => {
        const hasRequiredFields = ['tank', 'iso', 'glass_type'].every(
          (field) => row[field as keyof TankPlanData],
        );
        return hasRequiredFields;
      });

      logDebug('DataIntegrity', {
        passed: dataIntegrityCheck,
        sampleRow: result.data?.[0],
        totalRows: result.data?.length,
      });

      return {
        success: true,
        data: result.data,
        debug: {
          stage: 'LoadSuccess',
          details: {
            rowCount: result.data?.length,
            timestamp: new Date().toISOString(),
            integrityCheck: dataIntegrityCheck,
          },
        },
      };
    } catch (error) {
      return handleError(error, 'LoadFailed');
    } finally {
      setIsLoading(false);
      logDebug('LoadComplete', {
        timestamp: new Date().toISOString(),
        finalState: {
          error,
          debugInfo,
        },
      });
    }
  };

  return {
    loadLatestPlan,
    isLoading,
    error,
    clearError: () => setError(null),
    debugInfo,
  } as const;
}
