import { useState } from 'react';
import { ExcelProcessor } from '../excel-processor';
import type { TankPlanData } from '../types';
import { useToasts } from './useToasts';

export function useExport(data: TankPlanData[]) {
  const [isExporting, setIsExporting] = useState(false);
  const { showExportToast } = useToasts();

  const downloadFile = async (blob: Blob, fileName: string) => {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');

    try {
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
    } finally {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    }
  };

  const handleExport = async () => {
    if (isExporting || data.length === 0) return;

    try {
      setIsExporting(true);
      const fileName = `GB_Plan_${new Date().toISOString().split('T')[0]}.xlsx`;
      const blob = await ExcelProcessor.exportToExcel(data);

      await downloadFile(blob, fileName);

      showExportToast('success', {
        fileName,
        rowCount: data.length,
      });
    } catch (error) {
      console.error('Export error:', error);
      showExportToast('error', {
        message: 'Export failed. Please try again.',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return {
    handleExport,
    isExporting,
  } as const;
}
