import { useState } from 'react';
import type { TankPlanData } from '../types';
import { DatabaseService } from '../services/DatabaseService';
import { useToasts } from './useToasts';

export function useSaveData() {
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const { showToast } = useToasts();

  const saveData = async (data: TankPlanData[]) => {
    if (isSaving || !data.length) return false;

    try {
      setIsSaving(true);
      setErrors([]);

      const result = await DatabaseService.savePlanData(data);

      if (result.success) {
        showToast('success', {
          timestamp: new Date().toLocaleTimeString(),
        });
        return true;
      }

      const newErrors = result.errors || [result.error || 'Save failed'];
      setErrors(newErrors);
      showToast('error', { message: newErrors[0] });
      return false;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      setErrors([message]);
      showToast('error', { message });
      return false;
    } finally {
      setIsSaving(false);
    }
  };

  return { saveData, isSaving, errors } as const;
}
