import * as React from 'react';
import { useToast } from '@/hooks/use-toast';
import { BaseToast } from '../components/Toast';
import {
  toastStyles,
  ToastType,
  type ToastParams,
} from '../components/Toast/config';

export function useToasts() {
  const { toast } = useToast();

  const showToast = React.useCallback(
    (type: ToastType, params?: ToastParams) => {
      toast({
        description: <BaseToast type={type} params={params} />,
        className: toastStyles[type].className,
        duration: toastStyles[type].duration,
      });
    },
    [toast],
  );

  return {
    showToast,
    showSaveToast: (type: ToastType, timestamp: string) =>
      showToast(type, { timestamp }),
    showExportToast: (type: ToastType, options?: ToastParams) =>
      showToast(type, options),
  } as const;
}
