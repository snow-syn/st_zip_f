import { useState } from 'react';
import type { TankPlanData } from '../types';
import { COLUMNS, validateField } from '../config';

export type ValidationStep = {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'success' | 'error';
  message?: string;
};

export function useValidation() {
  const [validationSteps, setValidationSteps] = useState<ValidationStep[]>([
    { id: 'format', name: 'Format Validation', status: 'pending' },
    { id: 'required', name: 'Required Fields', status: 'pending' },
    { id: 'business', name: 'Business Rules', status: 'pending' },
    { id: 'save', name: 'Save Data', status: 'pending' },
  ]);

  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isValidating, setIsValidating] = useState(false);

  const updateStepStatus = (
    stepId: string,
    status: ValidationStep['status'],
    message?: string,
  ) => {
    setValidationSteps((steps) =>
      steps.map((step) =>
        step.id === stepId ? { ...step, status, message } : step,
      ),
    );
  };

  const validateData = async (data: TankPlanData[]): Promise<string[]> => {
    const errors: string[] = [];

    // 1. 格式验证
    updateStepStatus('format', 'processing');
    await new Promise((resolve) => setTimeout(resolve, 800));

    data.forEach((row, index) => {
      // 使用类型安全的方式访问属性
      Object.entries(COLUMNS).forEach(([key, column]) => {
        if (!column.validation) return;

        const value = row[key as keyof TankPlanData];
        const error = validateField(value, column);
        if (error) {
          errors.push(`Row ${index + 1}: ${error}`);
        }
      });
    });

    updateStepStatus('format', errors.length ? 'error' : 'success');
    if (errors.length) return errors;

    // 2. 必填字段验证
    updateStepStatus('required', 'processing');
    await new Promise((resolve) => setTimeout(resolve, 800));

    data.forEach((row, index) => {
      Object.entries(COLUMNS)
        .filter(([_, col]) =>
          col.validation?.some((rule) => rule.type === 'required'),
        )
        .forEach(([key, column]) => {
          const value = row[key as keyof TankPlanData];
          if (!value || !value.trim()) {
            errors.push(`Row ${index + 1}: ${column.label} is required`);
          }
        });
    });

    updateStepStatus('required', errors.length ? 'error' : 'success');
    if (errors.length) return errors;

    // 3. 业务规则验证
    updateStepStatus('business', 'processing');
    await new Promise((resolve) => setTimeout(resolve, 800));

    data.forEach((row, index) => {
      // 日期顺序验证
      if (row.drain && row.start) {
        const drainDate = new Date(row.drain);
        const startDate = new Date(row.start);
        if (drainDate > startDate) {
          errors.push(`Row ${index + 1}: Drain date must be before Start date`);
        }
      }

      // 可以添加更多业务规则验证...
    });

    updateStepStatus('business', errors.length ? 'error' : 'success');
    return errors;
  };

  return {
    validationSteps,
    setValidationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
  } as const;
}
