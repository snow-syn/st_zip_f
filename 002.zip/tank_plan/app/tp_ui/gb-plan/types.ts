import type { ColumnKey } from './config';

// 更新 Tank 计划数据类型
export interface TankPlanData {
  plan_id: string;
  tank: string;
  isopipe: string;
  biz_2: string;
  gen: string;
  rt: string;
  rc: string;
  design_as_is: string;
  design_to_be: string;
  tank_life: string;
  last_tank_light: string;
  drain: string;
  start: string;
  rtl: string;
  light: string;
  good_glass: string;
  idle_conv_days: string;
  installation_days: string;
  protective_days: string;
  startup_days: string;
  comments: string;
  [key: string]: string;
}

// Excel 处理结果类型
export interface ExcelProcessResult {
  data: TankPlanData[];
  errors: string[];
}

// 添加行验证结果类型
export interface RowValidationResult {
  isValid: boolean;
  errors: string[];
}

// 更明确的导出结果类型
export interface ExportResult {
  success: boolean;
  fileName?: string;
  error?: Error | string;
  rowCount?: number;
}

// 数据库响应类型
export interface DatabricksResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  errors?: string[];
  debug?: {
    queryTime?: number;
    transformTime?: number;
    rowCount?: number;
    timestamp?: string;
    stage?: string;
    details?: unknown;
  };
}
