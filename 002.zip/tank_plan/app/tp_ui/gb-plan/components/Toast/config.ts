import { Check, XCircle } from 'lucide-react';

export type ToastType = 'success' | 'error';

export interface ToastParams {
  fileName?: string;
  rowCount?: number;
  message?: string;
  timestamp?: string;
}

export interface ToastConfig {
  icon: typeof Check | typeof XCircle;
  iconClass: string;
  bgClass: string;
  textClass: string;
  title: (params: ToastParams) => string;
  content: (params: ToastParams) => string;
}

export interface ToastStyle {
  className: string;
  duration: number;
}

// 统一的 Toast 配置
export const toastConfig: Record<ToastType, ToastConfig> = {
  success: {
    icon: Check,
    iconClass: 'text-green-600',
    bgClass: 'bg-green-500/20',
    textClass: 'text-muted-foreground',
    title: ({ rowCount, timestamp }) =>
      rowCount !== undefined
        ? `${rowCount} rows exported`
        : 'Changes saved successfully',
    content: ({ fileName }) =>
      fileName
        ? `File: ${fileName}`
        : 'Your changes have been saved successfully',
  },
  error: {
    icon: XCircle,
    iconClass: 'text-destructive',
    bgClass: 'bg-destructive/20',
    textClass: 'text-destructive',
    title: () => 'Operation Failed',
    content: ({ message }) => message || 'Please try again',
  },
};

// Toast 样式配置
export const toastStyles: Record<ToastType, ToastStyle> = {
  success: {
    className: 'p-2 border border-green-100 bg-green-50',
    duration: 4000,
  },
  error: {
    className: 'p-2 border-destructive/50 bg-destructive/5',
    duration: 5000,
  },
};
