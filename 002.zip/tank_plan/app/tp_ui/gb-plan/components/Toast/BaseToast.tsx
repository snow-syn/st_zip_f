import * as React from 'react';
import { cn } from '@/lib/utils';
import { ToastType, toastConfig, type ToastParams } from './config';

interface BaseToastProps {
  type: ToastType;
  params?: ToastParams;
}

export const BaseToast: React.FC<BaseToastProps> = ({ type, params = {} }) => {
  const config = toastConfig[type];
  const Icon = config.icon;

  return (
    <div className="flex items-center gap-3">
      <div
        className={cn(
          'flex h-6 w-6 items-center justify-center rounded-full',
          config.bgClass,
        )}
      >
        <Icon className={cn('h-4 w-4', config.iconClass)} />
      </div>
      <div className="flex flex-col gap-1">
        <div className="flex items-center justify-between gap-2">
          <span className="font-medium tracking-tight">
            {config.title(params)}
          </span>
          {params.timestamp && type === 'success' && (
            <time className="text-[10px] tabular-nums text-muted-foreground/60">
              {params.timestamp}
            </time>
          )}
        </div>
        <span className={cn('text-sm', config.textClass)}>
          {config.content(params)}
        </span>
      </div>
    </div>
  );
};
