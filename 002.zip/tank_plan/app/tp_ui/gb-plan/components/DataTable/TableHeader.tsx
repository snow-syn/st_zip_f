import React from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import type { TableHeaderProps } from './types';

export const TableHeader: React.FC<TableHeaderProps> = ({ table }) => {
  const renderColumnHeader = (columnId: string) => (
    <th
      key={columnId}
      className={cn(
        'relative border-r border-border/50 p-1.5 last:border-r-0',
        'bg-gradient-to-b from-white/[0.02] via-white/[0.01] to-transparent',
        'group hover:bg-white/[0.02]',
        'transition-colors duration-200',
      )}
    >
      <span className="block text-[11px] font-medium text-muted-foreground/90">
        {columnId}
      </span>

      <Input
        className={cn(
          'mt-0.5 h-4 text-[11px]',
          'px-1.5 py-0',
          'bg-background/40',
          'border-border/40',
          'focus:bg-background/60',
          'focus:border-primary/50 focus:ring-1 focus:ring-primary/20',
          'placeholder:text-muted-foreground/40',
          'transition-all duration-200',
          'group-hover:bg-background/50',
          'group-hover:border-border/50',
        )}
        value={(table.getColumn(columnId)?.getFilterValue() as string) ?? ''}
        onChange={(e) =>
          table.getColumn(columnId)?.setFilterValue(e.target.value)
        }
      />
    </th>
  );

  return (
    <thead
      className={cn(
        'sticky top-0 z-10',
        'before:absolute before:inset-0 before:-z-10',
        'before:backdrop-blur-[8px] before:backdrop-saturate-[1.8]',
        'bg-gradient-to-b from-background/70 via-background/60 to-background/50',
        'supports-[backdrop-filter]:bg-background/40',
        'border-b border-border/50',
        'shadow-[0_2px_4px_rgba(0,0,0,0.08)]',
        'transition-all duration-200',
      )}
    >
      <tr>{table.getAllColumns().map((col) => renderColumnHeader(col.id))}</tr>
    </thead>
  );
};
