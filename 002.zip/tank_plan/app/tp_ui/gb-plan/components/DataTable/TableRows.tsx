import React from 'react';
import { TableBody, TableCell, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import type { TableRowsProps } from './types';
import { EditableCell } from './EditableCell';

export const TableRows: React.FC<TableRowsProps> = ({ table }) => {
  const renderRow = (
    row: ReturnType<typeof table.getRowModel>['rows'][number],
    index: number,
  ) => (
    <TableRow
      key={row.id}
      className={cn(
        'group border-b border-border/50',
        'transition-colors duration-150',
        'hover:bg-muted/50',
        index % 2 === 0 ? 'bg-card' : 'bg-muted/60 dark:bg-muted/30',
      )}
    >
      {row.getVisibleCells().map((cell) => (
        <TableCell
          key={cell.id}
          className={cn(
            'h-8 border-r border-border/50 p-0 text-sm',
            'last:border-r-0',
            'group-hover:bg-muted/30',
            'transition-colors duration-150',
          )}
        >
          <EditableCell cell={cell} onEdit={() => {}} />
        </TableCell>
      ))}
    </TableRow>
  );

  return (
    <TableBody>
      {table.getRowModel().rows.length ? (
        table.getRowModel().rows.map((row, index) => renderRow(row, index))
      ) : (
        <TableRow>
          <TableCell
            colSpan={table.getAllColumns().length}
            className="h-32 text-center text-muted-foreground"
          >
            No data available
          </TableCell>
        </TableRow>
      )}
    </TableBody>
  );
};
