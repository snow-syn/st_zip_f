import React, { useState, useEffect } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
} from '@tanstack/react-table';
import { Table } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { TableHeader } from './TableHeader';
import { TableRows } from './TableRows';
import { columns } from './columns';
import type { TankPlanData } from '../../types';
import { LayoutList, AlertTriangle, PenSquare } from 'lucide-react';
import type {
  DataTableProps,
  TableMeta,
  TableContainerProps,
  TableStatsProps,
} from './types';

const TableContainer = ({ children, rowCount }: TableContainerProps) => {
  const contentHeight = rowCount * 32 + 70;
  const containerHeight = Math.min(660, contentHeight);

  return (
    <div
      className={cn(
        'flex flex-col overflow-auto rounded-lg',
        'border border-border/50',
        'bg-gradient-to-b from-card via-card/95 to-card/90',
        'shadow-[0_2px_10px_rgba(0,0,0,0.06)]',
        'transition-all duration-300 ease-in-out',
      )}
      style={{ height: containerHeight }}
    >
      {children}
    </div>
  );
};

const TableStats = ({ data, errors, table, editedCells }: TableStatsProps) => {
  const totalRows = data.length;
  const filteredRows = table.getFilteredRowModel().rows.length;
  const hasFilters = filteredRows !== totalRows;

  const meta = table.options.meta as TableMeta;
  const editedRowsCount = new Set(
    Array.from(meta.editedCells).map((id) => id.split('-')[0]),
  ).size;

  const stats = [
    {
      label: hasFilters ? 'Showing' : 'Total',
      value: hasFilters
        ? `${filteredRows.toLocaleString()} of ${totalRows.toLocaleString()} rows`
        : totalRows.toLocaleString() + ' rows',
      icon: LayoutList,
      className: hasFilters ? 'text-blue-500' : 'text-muted-foreground',
      show: true,
    },
    {
      label: 'Modified',
      value: `${editedRowsCount} rows, ${editedCells} cells`,
      icon: PenSquare,
      className: 'text-emerald-500',
      show: editedCells > 0,
    },
    {
      label: 'Warnings',
      value: errors.length.toLocaleString(),
      icon: AlertTriangle,
      className: 'text-yellow-500',
      show: errors.length > 0,
    },
  ].filter((stat) => stat.show);

  return (
    <div className="flex h-8 items-center justify-between px-3">
      <div className="flex items-center gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className={cn('flex items-center gap-2 text-xs', stat.className)}
            >
              <Icon className="h-3.5 w-3.5" />
              <span className="font-medium tabular-nums">{stat.value}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const DataTable = ({
  data: initialData,
  errors,
  isTransitioning,
  onDataChange,
}: DataTableProps) => {
  const [data, setData] = useState<TankPlanData[]>(initialData);
  const [editedCells] = useState(new Set<string>());
  const [editingCell, setEditingCell] = useState<string>();

  useEffect(() => {
    onDataChange?.(data);
  }, [data, onDataChange]);

  const tableMeta: TableMeta = {
    updateData: (rowIndex: number, columnId: string, value: unknown) => {
      setData((old) =>
        old.map((row, index) => {
          if (index === rowIndex) {
            editedCells.add(`${rowIndex}-${columnId}`);
            return {
              ...old[rowIndex],
              [columnId]: value as string,
            };
          }
          return row;
        }),
      );
    },
    editingCell,
    switchEditingCell: (cell) => {
      setEditingCell(cell.id);
    },
    isEdited: (rowIndex: number, columnId: string) => {
      return editedCells.has(`${rowIndex}-${columnId}`);
    },
    editedCells,
  };

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    meta: tableMeta,
  });

  const filteredRowCount = table.getFilteredRowModel().rows.length;

  return (
    <div className="flex flex-col gap-1">
      <TableContainer rowCount={filteredRowCount}>
        <Table>
          <TableHeader table={table} />
          <TableRows table={table} />
        </Table>
      </TableContainer>

      <TableStats
        data={data}
        errors={errors}
        table={table}
        editedCells={editedCells.size}
      />
    </div>
  );
};
