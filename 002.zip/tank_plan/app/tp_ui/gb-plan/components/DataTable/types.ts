import type { Cell, Table as TableType } from '@tanstack/react-table';
import type { TankPlanData } from '../../types';

export interface DataTableProps {
  data: TankPlanData[];
  errors: string[];
  isTransitioning: boolean;
  className?: string;
  onDataChange?: (data: TankPlanData[]) => void;
}

export interface TableMeta<TData = TankPlanData> {
  updateData: (rowIndex: number, columnId: string, value: unknown) => void;
  editingCell: string | undefined;
  switchEditingCell: (cell: Cell<TData, unknown>) => void;
  isEdited: (rowIndex: number, columnId: string) => boolean;
  editedCells: Set<string>;
}

export interface TableHeaderProps {
  table: TableType<TankPlanData>;
}

export interface TableRowsProps {
  table: TableType<TankPlanData>;
}

export interface EditableCellProps {
  cell: Cell<TankPlanData, unknown>;
  onEdit?: () => void;
}

export interface TableContainerProps {
  children: React.ReactNode;
  rowCount: number;
}

export interface TableStatsProps {
  data: TankPlanData[];
  errors: string[];
  table: TableType<TankPlanData>;
  editedCells: number;
}
