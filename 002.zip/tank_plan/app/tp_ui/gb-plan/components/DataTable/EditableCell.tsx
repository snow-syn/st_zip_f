import React, { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import type { EditableCellProps } from './types';
import { DATE_COLUMNS, type DateColumn } from '../../config';
import { DateUtils, ValidationUtils } from '../../utils';
import type { TableMeta } from './types';
import type { TankPlanData } from '../../types';

// 内部工具函数
const validateCell = (value: string, columnId: keyof TankPlanData) => {
  const isDateField = DATE_COLUMNS.includes(columnId as DateColumn);
  return isDateField
    ? ValidationUtils.validateDate(value, String(columnId))
    : null;
};

const findTargetCell = (
  cell: EditableCellProps['cell'],
  direction: 'next' | 'prev',
) => {
  const table = cell.getContext().table;
  const visibleColumns = table.getVisibleLeafColumns();
  const currentIndex = visibleColumns.findIndex(
    (col) => col.id === cell.column.id,
  );
  const targetIndex =
    direction === 'next' ? currentIndex + 1 : currentIndex - 1;

  if (targetIndex >= 0 && targetIndex < visibleColumns.length) {
    const targetColumn = visibleColumns[targetIndex];
    return cell.row
      .getVisibleCells()
      .find((c) => c.column.id === targetColumn.id);
  }
  return undefined;
};

export const EditableCell: React.FC<EditableCellProps> = ({ cell, onEdit }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [value, setValue] = useState(cell.getValue() as string);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const columnId = cell.column.id as keyof TankPlanData;
  const isDateField = DATE_COLUMNS.includes(columnId as DateColumn);
  const meta = cell.getContext().table.options.meta as TableMeta;

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  useEffect(() => {
    if (meta.editingCell === cell.id && !isEditing) {
      setIsEditing(true);
    }
  }, [meta.editingCell]);

  const saveCell = () => {
    const validationError = validateCell(value, columnId);
    if (!validationError && value !== cell.getValue()) {
      meta.updateData(cell.row.index, String(columnId), value);
      onEdit?.();
    }
    return validationError;
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsEditing(true);
  };

  const handleBlur = () => {
    const error = saveCell();
    if (error) {
      setValue(cell.getValue() as string);
      setError(null);
    }
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setValue(newValue);
    const validationError = validateCell(newValue, columnId);
    setError(validationError);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    switch (e.key) {
      case 'Enter':
        e.preventDefault();
        inputRef.current?.blur();
        break;
      case 'Escape':
        setValue(cell.getValue() as string);
        setIsEditing(false);
        break;
      case 'Tab': {
        handleTab(e, e.shiftKey ? 'prev' : 'next');
        break;
      }
    }
  };

  const handleTab = (
    e: React.KeyboardEvent<HTMLInputElement>,
    direction: 'prev' | 'next',
  ) => {
    e.preventDefault();
    const error = saveCell();
    if (error) return;

    const targetCell = findTargetCell(cell, direction);
    if (targetCell) {
      meta.switchEditingCell(targetCell);
    }
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <div className="relative z-50 flex h-full w-full items-center">
        <div className="absolute inset-0 flex items-center duration-200 ease-out animate-in fade-in">
          <div className="relative h-full w-full">
            <div
              className={cn(
                'pointer-events-none absolute -inset-[1px] rounded-[2px]',
                'border border-primary/80',
                'shadow-[0_0_0_3px_rgba(0,0,0,0.02)]',
                'duration-200 ease-out animate-in fade-in',
                error && 'border-destructive/80',
              )}
            />
            <Input
              ref={inputRef}
              value={value}
              onChange={handleChange}
              onBlur={handleBlur}
              onKeyDown={handleKeyDown}
              className={cn(
                'h-full w-full rounded-[2px]',
                'border-0 bg-background/90',
                'px-2 py-0',
                'focus-visible:ring-0 focus-visible:ring-offset-0',
                'placeholder:text-muted-foreground/50',
                'selection:bg-primary/15',
                'backdrop-blur-[1px]',
                'duration-200 ease-out animate-in fade-in',
              )}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative flex h-full w-full items-center"
      onDoubleClick={handleDoubleClick}
    >
      <div
        className={cn(
          'flex h-full w-full cursor-text select-none items-center px-2',
          'active:bg-primary/8 hover:bg-primary/5',
          'transition-all duration-200 ease-out',
          meta.editingCell === cell.id && [
            'bg-primary/4',
            'outline outline-[1px] outline-primary/25',
            'duration-200 ease-out animate-in fade-in',
          ],
          meta.isEdited(cell.row.index, cell.column.id) && [
            'bg-amber-50/80 dark:bg-amber-500/30',
            'text-amber-900 dark:text-amber-100',
            'font-medium',
            'border-l-2 border-amber-400/50 dark:border-amber-400/30',
          ],
        )}
      >
        <span className="truncate">
          {isDateField && value ? DateUtils.format(value) : value}
        </span>
      </div>
    </div>
  );
};
