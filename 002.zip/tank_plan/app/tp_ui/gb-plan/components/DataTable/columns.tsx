import { ColumnDef } from '@tanstack/react-table';
import type { TankPlanData } from '../../types';
import { TANK_COLUMNS, DATE_COLUMNS } from '../../config';
import { StringUtils } from '../../utils';
import { EditableCell } from './EditableCell';

class ColumnFormatter {
  static isDateColumn(key: string): boolean {
    return DATE_COLUMNS.includes(key as any);
  }

  static formatColumnHeader(key: string): string {
    return this.isDateColumn(key) ? key : StringUtils.truncate(key);
  }
}

const ColumnHeader = ({ columnKey }: { columnKey: string }) => (
  <div className="group relative">
    <span className="text-[11px] font-medium tracking-tight">
      {ColumnFormatter.formatColumnHeader(columnKey)}
    </span>
    <div className="absolute -bottom-6 left-0 z-50 hidden whitespace-nowrap rounded-md border bg-popover/95 px-2.5 py-1 text-xs text-popover-foreground shadow-sm backdrop-blur group-hover:block supports-[backdrop-filter]:bg-popover/85">
      {columnKey}
    </div>
  </div>
);

const createColumn = (key: string): ColumnDef<TankPlanData> => ({
  accessorKey: key as keyof TankPlanData,
  header: () => <ColumnHeader columnKey={key} />,
  cell: (props) => <EditableCell cell={props.cell} onEdit={() => {}} />,
});

export const columns: ColumnDef<TankPlanData>[] =
  TANK_COLUMNS.map(createColumn);
