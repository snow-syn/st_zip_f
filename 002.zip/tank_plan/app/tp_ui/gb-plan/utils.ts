export class DateUtils {
  private static readonly EXCEL_DATE_BASE = 25569;
  private static readonly MS_PER_DAY = 86400 * 1000;
  private static readonly DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

  static format(dateStr: string): string {
    if (!dateStr) return '';

    try {
      return this.isExcelSerialNumber(dateStr)
        ? this.formatExcelDate(dateStr)
        : this.formatStringDate(dateStr);
    } catch {
      return '';
    }
  }

  static isValidDateFormat(dateStr: string): boolean {
    return this.DATE_REGEX.test(dateStr);
  }

  private static isExcelSerialNumber(dateStr: string): boolean {
    const num = Number(dateStr);
    return !isNaN(num) && num > 0;
  }

  private static formatExcelDate(serialNumber: string): string {
    const msFromBase =
      (Number(serialNumber) - this.EXCEL_DATE_BASE) * this.MS_PER_DAY;
    const excelDate = new Date(Math.round(msFromBase));
    return this.formatToISODate(excelDate);
  }

  private static formatStringDate(dateStr: string): string {
    const date = new Date(dateStr);
    return this.formatToISODate(date);
  }

  private static formatToISODate(date: Date): string {
    return date instanceof Date && !isNaN(date.getTime())
      ? date.toISOString().split('T')[0]
      : '';
  }
}

export class DataUtils {
  static cleanString(value: unknown): string {
    if (
      value === null ||
      value === undefined ||
      value === 'NULL' ||
      value === 'TBD'
    ) {
      return '';
    }
    return String(value).trim();
  }

  static cleanObject<T>(obj: Record<string, unknown>): T {
    return Object.entries(obj).reduce(
      (acc, [key, value]) => ({
        ...acc,
        [key]: this.cleanString(value),
      }),
      {} as T,
    );
  }

  static isEmptyObject(obj: unknown): boolean {
    return (
      obj !== null && typeof obj === 'object' && Object.keys(obj).length === 0
    );
  }
}

export class StringUtils {
  static truncate(text: string, maxLength: number = 8): string {
    if (!text) return '';
    return text.length > maxLength ? `${text.slice(0, maxLength)}..` : text;
  }

  static capitalize(text: string): string {
    if (!text) return '';
    return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
  }
}

export class ValidationUtils {
  static validateRequired(value: unknown, fieldName: string): string | null {
    if (!value || (typeof value === 'string' && !value.trim())) {
      return `${fieldName} is required`;
    }
    return null;
  }

  static validateDate(value: string, fieldName: string): string | null {
    if (value && !DateUtils.isValidDateFormat(value)) {
      return `${fieldName} has invalid date format, should be YYYY-MM-DD`;
    }
    return null;
  }
}
