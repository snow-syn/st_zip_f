import { NextRequest, NextResponse } from 'next/server';
import type { TankPlanData } from '@/app/tp_ui/gb-plan/types';

// 生成随机日期
const randomDate = (start: Date, end: Date) => {
  const date = new Date(
    start.getTime() + Math.random() * (end.getTime() - start.getTime()),
  );
  return date.toISOString().split('T')[0];
};

// 生成随机数字字符串
const randomNumber = (min: number, max: number) =>
  Math.floor(Math.random() * (max - min + 1) + min).toString();

// 生成单行数据
const generateMockRow = (index: number): TankPlanData => {
  const startDate = new Date('2024-01-01');
  const endDate = new Date('2024-12-31');

  return {
    plan_id: `P${index.toString().padStart(4, '0')}`,
    tank: `TANK${((index % 5) + 1).toString().padStart(2, '0')}`,
    isopipe: `ISO${index + 1}`,
    biz_2: `BIZ${(index % 3) + 1}`,
    gen: `GEN${(index % 4) + 1}`,
    rt: `RT${(index % 3) + 1}`,
    rc: `RC${(index % 2) + 1}`,
    design_as_is: `Design${(index % 3) + 1}`,
    design_to_be: `NewDesign${(index % 3) + 1}`,
    tank_life: randomNumber(1000, 2000),
    last_tank_light: randomDate(startDate, endDate),
    drain: randomDate(startDate, endDate),
    start: randomDate(startDate, endDate),
    rtl: randomDate(startDate, endDate),
    light: randomDate(startDate, endDate),
    good_glass: randomDate(startDate, endDate),
    idle_conv_days: randomNumber(10, 30),
    installation_days: randomNumber(5, 15),
    protective_days: randomNumber(3, 10),
    startup_days: randomNumber(5, 20),
    comments: `Test comment ${index + 1}`,
  };
};

// 生成mock数据集
const generateMockData = (count: number = 20): TankPlanData[] =>
  Array.from({ length: count }, (_, index) => generateMockRow(index));

// 处理 GET 请求
export async function GET(request: NextRequest) {
  try {
    // 模拟网络延迟
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const mockData = generateMockData();

    // 设置 CORS 头
    const headers = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    return NextResponse.json(
      {
        success: true,
        data: mockData,
        debug: {
          queryTime: 234,
          transformTime: 123,
          rowCount: mockData.length,
          timestamp: new Date().toISOString(),
          stage: 'MockData',
          details: {
            source: 'mock-api',
            version: '1.0.0',
          },
        },
      },
      { headers },
    );
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal Server Error',
        debug: {
          stage: 'ApiError',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      { status: 500 },
    );
  }
}

// 处理 OPTIONS 请求
export async function OPTIONS(request: NextRequest) {
  return NextResponse.json(
    {},
    {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    },
  );
}
