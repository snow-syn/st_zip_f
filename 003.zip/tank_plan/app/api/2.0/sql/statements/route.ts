import { NextRequest } from 'next/server';
import { randomUUID } from 'crypto';
import { logger } from '@/app/tp_ui/utils/logger';
import { Database, open } from 'sqlite';
import sqlite3 from 'sqlite3';
import path from 'path';

// Databricks SQL API 接口定义
interface SQLStatementRequest {
  warehouse_id: string;
  statement: string;
  wait_timeout?: string;
  on_wait_timeout?: 'CONTINUE' | 'CANCEL';
  parameters?: unknown[];
}

interface SQLColumn {
  name: string;
  position: number;
  type_name: string;
  type_text: string;
}

interface SQLResponse {
  statement_id: string;
  status: {
    state: 'SUCCEEDED' | 'FAILED';
    error?: {
      message: string;
      code?: string;
      detail?: string;
    };
  };
  manifest: {
    format: 'JSON_ARRAY';
    schema: {
      column_count: number;
      columns: SQLColumn[];
    };
  };
  result: {
    chunk_index: number;
    row_offset: number;
    row_count: number;
    data_array: unknown[][];
  };
}

// SQLite 数据库服务
class SQLiteService {
  private static db: Database | null = null;
  private static readonly DB_PATH = path.resolve(
    process.cwd(),
    'data/tank_plan.db',
  );

  static async getConnection(): Promise<Database> {
    if (!this.db) {
      this.db = await open({
        filename: this.DB_PATH,
        driver: sqlite3.Database,
      });
      await this.initializeDatabase();
    }
    return this.db;
  }

  private static async initializeDatabase(): Promise<void> {
    const db = await this.getConnection();
    await db.exec(`
      CREATE TABLE IF NOT EXISTS app_tank_plan_master (
        plan_master_id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_version TEXT NOT NULL UNIQUE,
        plan_type TEXT NOT NULL,
        plan_official TEXT,
        plan_version_no INTEGER NOT NULL,
        plan_version_parent TEXT,
        version_match TEXT,
        create_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        update_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        user_name TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS app_tank_plan_detail (
        plan_detail_id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_master_id INTEGER NOT NULL,
        plan_row_id TEXT NOT NULL,
        tank TEXT NOT NULL,
        iso TEXT,
        glass_type TEXT,
        gen TEXT,
        RT TEXT,
        RC TEXT,
        platform TEXT,
        design_asis TEXT,
        tank_life REAL,
        last_tank_light_date DATE,
        drain_date DATE,
        repair_date DATE,
        RTL_date DATE,
        TL_date DATE,
        GG_date DATE,
        cold_idle REAL,
        repair_LT REAL,
        RTL_LT REAL,
        TL_LT REAL,
        remark_category TEXT,
        remark TEXT,
        comment TEXT,
        create_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        update_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        user_name TEXT NOT NULL,
        FOREIGN KEY (plan_master_id) REFERENCES app_tank_plan_master(plan_master_id)
      );

      CREATE INDEX IF NOT EXISTS idx_plan_version ON app_tank_plan_master(plan_version);
      CREATE INDEX IF NOT EXISTS idx_plan_type ON app_tank_plan_master(plan_type);
      CREATE INDEX IF NOT EXISTS idx_plan_master_id ON app_tank_plan_detail(plan_master_id);
      CREATE INDEX IF NOT EXISTS idx_tank ON app_tank_plan_detail(tank);
    `);
  }

  static async executeStatement(
    sql: string,
    params?: unknown[],
  ): Promise<{
    rows?: unknown[][];
    columns?: SQLColumn[];
    changes?: number;
    lastID?: number;
  }> {
    const db = await this.getConnection();
    const isSelect = sql.trim().toUpperCase().startsWith('SELECT');

    try {
      if (isSelect) {
        const rows = await db.all(sql, params);
        if (!rows?.length) return { rows: [], columns: [] };

        const columns = Object.keys(rows[0]).map((key, index) => ({
          name: key,
          position: index,
          type_name: 'STRING',
          type_text: 'VARCHAR',
        }));

        return {
          rows: rows.map((row) => Object.values(row)),
          columns,
        };
      } else {
        const result = await db.run(sql, params);
        return {
          changes: result.changes || 0,
          lastID: result.lastID,
        };
      }
    } catch (error) {
      logger.error('SQL execution failed', { sql, params, error });
      throw error;
    }
  }
}

// Databricks SQL API 路由处理
export async function POST(request: NextRequest) {
  const context = {
    module: 'SQLStatements',
    function: 'POST',
    requestId: randomUUID(),
  };

  try {
    const requestBody = (await request.json()) as SQLStatementRequest;
    logger.group('SQL Request', context);
    logger.debug('Request details', context, {
      url: request.url,
      method: request.method,
      headers: Object.fromEntries(request.headers.entries()),
      body: requestBody,
    });

    // 验证请求
    if (!requestBody.statement) {
      throw new Error('SQL statement is required');
    }

    // 执行 SQL 语句
    const statements = requestBody.statement
      .split(';')
      .filter((s: string) => s.trim());
    let result = null;

    for (const stmt of statements) {
      if (!stmt.trim()) continue;
      result = await SQLiteService.executeStatement(
        stmt,
        requestBody.parameters,
      );
    }

    // 构造 Databricks 格式的响应
    const response: SQLResponse = {
      statement_id: randomUUID().replace(/-/g, ''),
      status: { state: 'SUCCEEDED' },
      manifest: {
        format: 'JSON_ARRAY',
        schema: {
          column_count: result?.columns?.length || 2,
          columns: result?.columns || [
            {
              name: 'changes',
              position: 0,
              type_name: 'INTEGER',
              type_text: 'INTEGER',
            },
            {
              name: 'lastID',
              position: 1,
              type_name: 'INTEGER',
              type_text: 'INTEGER',
            },
          ],
        },
      },
      result: {
        chunk_index: 0,
        row_offset: 0,
        row_count: result?.rows?.length || 1,
        data_array: result?.rows || [
          [result?.changes || 0, result?.lastID || 0],
        ],
      },
    };

    logger.debug('Response prepared', context, {
      statement_id: response.statement_id,
      rowCount: response.result.row_count,
      sampleData: response.result.data_array[0],
    });

    logger.groupEnd();
    return new Response(JSON.stringify(response), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    logger.error('Request failed', context, {
      error,
      request: {
        url: request.url,
        method: request.method,
        body: await request
          .clone()
          .text()
          .catch(() => 'Unable to read body'),
      },
    });

    const errorResponse = {
      statement_id: randomUUID().replace(/-/g, ''),
      status: {
        state: 'FAILED',
        error: {
          message: error instanceof Error ? error.message : 'Unknown error',
          code: error instanceof Error ? (error as any).code : 'UNKNOWN_ERROR',
          detail: error instanceof Error ? error.stack : undefined,
        },
      },
    };

    logger.debug('Error response prepared', context, errorResponse);
    logger.groupEnd();
    return new Response(JSON.stringify(errorResponse), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

export const OPTIONS = () =>
  new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
