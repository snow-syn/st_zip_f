import { COLUMNS } from '@/app/tp_ui/config/config';
import type {
  TankPlanDetailData,
  DatabricksResponse,
  PlanVersion,
  PlanFilter,
  PlanListResult,
  VersionOperationResult,
  VersionDiff,
  VersionTree,
  PlanVersionResponse,
  PlanType,
  PlanTag,
} from '@/app/tp_ui/types';
import { logger, LogLevel } from '@/app/tp_ui/utils/logger';

interface SQLColumn {
  name: string;
  position: number;
  type_name: string;
  type_text: string;
}

interface DatabricksAPIResponse {
  statement_id: string;
  status: {
    state: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED';
    error?: {
      message: string;
      code?: string;
    };
  };
  manifest?: {
    format: 'JSON_ARRAY';
    schema: {
      column_count: number;
      columns: SQLColumn[];
    };
  };
  result?: {
    chunk_index: number;
    row_offset: number;
    row_count: number;
    data_array: any[][];
  };
}

const DatabaseService = {
  API_CONFIG: {
    baseUrl: process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080',
    token: process.env.NEXT_PUBLIC_DATABRICKS_TOKEN,
    warehouseId: process.env.NEXT_PUBLIC_DATABRICKS_WAREHOUSE_ID,
  },

  async getLatestPlanData(): Promise<DatabricksResponse<TankPlanDetailData[]>> {
    const context = {
      module: 'DatabaseService',
      function: 'getLatestPlanData',
      requestId: `req-${Date.now()}`,
    };

    try {
      logger.group('Starting data fetch', context, LogLevel.INFO);
      logger.startTimer('data-fetch');

      const result = await this.executeSQLQuery(
        this.buildLatestPlanQuery(),
        context,
      );

      return this.transformQueryResult(result, context);
    } catch (error) {
      return this.handleError(error, context);
    } finally {
      logger.groupEnd(LogLevel.INFO);
    }
  },

  async executeSQLQuery(
    sql: string,
    context: Record<string, any>,
  ): Promise<DatabricksAPIResponse> {
    const requestBody = {
      warehouse_id: this.API_CONFIG.warehouseId,
      statement: sql,
      wait_timeout: '30s',
      on_wait_timeout: 'CONTINUE',
    };

    logger.debug('Preparing API request', context, {
      url: `${this.API_CONFIG.baseUrl}/api/2.0/sql/statements`,
      body: requestBody,
    });

    const response = await fetch(
      `${this.API_CONFIG.baseUrl}/api/2.0/sql/statements`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.API_CONFIG.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      },
    );

    logger.debug('Received API response', context, {
      ok: response.ok,
      status: response.status,
    });

    const responseText = await response.text();

    try {
      const result = JSON.parse(responseText);
      logger.trace('Raw API response', context, result);
      return result;
    } catch (e) {
      logger.error('Failed to parse response', context, {
        responseText,
        error: e,
      });
      throw new Error('Invalid JSON response from API');
    }
  },

  transformQueryResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): DatabricksResponse<TankPlanDetailData[]> {
    if (
      result.status.state !== 'SUCCEEDED' ||
      !result.manifest ||
      !result.result
    ) {
      logger.warn('Invalid response format', context, result);
      return {
        success: false,
        error: 'Invalid response format from SQL API',
        data: [],
      };
    }

    try {
      logger.debug('Starting data transformation', context, {
        rowCount: result.result.row_count,
        columnCount: result.manifest.schema.column_count,
      });

      const transformedData = this.transformRows(result);

      return {
        success: true,
        data: transformedData,
        debug: {
          queryTime: 0,
          transformTime: 0,
          rowCount: transformedData.length,
          timestamp: new Date().toISOString(),
          stage: 'Success',
          details: {
            statement_id: result.statement_id,
            originalStructure: {
              columnCount: result.manifest.schema.column_count,
              rowCount: result.result.row_count,
            },
          },
        },
      };
    } catch (error) {
      logger.error('Data transformation failed', context, { error });
      return {
        success: false,
        error: 'Failed to transform data',
        data: [],
        debug: {
          stage: 'TransformError',
          timestamp: new Date().toISOString(),
          details: { error, statement_id: result.statement_id },
        },
      };
    }
  },

  transformRows(result: DatabricksAPIResponse): TankPlanDetailData[] {
    return result.result!.data_array.map((row) => {
      return result.manifest!.schema.columns.reduce(
        (acc, col, index) => {
          acc[col.name] = row[index] === null ? '' : String(row[index]);
          return acc;
        },
        {} as Record<string, string>,
      ) as TankPlanDetailData;
    });
  },

  handleError<T>(
    error: unknown,
    context: Record<string, any>,
  ): T extends PlanVersion[] ? PlanVersionResponse : DatabricksResponse<T> {
    logger.error('Operation failed', context, {
      error,
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
    });

    const baseResponse = {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      debug: {
        stage: 'Error',
        timestamp: new Date().toISOString(),
        details: {
          treeDepth: 0,
          relationCount: 0,
          filters: undefined,
        },
      },
    };

    // 如果是 PlanVersion[] 类型，返回 PlanVersionResponse
    if (context.function === 'getPlanVersions') {
      return {
        ...baseResponse,
        data: [],
        debug: {
          ...baseResponse.debug,
          details: {
            treeDepth: 0,
            relationCount: 0,
            filters: undefined,
          },
        },
      } as T extends PlanVersion[]
        ? PlanVersionResponse
        : DatabricksResponse<T>;
    }

    // 其他类型返回普通的 DatabricksResponse
    return {
      ...baseResponse,
      data: undefined,
    } as T extends PlanVersion[] ? PlanVersionResponse : DatabricksResponse<T>;
  },

  buildLatestPlanQuery(): string {
    const columnNames = Object.values(COLUMNS)
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map((col) => col.key)
      .join(', ');

    return `
      SELECT ${columnNames}
      FROM app_tank_plan_detail
      ORDER BY create_timestamp DESC
      LIMIT 3
    `;
  },

  async saveData(data: TankPlanDetailData[]): Promise<boolean> {
    const context = {
      module: 'DatabaseService',
      function: 'saveData',
      requestId: `save-${Date.now()}`,
    };

    try {
      logger.group('Starting save operation', context);

      // 构建 master 记录的插入语句
      const currentDate = new Date();
      const planVersion = currentDate.toISOString().split('T')[0];
      const versionMatch = planVersion.substring(0, 7).replace('-', '');

      const masterInsertQuery = `
        INSERT INTO app_tank_plan_master (
          plan_version,
          plan_type,
          plan_official,
          plan_version_no,
          plan_version_parent,
          version_match,
          user_name
        ) VALUES (
          '${planVersion}',
          'Long-term',
          '',
          1,
          NULL,
          '${versionMatch}',
          'system'
        ) RETURNING plan_master_id;
      `;

      // 执行 master 插入并获取 plan_master_id
      const masterResponse = await this.executeSQLQuery(
        masterInsertQuery,
        context,
      );

      if (
        masterResponse.status.state !== 'SUCCEEDED' ||
        !masterResponse.result?.data_array?.[0]?.[0]
      ) {
        throw new Error('Failed to create master record');
      }

      const planMasterId = masterResponse.result.data_array[0][0];
      logger.debug('Created master record', context, { planMasterId });

      // 构建 detail 记录的插入语句
      const detailColumns = [
        'plan_master_id',
        'plan_row_id',
        'tank',
        'iso',
        'glass_type',
        'gen',
        'RT',
        'RC',
        'platform',
        'design_asis',
        'tank_life',
        'last_tank_light_date',
        'drain_date',
        'repair_date',
        'RTL_date',
        'TL_date',
        'GG_date',
        'cold_idle',
        'repair_LT',
        'RTL_LT',
        'TL_LT',
        'remark_category',
        'remark',
        'comment',
        'user_name',
      ].join(', ');

      const detailValues = data
        .map(
          (row) => `(
        ${planMasterId},
        '${row.plan_row_id}',
        '${row.tank}',
        ${row.iso ? `'${row.iso}'` : 'NULL'},
        ${row.glass_type ? `'${row.glass_type}'` : 'NULL'},
        ${row.gen ? `'${row.gen}'` : 'NULL'},
        ${row.RT ? `'${row.RT}'` : 'NULL'},
        ${row.RC ? `'${row.RC}'` : 'NULL'},
        ${row.platform ? `'${row.platform}'` : 'NULL'},
        ${row.design_asis ? `'${row.design_asis}'` : 'NULL'},
        ${row.tank_life || 'NULL'},
        ${row.last_tank_light_date ? `'${row.last_tank_light_date}'` : 'NULL'},
        ${row.drain_date ? `'${row.drain_date}'` : 'NULL'},
        ${row.repair_date ? `'${row.repair_date}'` : 'NULL'},
        ${row.RTL_date ? `'${row.RTL_date}'` : 'NULL'},
        ${row.TL_date ? `'${row.TL_date}'` : 'NULL'},
        ${row.GG_date ? `'${row.GG_date}'` : 'NULL'},
        ${row.cold_idle || 'NULL'},
        ${row.repair_LT || 'NULL'},
        ${row.RTL_LT || 'NULL'},
        ${row.TL_LT || 'NULL'},
        ${row.remark_category ? `'${row.remark_category}'` : 'NULL'},
        ${row.remark ? `'${row.remark}'` : 'NULL'},
        ${row.comment ? `'${row.comment}'` : 'NULL'},
        'system'
      )`,
        )
        .join(',\n');

      const detailInsertQuery = `
        INSERT INTO app_tank_plan_detail (
          ${detailColumns}
        ) VALUES ${detailValues};
      `;

      // 执行 detail 插入
      const detailResponse = await this.executeSQLQuery(
        detailInsertQuery,
        context,
      );

      if (detailResponse.status.state !== 'SUCCEEDED') {
        throw new Error('Failed to create detail records');
      }

      logger.debug('Created detail records', context, {
        rowCount: data.length,
        planMasterId,
      });

      return true;
    } catch (error) {
      logger.error('Save operation failed', context, error);
      throw error;
    } finally {
      logger.groupEnd();
    }
  },

  // 获取版本列表
  async getPlanVersions(): Promise<PlanVersionResponse> {
    const context = {
      module: 'DatabaseService',
      function: 'getPlanVersions',
      requestId: `req-${Date.now()}`,
    };

    try {
      logger.group('Fetching plan versions', context);

      // 简化查询,不再包含筛选条件
      const sql = `
        SELECT 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name,
          COUNT(d.plan_detail_id) as row_count
        FROM app_tank_plan_master m
        LEFT JOIN app_tank_plan_detail d ON m.plan_master_id = d.plan_master_id
        GROUP BY 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name
        ORDER BY m.plan_version DESC, m.plan_version_no DESC
      `;

      logger.debug('Executing SQL query', context, { sql });
      const result = await this.executeSQLQuery(sql, []);

      return this.transformVersionQueryResult(result, context);
    } catch (error) {
      logger.error('Failed to fetch plan versions', context, { error });
      return this.handleError(error, context);
    } finally {
      logger.groupEnd();
    }
  },

  // 获取版本树
  async getVersionTree(): Promise<DatabricksResponse<VersionTree>> {
    const context = {
      module: 'DatabaseService',
      function: 'getVersionTree',
      requestId: `req-${Date.now()}`,
    };

    try {
      const sql = `
        WITH RECURSIVE version_tree AS (
          -- 根节点
          SELECT 
            plan_master_id,
            plan_version,
            plan_type,
            plan_official,
            plan_version_no,
            plan_version_parent,
            create_timestamp,
            update_timestamp,
            user_name,
            0 as level
          FROM app_tank_plan_master
          WHERE plan_version_parent IS NULL
          
          UNION ALL
          
          -- 递归查询子节点
          SELECT 
            m.plan_master_id,
            m.plan_version,
            m.plan_type,
            m.plan_official,
            m.plan_version_no,
            m.plan_version_parent,
            m.create_timestamp,
            m.update_timestamp,
            m.user_name,
            vt.level + 1
          FROM app_tank_plan_master m
          JOIN version_tree vt ON m.plan_version_parent = vt.plan_master_id
        )
        SELECT * FROM version_tree
        ORDER BY level, create_timestamp
      `;

      const result = await this.executeSQLQuery(sql, []);
      return this.transformTreeQueryResult(result, context);
    } catch (error) {
      return this.handleError(error, context);
    }
  },

  // 获取版本详情
  async getVersionDetails(
    versionId: number,
  ): Promise<DatabricksResponse<PlanVersion>> {
    const context = {
      module: 'DatabaseService',
      function: 'getVersionDetails',
      requestId: `req-${Date.now()}`,
    };

    try {
      const sql = `
        SELECT 
          m.*,
          COUNT(d.plan_detail_id) as row_count
        FROM app_tank_plan_master m
        LEFT JOIN app_tank_plan_detail d ON m.plan_master_id = d.plan_master_id
        WHERE m.plan_master_id = ?
        GROUP BY m.plan_master_id
      `;

      const result = await this.executeSQLQuery(sql, [versionId]);
      return this.transformVersionDetailResult(result, context);
    } catch (error) {
      return this.handleError(error, context);
    }
  },

  // 比较两个版本
  async compareVersions(
    sourceId: number,
    targetId: number,
  ): Promise<DatabricksResponse<VersionDiff>> {
    const context = {
      module: 'DatabaseService',
      function: 'compareVersions',
      requestId: `req-${Date.now()}`,
    };

    try {
      const sql = `
        WITH source_data AS (
          SELECT * FROM app_tank_plan_detail WHERE plan_master_id = ?
        ),
        target_data AS (
          SELECT * FROM app_tank_plan_detail WHERE plan_master_id = ?
        )
        SELECT 
          'added' as change_type,
          t.*
        FROM target_data t
        LEFT JOIN source_data s ON t.plan_row_id = s.plan_row_id
        WHERE s.plan_row_id IS NULL
        
        UNION ALL
        
        SELECT 
          'deleted' as change_type,
          s.*
        FROM source_data s
        LEFT JOIN target_data t ON s.plan_row_id = t.plan_row_id
        WHERE t.plan_row_id IS NULL
        
        UNION ALL
        
        SELECT 
          'modified' as change_type,
          t.*
        FROM source_data s
        JOIN target_data t ON s.plan_row_id = t.plan_row_id
        WHERE s.tank != t.tank 
           OR s.iso != t.iso
           -- ... 其他字段比较
      `;

      const result = await this.executeSQLQuery(sql, [sourceId, targetId]);
      return this.transformCompareResult(result, context);
    } catch (error) {
      return this.handleError(error, context);
    }
  },

  // 创建新版本
  async createVersion(
    type: PlanType,
    parentId: number | null = null,
  ): Promise<DatabricksResponse<PlanVersion>> {
    const context = {
      module: 'DatabaseService',
      function: 'createVersion',
      requestId: `create-${Date.now()}`,
    };

    try {
      logger.group('Creating new version', context);

      const currentDate = new Date();
      const planVersion = currentDate.toISOString().split('T')[0];
      const versionMatch = planVersion.substring(0, 7).replace('-', '');

      const sql = `
        INSERT INTO app_tank_plan_master (
          plan_version,
          plan_type,
          plan_official,
          plan_version_no,
          version_match,
          user_name
        ) VALUES (
          ?,
          ?,
          '',  // 默认为空标签
          ?,
          ?,
          'system'
        )
      `;

      const result = await this.executeSQLQuery(sql, [
        planVersion,
        planVersion,
        type,
        parentId,
        versionMatch,
      ]);

      if (!result?.result?.data_array?.[0]) {
        throw new Error('Failed to create version: No data returned');
      }

      // 转换数据为 PlanVersion 类型
      const version: PlanVersion = {
        plan_master_id: Number(result.result.data_array[0][0]),
        plan_version: String(result.result.data_array[0][1]),
        plan_type: String(result.result.data_array[0][2]) as PlanType,
        plan_official: String(result.result.data_array[0][3]) as PlanTag,
        plan_version_no: Number(result.result.data_array[0][4]),
        plan_version_parent: result.result.data_array[0][5]
          ? String(result.result.data_array[0][5])
          : null,
        version_match: String(result.result.data_array[0][6]),
        create_timestamp: String(result.result.data_array[0][7]),
        update_timestamp: String(result.result.data_array[0][8]),
        user_name: String(result.result.data_array[0][9]),
        row_count: 0,
      };

      logger.debug('Version created', context, {
        result,
        planVersion,
        type,
        parentId,
      });

      return {
        success: true,
        data: version,
      };
    } catch (error) {
      logger.error('Failed to create version', context, { error });
      return {
        success: false,
        error:
          error instanceof Error ? error.message : 'Failed to create version',
      };
    } finally {
      logger.groupEnd();
    }
  },

  // 更新版本状态
  async updateVersionTag(
    versionId: number,
    tag: PlanTag,
  ): Promise<DatabricksResponse<PlanVersion>> {
    const context = {
      module: 'DatabaseService',
      function: 'updateVersionTag',
      requestId: `update-${Date.now()}`,
    };

    try {
      logger.group('Updating version tag', context);

      const sql = `
        UPDATE app_tank_plan_master
        SET plan_official = ?,
            update_timestamp = CURRENT_TIMESTAMP
        WHERE plan_master_id = ?
        RETURNING *;
      `;

      const result = await this.executeSQLQuery(sql, [tag, versionId]);

      if (!result?.result?.data_array?.[0]) {
        throw new Error('Failed to update version status: No data returned');
      }

      // 转换数据为 PlanVersion 类型
      const version: PlanVersion = {
        plan_master_id: Number(result.result.data_array[0][0]),
        plan_version: String(result.result.data_array[0][1]),
        plan_type: String(result.result.data_array[0][2]) as PlanType,
        plan_official: String(result.result.data_array[0][3]) as PlanTag,
        plan_version_no: Number(result.result.data_array[0][4]),
        plan_version_parent: result.result.data_array[0][5]
          ? String(result.result.data_array[0][5])
          : null,
        version_match: String(result.result.data_array[0][6]),
        create_timestamp: String(result.result.data_array[0][7]),
        update_timestamp: String(result.result.data_array[0][8]),
        user_name: String(result.result.data_array[0][9]),
        row_count: 0,
      };

      logger.debug('Status updated', context, {
        result,
        versionId,
        tag,
      });

      return {
        success: true,
        data: version,
      };
    } catch (error) {
      logger.error('Failed to update status', context, { error });
      return {
        success: false,
        error:
          error instanceof Error ? error.message : 'Failed to update status',
      };
    } finally {
      logger.groupEnd();
    }
  },

  // 果转换方法
  transformVersionQueryResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): PlanVersionResponse {
    logger.debug('Transforming version query result', context, {
      status: result.status,
      rowCount: result.result?.row_count,
    });

    if (
      result.status.state !== 'SUCCEEDED' ||
      !result.manifest ||
      !result.result
    ) {
      return {
        success: false,
        error: 'Invalid response format from SQL API',
        data: [],
        debug: {
          stage: 'TransformError',
          timestamp: new Date().toISOString(),
          details: {
            treeDepth: 0,
            relationCount: 0,
            filters: undefined,
          },
        },
      };
    }

    try {
      const versions: PlanVersion[] = result.result.data_array.map((row) => {
        const version: PlanVersion = {
          plan_master_id: Number(row[0]),
          plan_version: String(row[1]),
          plan_type: String(row[2]) as PlanType,
          plan_official: String(row[3]) as PlanTag,
          plan_version_no: Number(row[4]),
          plan_version_parent: row[5] ? String(row[5]) : null,
          version_match: String(row[6]),
          create_timestamp: String(row[7]),
          update_timestamp: String(row[8]),
          user_name: String(row[9]),
          row_count: Number(row[10]),
        };
        return version;
      });

      logger.debug('Transformed versions', context, {
        count: versions.length,
        sample: versions[0],
      });

      return {
        success: true,
        data: versions,
        debug: {
          queryTime: 0,
          transformTime: 0,
          rowCount: versions.length,
          timestamp: new Date().toISOString(),
          stage: 'Success',
          details: {
            treeDepth: 0,
            relationCount: 0,
          },
        },
      };
    } catch (error) {
      logger.error('Failed to transform version data', context, { error });
      return {
        success: false,
        error: 'Failed to transform version data',
        data: [],
        debug: {
          stage: 'TransformError',
          timestamp: new Date().toISOString(),
          details: {
            treeDepth: 0,
            relationCount: 0,
            filters: undefined,
          },
        },
      };
    }
  },

  transformTreeQueryResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): DatabricksResponse<VersionTree> {
    return {
      success: false,
      error: 'Not implemented',
      debug: {
        stage: 'NotImplemented',
        timestamp: new Date().toISOString(),
      },
    };
  },

  transformVersionDetailResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): DatabricksResponse<PlanVersion> {
    return {
      success: false,
      error: 'Not implemented',
      debug: {
        stage: 'NotImplemented',
        timestamp: new Date().toISOString(),
      },
    };
  },

  transformCompareResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): DatabricksResponse<VersionDiff> {
    return {
      success: false,
      error: 'Not implemented',
      debug: {
        stage: 'NotImplemented',
        timestamp: new Date().toISOString(),
      },
    };
  },

  transformCreateResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): DatabricksResponse<VersionOperationResult> {
    return {
      success: false,
      error: 'Not implemented',
      debug: {
        stage: 'NotImplemented',
        timestamp: new Date().toISOString(),
      },
    };
  },

  transformUpdateResult(
    result: DatabricksAPIResponse,
    context: Record<string, any>,
  ): DatabricksResponse<VersionOperationResult> {
    return {
      success: false,
      error: 'Not implemented',
      debug: {
        stage: 'NotImplemented',
        timestamp: new Date().toISOString(),
      },
    };
  },

  // 获取所有版本数据
  async getAllPlanVersions(): Promise<PlanVersionResponse> {
    const context = {
      module: 'DatabaseService',
      function: 'getAllPlanVersions',
      requestId: `req-${Date.now()}`,
    };

    try {
      logger.group('Fetching all plan versions', context);

      const sql = `
        SELECT 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name,
          COUNT(d.plan_detail_id) as row_count
        FROM app_tank_plan_master m
        LEFT JOIN app_tank_plan_detail d ON m.plan_master_id = d.plan_master_id
        GROUP BY 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name
        ORDER BY m.create_timestamp DESC
      `;

      logger.debug('Executing SQL query', context, { sql });
      const result = await this.executeSQLQuery(sql, []);

      return this.transformVersionQueryResult(result, context);
    } catch (error) {
      return this.handleError(error, context);
    }
  },

  async getVersionData(
    versionId: number,
  ): Promise<DatabricksResponse<TankPlanDetailData[]>> {
    const context = {
      module: 'DatabaseService',
      function: 'getVersionData',
      requestId: `req-${Date.now()}`,
      versionId,
    };

    try {
      logger.group('Fetching version data', context);

      const sql = `
        SELECT 
          plan_row_id, tank, iso, glass_type, gen, RT, RC, 
          platform, design_asis, tank_life, last_tank_light_date,
          drain_date, repair_date, RTL_date, TL_date, GG_date,
          cold_idle, repair_LT, RTL_LT, TL_LT, comment,
          remark_category, remark
        FROM app_tank_plan_detail
        WHERE plan_master_id = ${versionId}
        ORDER BY plan_row_id
      `;

      const result = await this.executeSQLQuery(sql, {
        module: 'DatabaseService',
        function: 'getVersionData',
        versionId,
      });

      if (!result?.result?.data_array) {
        throw new Error('Invalid response format from SQL API');
      }

      logger.debug('Version data retrieved', context, {
        rowCount: result.result.data_array.length,
        columns: result.manifest?.schema.columns.map((col) => col.name),
        sampleRow: result.result.data_array[0],
      });

      // 转换数据
      const transformedData = result.result.data_array.map((row) => {
        // 将数组转换为对象
        const rowObj = result.manifest!.schema.columns.reduce(
          (obj, col, index) => {
            obj[col.name] = row[index];
            return obj;
          },
          {} as Record<string, unknown>,
        );

        return this.transformDetailRow(rowObj);
      });

      return {
        success: true,
        data: transformedData,
        debug: {
          queryTime: 0,
          rowCount: transformedData.length,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      logger.error('Failed to fetch version data', context, { error });
      return this.handleError(error, context);
    } finally {
      logger.groupEnd();
    }
  },

  transformDetailRow(row: Record<string, unknown>): TankPlanDetailData {
    const context = {
      module: 'DatabaseService',
      function: 'transformDetailRow',
    };

    try {
      logger.debug('Transforming detail row', context, {
        originalRow: row,
        columns: Object.keys(row),
      });

      // 换数据
      const transformedData: TankPlanDetailData = {
        plan_row_id: String(row.plan_row_id || ''),
        tank: String(row.tank || ''),
        iso: String(row.iso || ''),
        glass_type: String(row.glass_type || ''),
        gen: String(row.gen || ''),
        RT: String(row.RT || ''),
        RC: String(row.RC || ''),
        platform: String(row.platform || ''),
        design_asis: String(row.design_asis || ''),
        tank_life: String(row.tank_life || ''),
        last_tank_light_date: String(row.last_tank_light_date || ''),
        drain_date: String(row.drain_date || ''),
        repair_date: String(row.repair_date || ''),
        RTL_date: String(row.RTL_date || ''),
        TL_date: String(row.TL_date || ''),
        GG_date: String(row.GG_date || ''),
        cold_idle: String(row.cold_idle || ''),
        repair_LT: String(row.repair_LT || ''),
        RTL_LT: String(row.RTL_LT || ''),
        TL_LT: String(row.TL_LT || ''),
        comment: String(row.comment || ''),
        remark_category: String(row.remark_category || ''),
        remark: String(row.remark || ''),
      };

      logger.debug('Row transformed', context, {
        transformedData,
        includedColumns: Object.keys(transformedData),
      });

      return transformedData;
    } catch (error) {
      logger.error('Failed to transform row', context, { error, row });
      throw error;
    }
  },

  // 在 DatabaseService 中添加新方法
  async getVersionInfo(
    versionId: number,
  ): Promise<DatabricksResponse<PlanVersion>> {
    const context = {
      module: 'DatabaseService',
      function: 'getVersionInfo',
      requestId: `req-${Date.now()}`,
      versionId,
    };

    try {
      logger.group('Fetching version info', context);

      const sql = `
        SELECT 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name,
          COUNT(d.plan_detail_id) as row_count
        FROM app_tank_plan_master m
        LEFT JOIN app_tank_plan_detail d ON m.plan_master_id = d.plan_master_id
        WHERE m.plan_master_id = ${versionId}
        GROUP BY 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name
      `;

      const result = await this.executeSQLQuery(sql, {
        module: 'DatabaseService',
        function: 'getVersionInfo',
        versionId,
      });

      if (!result?.result?.data_array?.[0]) {
        throw new Error('Version not found');
      }

      const row = result.result.data_array[0];
      const version: PlanVersion = {
        plan_master_id: Number(row[0]),
        plan_version: String(row[1]),
        plan_type: String(row[2]) as PlanType,
        plan_official: String(row[3]) as PlanTag,
        plan_version_no: Number(row[4]),
        plan_version_parent: row[5] ? String(row[5]) : null,
        version_match: String(row[6]),
        create_timestamp: String(row[7]),
        update_timestamp: String(row[8]),
        user_name: String(row[9]),
        row_count: Number(row[10]),
      };

      return {
        success: true,
        data: version,
        debug: {
          queryTime: 0,
          rowCount: 1,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      logger.error('Failed to fetch version info', context, { error });
      return this.handleError(error, context);
    } finally {
      logger.groupEnd();
    }
  },

  // 添加新方法
  async getLatestPlan(): Promise<DatabricksResponse<PlanVersion>> {
    const context = {
      module: 'DatabaseService',
      function: 'getLatestPlan',
    };

    try {
      logger.group('Fetching latest plan', context);

      const sql = `
        SELECT 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name,
          COUNT(d.plan_detail_id) as row_count
        FROM app_tank_plan_master m
        LEFT JOIN app_tank_plan_detail d ON m.plan_master_id = d.plan_master_id
        GROUP BY 
          m.plan_master_id,
          m.plan_version,
          m.plan_type,
          m.plan_official,
          m.plan_version_no,
          m.plan_version_parent,
          m.version_match,
          m.create_timestamp,
          m.update_timestamp,
          m.user_name
        ORDER BY m.create_timestamp DESC
        LIMIT 1
      `;

      const result = await this.executeSQLQuery(sql, {
        module: 'DatabaseService',
        function: 'getLatestPlan',
      });

      logger.debug('SQL query result', context, { result });

      if (!result?.result?.data_array?.[0]) {
        throw new Error('No plans found');
      }

      const row = result.result.data_array[0];
      const latestPlan: PlanVersion = {
        plan_master_id: Number(row[0]),
        plan_version: String(row[1]),
        plan_type: String(row[2]) as PlanType,
        plan_official: String(row[3]) as PlanTag,
        plan_version_no: Number(row[4]),
        plan_version_parent: row[5] ? String(row[5]) : null,
        version_match: String(row[6]),
        create_timestamp: String(row[7]),
        update_timestamp: String(row[8]),
        user_name: String(row[9]),
        row_count: Number(row[10]),
      };

      logger.debug('Latest plan data transformed', context, { latestPlan });

      return {
        success: true,
        data: latestPlan,
        debug: {
          queryTime: 0,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      logger.error('Failed to fetch latest plan', context, {
        error,
        message: error instanceof Error ? error.message : 'Unknown error',
      });
      return {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : 'Failed to fetch latest plan',
        debug: {
          stage: 'Error',
          timestamp: new Date().toISOString(),
        },
      };
    } finally {
      logger.groupEnd();
    }
  },
};

export default DatabaseService;
