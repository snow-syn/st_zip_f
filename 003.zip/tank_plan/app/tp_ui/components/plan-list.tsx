import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import {
  Search,
  CalendarIcon,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Eye,
  FileText,
} from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/app/tp_ui/utils/logger';
import DatabaseService from '@/app/tp_ui/services/DatabaseService';
import type { PlanVersion, PlanFilter, PlanType } from '@/app/tp_ui/types';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useRouter } from 'next/navigation';
import { type SelectRangeEventHandler } from 'react-day-picker';
import { DateRange } from 'react-day-picker';

interface PlanListProps {
  refreshing: boolean;
  onRefresh: () => void;
  onDateRangeChange?: (from: Date, to: Date) => void;
}

export function PlanList({
  refreshing,
  onRefresh,
  onDateRangeChange,
}: PlanListProps) {
  const [allPlans, setAllPlans] = useState<PlanVersion[]>([]);
  const [filteredPlans, setFilteredPlans] = useState<PlanVersion[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<PlanType | 'all'>('all');
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<PlanVersion | null>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);

  // 初始化默认日期范围为最近三个月
  useEffect(() => {
    const context = {
      module: 'PlanList',
      function: 'initDateRange',
    };

    try {
      const end = new Date();
      const start = new Date();
      start.setMonth(start.getMonth() - 3);

      logger.debug('Initializing date range', context, {
        start: format(start, 'yyyy-MM-dd'),
        end: format(end, 'yyyy-MM-dd'),
      });

      setStartDate(start);
      setEndDate(end);
    } catch (error) {
      logger.error('Failed to initialize date range', context, { error });
    }
  }, []);

  // 加载所有计划列表数据
  const loadPlanList = async () => {
    const context = {
      module: 'PlanList',
      function: 'loadPlanList',
      requestId: `load-${Date.now()}`,
    };

    try {
      logger.group('Loading plan list', context);
      setLoading(true);

      const result = await DatabaseService.getPlanVersions();

      if (!result.success) {
        throw new Error(result.error || 'Failed to load plan list');
      }

      logger.debug('Plan list loaded', context, {
        totalCount: result.data?.length,
      });

      setAllPlans(result.data || []);
    } catch (error) {
      logger.error('Failed to load plan list', context, { error });
      toast({
        variant: 'destructive',
        title: 'Error',
        description:
          error instanceof Error ? error.message : 'Failed to load plan list',
      });
    } finally {
      setLoading(false);
      logger.groupEnd();
    }
  };

  // 本地筛选数据
  const filterPlans = useCallback(() => {
    const context = {
      module: 'PlanList',
      function: 'filterPlans',
    };

    try {
      let filtered = [...allPlans];

      // 日期范围筛选
      if (startDate && endDate) {
        filtered = filtered.filter((plan) => {
          const planDate = plan.plan_version;
          return (
            planDate >= format(startDate, 'yyyy-MM-dd') &&
            planDate <= format(endDate, 'yyyy-MM-dd')
          );
        });
      }

      // 类型筛选
      if (selectedType !== 'all') {
        filtered = filtered.filter((plan) => plan.plan_type === selectedType);
      }

      // 标签筛选
      if (selectedTag !== 'all') {
        filtered = filtered.filter(
          (plan) => plan.plan_official === selectedTag,
        );
      }

      // 搜索筛选
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        filtered = filtered.filter(
          (plan) =>
            plan.plan_version.toLowerCase().includes(searchLower) ||
            plan.user_name.toLowerCase().includes(searchLower),
        );
      }

      logger.debug('Plans filtered', context, {
        totalCount: allPlans.length,
        filteredCount: filtered.length,
        filters: {
          dateRange: { startDate, endDate },
          type: selectedType,
          tag: selectedTag,
          searchTerm,
        },
      });

      setFilteredPlans(filtered);
      setTotalPages(Math.ceil(filtered.length / 10));
      setCurrentPage(1); // 重置页码
    } catch (error) {
      logger.error('Failed to filter plans', context, { error });
    }
  }, [allPlans, startDate, endDate, selectedType, selectedTag, searchTerm]);

  // 监听筛选条件变化
  useEffect(() => {
    filterPlans();
  }, [filterPlans]);

  // 初始加载数据
  useEffect(() => {
    loadPlanList();
  }, []);

  // 处理搜索
  const handleSearch = (value: string) => {
    setSearchTerm(value);
  };

  // 处理类型筛选
  const handleTypeFilter = (type: PlanType | 'all') => {
    setSelectedType(type);
  };

  // 处理日期选择
  const handleDateSelect = (range: DateRange | undefined) => {
    if (range?.from && range?.to) {
      handleDateRangeFilter(range.from, range.to);
    }
  };

  // 处理标签筛选
  const handleTagFilter = (tag: string) => {
    const context = {
      module: 'PlanList',
      function: 'handleTagFilter',
    };

    try {
      logger.debug('Tag filter changed', context, { tag });
      setSelectedTag(tag);
    } catch (error) {
      logger.error('Failed to handle tag filter', context, { error });
    }
  };

  // 获取当前页的数据
  const getCurrentPageData = () => {
    const startIndex = (currentPage - 1) * 10;
    return filteredPlans.slice(startIndex, startIndex + 10);
  };

  // 处理分页
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // 生成分页按钮
  const renderPaginationButtons = () => {
    const buttons = [];
    for (let i = 1; i <= totalPages; i++) {
      buttons.push(
        <Button
          key={i}
          variant={currentPage === i ? 'default' : 'outline'}
          size="sm"
          onClick={() => handlePageChange(i)}
        >
          {i}
        </Button>,
      );
    }
    return buttons;
  };

  // 处理查看详情
  const handleViewDetails = (plan: PlanVersion) => {
    const context = {
      module: 'PlanList',
      function: 'handleViewDetails',
      planId: plan.plan_master_id,
    };

    try {
      logger.debug('Opening plan details', context);
      setSelectedPlan(plan);
      setShowDetailsDialog(true);
    } catch (error) {
      logger.error('Failed to view details', context, { error });
      toast({
        variant: 'destructive',
        title: 'Error',
        description:
          error instanceof Error ? error.message : 'Failed to view details',
      });
    }
  };

  // 添加详情对话框组件
  const PlanDetailsDialog = ({
    plan,
    open,
    onClose,
  }: {
    plan: PlanVersion | null;
    open: boolean;
    onClose: () => void;
  }) => {
    if (!plan) return null;

    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span>Plan Details</span>
              <Badge variant="outline">{plan.plan_type}</Badge>
              {plan.plan_official && (
                <Badge variant="secondary">{plan.plan_official}</Badge>
              )}
            </DialogTitle>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Version</Label>
                <div className="mt-1 flex items-center gap-2">
                  <span className="font-medium">{plan.plan_version}</span>
                  {plan.plan_version_no > 1 && (
                    <Badge variant="outline">v{plan.plan_version_no}</Badge>
                  )}
                </div>
              </div>
              <div>
                <Label>Created By</Label>
                <div className="mt-1">{plan.user_name}</div>
              </div>
              <div>
                <Label>Created At</Label>
                <div className="mt-1">
                  {new Date(plan.create_timestamp).toLocaleString()}
                </div>
              </div>
              <div>
                <Label>Updated At</Label>
                <div className="mt-1">
                  {new Date(plan.update_timestamp).toLocaleString()}
                </div>
              </div>
              {plan.row_count !== undefined && (
                <div>
                  <Label>Row Count</Label>
                  <div className="mt-1">{plan.row_count}</div>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  // 添加处理数
  const router = useRouter();

  const handleViewPlan = (plan: PlanVersion) => {
    const context = {
      module: 'PlanList',
      function: 'handleViewPlan',
      planId: plan.plan_master_id,
    };

    try {
      logger.debug('Navigating to plan view', context);
      router.push(`/tp_ui/plan-view?id=${plan.plan_master_id}`);
    } catch (error) {
      logger.error('Navigation failed', context, { error });
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to navigate to plan view',
      });
    }
  };

  // 添加事件监听
  useEffect(() => {
    const handleRefresh = () => {
      logger.debug('Refreshing plan list from event');
      loadPlanList();
    };

    // 监听刷新事件
    window.addEventListener('refreshPlanList', handleRefresh);

    // 清理函数
    return () => {
      window.removeEventListener('refreshPlanList', handleRefresh);
    };
  }, []);

  // 添加 handleDateRangeFilter 函数
  const handleDateRangeFilter = (from: Date, to: Date) => {
    const context = {
      module: 'PlanList',
      function: 'handleDateRangeFilter',
    };

    try {
      logger.debug('Date range filter changed', context, {
        from: format(from, 'yyyy-MM-dd'),
        to: format(to, 'yyyy-MM-dd'),
      });
      if (onDateRangeChange) {
        onDateRangeChange(from, to);
      }
    } catch (error) {
      logger.error('Failed to handle date range filter', context, { error });
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center space-x-4 px-2">
          <div>
            <CardTitle className="text-lg">Tank Plan List</CardTitle>
          </div>
          <div className="flex items-center gap-1.5">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="h-8 w-[240px] justify-start text-left text-sm font-normal"
                >
                  <CalendarIcon className="mr-1.5 h-3.5 w-3.5" />
                  {startDate && endDate ? (
                    <>
                      {format(startDate, 'yyyy/MM/dd')} -{' '}
                      {format(endDate, 'yyyy/MM/dd')}
                    </>
                  ) : (
                    <span>Select date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="range"
                  defaultMonth={startDate}
                  selected={{
                    from: startDate,
                    to: endDate,
                  }}
                  onSelect={handleDateSelect}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {/* 搜索和筛选区域 - 减小上边距和组件大小 */}
        <div className="mt-2">
          <div className="flex items-center justify-between gap-3">
            {/* 搜索框 */}
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                placeholder="Search plans..."
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
                className="h-8 pl-7 text-sm"
              />
            </div>

            {/* 选择框组 */}
            <div className="flex items-center gap-1.5">
              {/* 计划类型选择 */}
              <Select
                onValueChange={(value) =>
                  handleTypeFilter(value as PlanType | 'all')
                }
              >
                <SelectTrigger className="h-8 w-[140px] text-sm">
                  <SelectValue placeholder="Plan Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Long-term">Long-term</SelectItem>
                  <SelectItem value="Weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>

              {/* 标签选择 */}
              <Select onValueChange={handleTagFilter} defaultValue="all">
                <SelectTrigger className="h-8 w-[140px] text-sm">
                  <SelectValue placeholder="Select Tag" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tags</SelectItem>
                  <SelectItem value="GB">GB</SelectItem>
                  <SelectItem value="18MP">18MP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="h-8">
              <TableHead className="py-1">Plan Version</TableHead>
              <TableHead className="py-1">Type</TableHead>
              <TableHead className="py-1">Created By</TableHead>
              <TableHead className="py-1">Created At</TableHead>
              <TableHead className="py-1">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {getCurrentPageData().map((plan) => (
              <TableRow
                key={plan.plan_master_id}
                className="h-10 hover:bg-muted/50"
              >
                <TableCell className="py-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{plan.plan_version}</span>
                    {plan.plan_official && (
                      <Badge
                        variant="outline"
                        className={cn(
                          'h-5 px-2 text-xs font-medium',
                          // 根据标签类型设置不同的颜色
                          plan.plan_official === 'GB'
                            ? 'border-purple-300 bg-purple-50/50 text-purple-700 hover:bg-purple-100 dark:border-purple-800 dark:bg-purple-950/20 dark:text-purple-400'
                            : plan.plan_official === '18MP'
                              ? 'border-amber-300 bg-amber-50/50 text-amber-700 hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-400'
                              : '',
                        )}
                      >
                        {plan.plan_official}
                      </Badge>
                    )}
                    {plan.plan_version_no > 1 && (
                      <Badge variant="outline" className="h-5 px-1 text-xs">
                        v{plan.plan_version_no}
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell className="py-1">
                  <Badge
                    variant="outline"
                    className={cn(
                      'h-5 px-2 text-xs font-medium',
                      // 根据计划类型设置不同的颜色
                      plan.plan_type === 'Long-term'
                        ? 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950/30 dark:text-blue-400'
                        : 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400',
                    )}
                  >
                    {plan.plan_type}
                  </Badge>
                </TableCell>
                <TableCell className="py-1">{plan.user_name}</TableCell>
                <TableCell className="py-1 text-muted-foreground">
                  {new Date(plan.create_timestamp).toLocaleString()}
                </TableCell>
                <TableCell className="py-1">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-[160px]">
                      <DropdownMenuItem
                        onClick={() => handleViewDetails(plan)}
                        className="cursor-pointer"
                      >
                        <Eye className="mr-2 h-4 w-4" />
                        <span>View Details</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleViewPlan(plan)}
                        className="cursor-pointer"
                      >
                        <FileText className="mr-2 h-4 w-4" />
                        <span>View Plan</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {/* 分页控件 */}
        <div className="mt-4 flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          {renderPaginationButtons()}
          <Button
            variant="outline"
            size="icon"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>

      {/* 添加详情对话框 */}
      <PlanDetailsDialog
        plan={selectedPlan}
        open={showDetailsDialog}
        onClose={() => {
          setShowDetailsDialog(false);
          setSelectedPlan(null);
        }}
      />
    </Card>
  );
}
