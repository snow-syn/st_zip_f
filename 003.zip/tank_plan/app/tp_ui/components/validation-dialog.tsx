import * as React from 'react';
import { Check, XCircle, Loader2, CheckCircle, Circle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';

export type ValidationStepStatus =
  | 'pending'
  | 'processing'
  | 'success'
  | 'error';

export interface ValidationStep {
  id: string;
  name: string;
  status: ValidationStepStatus;
  message?: string;
}

const ValidationSteps = ({
  steps,
  isValidating,
}: {
  steps: ValidationStep[];
  isValidating: boolean;
}) => (
  <div
    className={cn(
      'space-y-2.5 rounded-lg bg-muted/30 p-3 transition-all duration-300',
      isValidating ? 'opacity-100' : 'opacity-80',
    )}
  >
    {steps.map((step) => (
      <div
        key={step.id}
        className={cn(
          'flex items-center gap-3 rounded-md px-3 py-2 transition-all duration-200',
          step.status === 'processing' &&
            'bg-background shadow-sm ring-1 ring-border/50',
          step.status === 'success' && 'text-green-600',
          step.status === 'error' && 'text-red-600',
        )}
      >
        <div className="flex-shrink-0">
          {step.status === 'pending' && (
            <div className="h-2 w-2 rounded-full bg-muted-foreground/30" />
          )}
          {step.status === 'processing' && (
            <div className="h-2 w-2 animate-pulse rounded-full bg-primary" />
          )}
          {step.status === 'success' && (
            <div className="h-2 w-2 rounded-full bg-green-500" />
          )}
          {step.status === 'error' && (
            <div className="h-2 w-2 rounded-full bg-red-500" />
          )}
        </div>
        <span className="text-sm">{step.name}</span>
      </div>
    ))}
  </div>
);

const ValidationErrors = ({ errors }: { errors: string[] }) => (
  <div className="duration-300 animate-in fade-in slide-in-from-top-2">
    <div className="space-y-3 rounded-lg bg-red-50 px-4 py-3 text-red-900 ring-1 ring-red-200">
      <div className="flex items-center gap-2">
        <div className="h-1 w-1 rounded-full bg-red-500" />
        <p className="text-sm font-medium">Please fix the following issues</p>
      </div>
      <ScrollArea className="h-[200px] w-full rounded pr-4">
        <div className="space-y-2 pl-3">
          {errors.map((error, index) => (
            <p
              key={index}
              className={cn(
                'text-sm text-red-700',
                'py-1',
                'border-l-2 border-red-200/50 pl-2',
                'animate-in fade-in-50 slide-in-from-top-1',
                'duration-100',
              )}
            >
              {error}
            </p>
          ))}
        </div>
      </ScrollArea>
    </div>
  </div>
);

const ValidationSuccess = ({
  step,
  message,
}: {
  step?: ValidationStep;
  message?: string;
}) => {
  if (!step || step.status !== 'pending') return null;

  return (
    <div className="duration-300 animate-in fade-in slide-in-from-top-2">
      <div className="min-h-[90px] space-y-2 rounded-lg bg-green-50 px-4 py-3 text-green-900 ring-1 ring-green-200">
        <div className="flex items-center gap-2">
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100">
            <Check className="h-3 w-3 text-green-600" />
          </div>
          <p className="text-sm font-medium">Ready to save changes</p>
        </div>
        <div className="pl-7">
          <p className="text-sm text-green-700">
            {message ||
              'All validations passed successfully. Would you like to proceed with saving?'}
          </p>
        </div>
      </div>
    </div>
  );
};

const SavingStatus = ({
  message = 'Please wait while we save your data. This may take a few moments...',
}: {
  message?: string;
}) => (
  <div className="duration-300 animate-in fade-in slide-in-from-top-2">
    <div className="min-h-[90px] space-y-2 rounded-lg bg-primary/5 px-4 py-3 text-primary ring-1 ring-primary/20">
      <div className="flex items-center gap-2">
        <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/10">
          <div className="h-3 w-3 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
        <p className="text-sm font-medium">Saving your changes</p>
      </div>
      <div className="pl-7">
        <p className="text-sm text-primary/80">{message}</p>
      </div>
    </div>
  </div>
);

export interface ValidationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isValidating: boolean;
  isSaving: boolean;
  errors?: string[];
  validationSteps: ValidationStep[];
  onConfirmSave?: () => Promise<void>;
  validationErrors?: string[];
}

export function ValidationDialog({
  open,
  onOpenChange,
  validationSteps,
  errors = [],
  isValidating,
  isSaving,
  onConfirmSave,
}: ValidationDialogProps) {
  const getStatusIcon = () => {
    if (isValidating) {
      return (
        <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      );
    }
    if (errors.length > 0) {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
    return <Check className="h-4 w-4 text-primary" />;
  };

  const getStatusTitle = () => {
    if (isValidating) return 'Validating Data';
    if (errors.length > 0) return 'Validation Failed';
    return 'Save Data';
  };

  const getStepIcon = (step: ValidationStep) => {
    if (isValidating && step.status === 'pending') {
      return <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />;
    }
    if (step.status === 'success') {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    if (errors?.length > 0) {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
    if (isValidating) {
      return <Loader2 className="h-4 w-4 animate-spin" />;
    }
    return <Circle className="h-4 w-4" />;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="transition-all duration-300 sm:max-w-[525px]">
        <DialogHeader className="space-y-4">
          <DialogTitle className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-background shadow-sm ring-1 ring-border/50">
              {getStatusIcon()}
            </div>
            <span className="text-lg font-medium">{getStatusTitle()}</span>
          </DialogTitle>

          <DialogDescription asChild>
            <div className="relative space-y-4">
              <ValidationSteps
                steps={validationSteps}
                isValidating={isValidating}
              />
              {errors.length > 0 && <ValidationErrors errors={errors} />}
              {!isValidating && errors.length === 0 && (
                <ValidationSuccess
                  step={validationSteps.find((s) => s.id === 'save')}
                />
              )}
            </div>
          </DialogDescription>
        </DialogHeader>

        {!isValidating && (
          <DialogFooter className="mt-6">
            <div className="flex w-full items-center justify-end gap-3">
              <Button
                variant="ghost"
                onClick={() => onOpenChange(false)}
                className="transition-all duration-200"
              >
                Cancel
              </Button>

              {errors.length === 0 && onConfirmSave && (
                <Button
                  onClick={onConfirmSave}
                  disabled={isSaving}
                  className="relative min-w-[120px] transition-all duration-200"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Save Changes'
                  )}
                </Button>
              )}

              {errors.length > 0 && (
                <Button
                  variant="ghost"
                  onClick={() => onOpenChange(false)}
                  className="transition-all duration-200"
                >
                  Close
                </Button>
              )}
            </div>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
