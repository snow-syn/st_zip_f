import React, { useState, useEffect } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  type Table,
  type Cell,
  type ColumnDef,
} from '@tanstack/react-table';
import {
  Table as UITable,
  TableBody,
  TableCell,
  TableRow,
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { LayoutList, AlertTriangle, PenSquare } from 'lucide-react';

export interface EditConfig {
  allowEdit?: boolean;
  validateCell?: (value: string, columnId: string) => string | null;
  formatValue?: (value: string, columnId: string) => string;
}

export interface TableConfig<TData> {
  editConfig?: EditConfig;
  rowHeight?: number;
  maxHeight?: number;
  className?: string;
  renderStats?: (props: {
    table: Table<TData>;
    editedCells: number;
    data: TData[];
    errors?: string[];
  }) => React.ReactNode;
}

export interface DataTableProps<TData> extends TableConfig<TData> {
  data: TData[];
  columns: ColumnDef<TData>[];
  onDataChange?: (data: TData[]) => void;
  errors?: string[];
}

export interface TableMeta<TData> {
  editedCells: Set<string>;
  updateData: (rowIndex: number, columnId: string, value: string) => void;
  editingCell: string | undefined;
  switchEditingCell: (cell: Cell<TData, unknown>) => void;
  isEdited: (rowIndex: number, columnId: string) => boolean;
  editConfig?: EditConfig;
}

interface ColumnHeaderProps {
  columnKey: string;
  label?: string;
  tooltip?: string;
}

export const ColumnHeader = ({
  columnKey,
  label,
  tooltip,
}: ColumnHeaderProps) => (
  <div className="group relative">
    <span className="text-[11px] font-medium tracking-tight">
      {label || columnKey}
    </span>
    {tooltip && (
      <div className="absolute -bottom-6 left-0 z-50 hidden whitespace-nowrap rounded-md border bg-popover/95 px-2.5 py-1 text-xs text-popover-foreground shadow-sm backdrop-blur group-hover:block supports-[backdrop-filter]:bg-popover/85">
        {tooltip}
      </div>
    )}
  </div>
);

export interface DataGridColumn<T> {
  key: keyof T;
  label?: string;
  tooltip?: string;
  isDate?: boolean;
  formatValue?: (value: string) => string;
  validateValue?: (value: string) => string | null;
}

export function createColumn<TData>(
  config: DataGridColumn<TData>,
): ColumnDef<TData> {
  return {
    accessorKey: config.key,
    header: () => (
      <ColumnHeader
        columnKey={String(config.key)}
        label={config.label}
        tooltip={config.tooltip}
      />
    ),
  };
}

interface TableStatsProps<T> {
  data: T[];
  errors?: string[];
  table: Table<T>;
  editedCells: number;
}

function TableStats<T>({
  data,
  errors = [],
  table,
  editedCells,
}: TableStatsProps<T>) {
  const totalRows = data.length;
  const filteredRows = table.getFilteredRowModel().rows.length;
  const hasFilters = filteredRows !== totalRows;

  const meta = table.options.meta as TableMeta<T>;
  const editedRowsCount = new Set(
    Array.from(meta.editedCells).map((id: string) => id.split('-')[0]),
  ).size;

  const stats = [
    {
      label: hasFilters ? 'Showing' : 'Total',
      value: hasFilters
        ? `${filteredRows.toLocaleString()} of ${totalRows.toLocaleString()} rows`
        : totalRows.toLocaleString() + ' rows',
      icon: LayoutList,
      className: hasFilters ? 'text-blue-500' : 'text-muted-foreground',
      show: true,
    },
    {
      label: 'Modified',
      value: `${editedRowsCount} rows, ${editedCells} cells`,
      icon: PenSquare,
      className: 'text-emerald-500',
      show: editedCells > 0,
    },
    {
      label: 'Warnings',
      value: errors.length.toLocaleString(),
      icon: AlertTriangle,
      className: 'text-yellow-500',
      show: errors.length > 0,
    },
  ].filter((stat) => stat.show);

  return (
    <div className="flex h-8 items-center justify-between px-3">
      <div className="flex items-center gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className={cn('flex items-center gap-2 text-xs', stat.className)}
            >
              <Icon className="h-3.5 w-3.5" />
              <span className="font-medium tabular-nums">{stat.value}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface EditableCellProps<TData> {
  cell: Cell<TData, unknown>;
}

function EditableCell<TData>({ cell }: EditableCellProps<TData>) {
  const [isEditing, setIsEditing] = useState(false);
  const [value, setValue] = useState(cell.getValue() as string);
  const [error, setError] = useState<string | null>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);

  const meta = cell.getContext().table.options.meta as TableMeta<TData>;
  const editConfig = meta.editConfig;

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  useEffect(() => {
    if (meta.editingCell === cell.id && !isEditing) {
      setIsEditing(true);
    }
  }, [meta.editingCell]);

  if (!editConfig?.allowEdit) {
    return (
      <div className="flex h-full w-full items-center px-2">
        <span className="truncate">
          {editConfig?.formatValue?.(value, cell.column.id) ?? value}
        </span>
      </div>
    );
  }

  const saveCell = () => {
    const validationError = editConfig?.validateCell?.(value, cell.column.id);
    if (!validationError && value !== cell.getValue()) {
      meta.updateData(cell.row.index, cell.column.id, value);
    }
    return validationError;
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsEditing(true);
  };

  const handleBlur = () => {
    const error = saveCell();
    if (error) {
      setValue(cell.getValue() as string);
      setError(null);
    }
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setValue(newValue);
    const validationError = editConfig?.validateCell?.(
      newValue,
      cell.column.id,
    );
    if (validationError !== undefined) {
      setError(validationError);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    switch (e.key) {
      case 'Enter':
        e.preventDefault();
        inputRef.current?.blur();
        break;
      case 'Escape':
        setValue(cell.getValue() as string);
        setIsEditing(false);
        break;
      case 'Tab':
        handleTab(e, e.shiftKey ? 'prev' : 'next');
        break;
    }
  };

  const handleTab = (
    e: React.KeyboardEvent<HTMLInputElement>,
    direction: 'prev' | 'next',
  ) => {
    e.preventDefault();
    const error = saveCell();
    if (error) return;

    const table = cell.getContext().table;
    const visibleColumns = table.getVisibleLeafColumns();
    const currentIndex = visibleColumns.findIndex(
      (col) => col.id === cell.column.id,
    );
    const targetIndex =
      direction === 'next' ? currentIndex + 1 : currentIndex - 1;

    if (targetIndex >= 0 && targetIndex < visibleColumns.length) {
      const targetColumn = visibleColumns[targetIndex];
      const targetCell = cell.row
        .getVisibleCells()
        .find((c) => c.column.id === targetColumn.id);
      if (targetCell) {
        meta.switchEditingCell(targetCell);
      }
    }
    setIsEditing(false);
  };

  return isEditing ? (
    <div className="relative z-50 flex h-full w-full items-center">
      <div className="absolute inset-0 flex items-center duration-200 ease-out animate-in fade-in">
        <div className="relative h-full w-full">
          <div
            className={cn(
              'pointer-events-none absolute -inset-[1px] rounded-[2px]',
              'border border-primary/80',
              'shadow-[0_0_0_3px_rgba(0,0,0,0.02)]',
              'duration-200 ease-out animate-in fade-in',
              error && 'border-destructive/80',
            )}
          />
          <Input
            ref={inputRef}
            value={value}
            onChange={handleChange}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
            className={cn(
              'h-full w-full rounded-[2px]',
              'border-0 bg-background/90',
              'px-2 py-0',
              'focus-visible:ring-0 focus-visible:ring-offset-0',
              'placeholder:text-muted-foreground/50',
              'selection:bg-primary/15',
              'backdrop-blur-[1px]',
              'duration-200 ease-out animate-in fade-in',
            )}
          />
        </div>
      </div>
    </div>
  ) : (
    <div
      className="relative flex h-full w-full items-center"
      onDoubleClick={handleDoubleClick}
    >
      <div
        className={cn(
          'flex h-full w-full cursor-text select-none items-center px-2',
          'active:bg-primary/8 hover:bg-primary/5',
          'transition-all duration-200 ease-out',
          meta.editingCell === cell.id && [
            'bg-primary/4',
            'outline outline-[1px] outline-primary/25',
            'duration-200 ease-out animate-in fade-in',
          ],
          meta.isEdited(cell.row.index, cell.column.id) && [
            'bg-amber-50/80 dark:bg-amber-500/30',
            'text-amber-900 dark:text-amber-100',
            'font-medium',
            'border-l-2 border-amber-400/50 dark:border-amber-400/30',
          ],
        )}
      >
        <span className="truncate">
          {editConfig?.formatValue?.(value, cell.column.id) ?? value}
        </span>
      </div>
    </div>
  );
}

function TableHeader<TData>({ table }: { table: Table<TData> }) {
  return (
    <thead
      className={cn(
        'sticky top-0 z-10',
        'before:absolute before:inset-0 before:-z-10',
        'before:backdrop-blur-[8px] before:backdrop-saturate-[1.8]',
        'bg-gradient-to-b from-background/70 via-background/60 to-background/50',
        'supports-[backdrop-filter]:bg-background/40',
        'border-b border-border/50',
        'shadow-[0_2px_4px_rgba(0,0,0,0.08)]',
        'transition-all duration-200',
      )}
    >
      <tr>
        {table.getAllColumns().map((column) => (
          <th
            key={column.id}
            className={cn(
              'relative border-r border-border/50 p-1.5 last:border-r-0',
              'bg-gradient-to-b from-white/[0.02] via-white/[0.01] to-transparent',
              'group hover:bg-white/[0.02]',
              'transition-colors duration-200',
            )}
          >
            <span className="block text-[11px] font-medium text-muted-foreground/90">
              {column.id}
            </span>

            <Input
              className={cn(
                'mt-0.5 h-4 text-[11px]',
                'px-1.5 py-0',
                'bg-background/40',
                'border-border/40',
                'focus:bg-background/60',
                'focus:border-primary/50 focus:ring-1 focus:ring-primary/20',
                'placeholder:text-muted-foreground/40',
                'transition-all duration-200',
                'group-hover:bg-background/50',
                'group-hover:border-border/50',
              )}
              value={(column.getFilterValue() as string) ?? ''}
              onChange={(e) => column.setFilterValue(e.target.value)}
            />
          </th>
        ))}
      </tr>
    </thead>
  );
}

const DEFAULT_ROW_HEIGHT = 32;
const DEFAULT_MAX_HEIGHT = 660;

export function DataTable<TData extends Record<string, any>>({
  data: initialData,
  columns,
  onDataChange,
  editConfig,
  rowHeight = DEFAULT_ROW_HEIGHT,
  maxHeight = DEFAULT_MAX_HEIGHT,
  renderStats = TableStats,
  className,
  errors = [],
}: DataTableProps<TData>) {
  const [data, setData] = useState<TData[]>(initialData);
  const [editedCells] = useState(new Set<string>());
  const [editingCell, setEditingCell] = useState<string>();

  useEffect(() => {
    onDataChange?.(data);
  }, [data, onDataChange]);

  const tableMeta: TableMeta<TData> = {
    updateData: (rowIndex: number, columnId: string, value: string) => {
      setData((old) =>
        old.map((row, index) => {
          if (index === rowIndex) {
            editedCells.add(`${rowIndex}-${columnId}`);
            return {
              ...old[rowIndex],
              [columnId]: value,
            };
          }
          return row;
        }),
      );
    },
    editingCell,
    switchEditingCell: (cell) => {
      setEditingCell(cell.id);
    },
    isEdited: (rowIndex: number, columnId: string) => {
      return editedCells.has(`${rowIndex}-${columnId}`);
    },
    editedCells,
    editConfig,
  };

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    meta: tableMeta,
  });

  const filteredRowCount = table.getFilteredRowModel().rows.length;
  const contentHeight = filteredRowCount * rowHeight + 70;
  const containerHeight = Math.min(maxHeight, contentHeight);

  return (
    <div className="flex flex-col gap-1">
      <div
        className={cn(
          'flex flex-col overflow-auto rounded-lg',
          'border border-border/50',
          'bg-gradient-to-b from-card via-card/95 to-card/90',
          'shadow-[0_2px_10px_rgba(0,0,0,0.06)]',
          'transition-all duration-300 ease-in-out',
          className,
        )}
        style={{ height: containerHeight }}
      >
        <UITable>
          <TableHeader table={table} />
          <TableBody>
            {table.getRowModel().rows.length ? (
              table.getRowModel().rows.map((row, index) => (
                <TableRow
                  key={row.id}
                  className={cn(
                    'group border-b border-border/50',
                    'transition-colors duration-150',
                    'hover:bg-muted/50',
                    index % 2 === 0
                      ? 'bg-card'
                      : 'bg-muted/60 dark:bg-muted/30',
                  )}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell
                      key={cell.id}
                      className={cn(
                        'border-r border-border/50 p-0 text-sm',
                        'last:border-r-0',
                        'group-hover:bg-muted/30',
                        'transition-colors duration-150',
                      )}
                      style={{ height: rowHeight }}
                    >
                      <EditableCell cell={cell} />
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={table.getAllColumns().length}
                  className="h-32 text-center text-muted-foreground"
                >
                  No data available
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </UITable>
      </div>

      {renderStats &&
        renderStats({
          table,
          editedCells: editedCells.size,
          data: initialData,
          errors,
        })}
    </div>
  );
}
