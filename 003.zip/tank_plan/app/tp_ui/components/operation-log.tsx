import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { RefreshCw, Upload, FileDown, History } from 'lucide-react';

interface OperationLogProps {
  refreshing: boolean;
  onRefresh: () => void;
}

export function OperationLog({ refreshing, onRefresh }: OperationLogProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Operation Log</CardTitle>
            <CardDescription>Recent system activities</CardDescription>
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={onRefresh}
            disabled={refreshing}
          >
            <RefreshCw
              className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`}
            />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Action</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Target</TableHead>
              <TableHead>Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {[...Array(5)].map((_, i) => (
              <TableRow key={i}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {i % 3 === 0 ? (
                      <Upload className="h-4 w-4 text-blue-500" />
                    ) : i % 3 === 1 ? (
                      <FileDown className="h-4 w-4 text-green-500" />
                    ) : (
                      <History className="h-4 w-4 text-amber-500" />
                    )}
                    <span>
                      {i % 3 === 0
                        ? 'Uploaded'
                        : i % 3 === 1
                          ? 'Exported'
                          : 'Updated'}
                    </span>
                  </div>
                </TableCell>
                <TableCell>User {i + 1}</TableCell>
                <TableCell>Plan {i + 1}</TableCell>
                <TableCell className="text-muted-foreground">
                  {`${i + 1}h ago`}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
