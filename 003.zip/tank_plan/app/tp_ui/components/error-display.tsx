import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { AlertCircle, X } from 'lucide-react';
import { useState, useEffect } from 'react';

export interface ErrorDisplayProps {
  errors: string[];
  title?: string;
  description?: string;
  className?: string;
  position?: 'fixed' | 'absolute' | 'relative';
  maxHeight?: number;
  showClose?: boolean;
  onClose?: () => void;
  icon?: React.ReactNode;
  variant?: 'error' | 'warning' | 'info';
}

const variantStyles = {
  error: {
    border: 'border-destructive/30',
    bg: 'bg-destructive/5',
    text: 'text-destructive',
    iconBg: 'bg-destructive/10',
  },
  warning: {
    border: 'border-yellow-500/30',
    bg: 'bg-yellow-500/5',
    text: 'text-yellow-700',
    iconBg: 'bg-yellow-500/10',
  },
  info: {
    border: 'border-blue-500/30',
    bg: 'bg-blue-500/5',
    text: 'text-blue-700',
    iconBg: 'bg-blue-500/10',
  },
};

export function ErrorDisplay({
  errors,
  title = 'Validation Failed',
  description = 'Please fix the errors and try again',
  className,
  position = 'fixed',
  maxHeight = 240,
  showClose = true,
  onClose,
  icon,
  variant = 'error',
}: ErrorDisplayProps) {
  const [show, setShow] = useState(true);
  const styles = variantStyles[variant];

  useEffect(() => {
    if (errors.length > 0) {
      setShow(true);
    }
  }, [errors]);

  if (!errors.length || !show) return null;

  const handleClose = () => {
    setShow(false);
    onClose?.();
  };

  const containerStyles = {
    fixed: 'fixed left-1/2 top-6 z-50 -translate-x-1/2',
    absolute: 'absolute left-1/2 top-6 z-50 -translate-x-1/2',
    relative: 'relative w-full',
  };

  return (
    <div className={cn(containerStyles[position], className)}>
      <div
        className={cn(
          'w-[600px] rounded-lg',
          `border ${styles.border}`,
          `${styles.bg} backdrop-blur-lg`,
          'shadow-lg',
          'duration-300 animate-in slide-in-from-top-4',
          'supports-[backdrop-filter]:bg-opacity-[0.03]',
        )}
      >
        <div className="relative p-4">
          {showClose && (
            <button
              onClick={handleClose}
              className={cn(
                'absolute right-2 top-2',
                'rounded-md p-1',
                `${styles.text}/50 hover:${styles.text}`,
                'transition-colors duration-200',
              )}
            >
              <X className="h-4 w-4" />
            </button>
          )}

          <div className="flex items-center gap-2">
            <div className={cn('rounded-full p-1', styles.iconBg)}>
              {icon || <AlertCircle className={cn('h-4 w-4', styles.text)} />}
            </div>
            <h4 className={cn('font-medium', styles.text)}>{title}</h4>
          </div>

          <ScrollArea
            className={cn(
              'mt-3 pr-4',
              'scrollbar-thin',
              `scrollbar-track-${styles.text}/5`,
              `scrollbar-thumb-${styles.text}/20`,
            )}
            style={{ maxHeight }}
          >
            <ul className={cn('space-y-2 pl-6 text-sm', `${styles.text}/90`)}>
              {errors.map((error, index) => (
                <li
                  key={index}
                  className={cn(
                    'list-disc leading-relaxed',
                    'animate-in fade-in slide-in-from-bottom-1',
                    'duration-300',
                  )}
                >
                  {error}
                </li>
              ))}
            </ul>
          </ScrollArea>

          <div
            className={cn(
              'mt-3 flex items-center justify-between',
              'border-t pt-3 text-xs',
              `border-${styles.text}/10`,
              `${styles.text}/70`,
            )}
          >
            <div>
              {errors.length} {errors.length === 1 ? 'error' : 'errors'} found
            </div>
            <div>{description}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
