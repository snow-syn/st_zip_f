'use client';

import { usePathname, useRouter } from 'next/navigation';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion, AnimatePresence } from 'framer-motion';
import { useCallback, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Home } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  {
    value: 'long-term-plan',
    label: 'Long-term Plan',
    href: '/tp_ui/long-term',
  },
  {
    value: 'weekly',
    label: 'Weekly',
    href: '/tp_ui/weekly',
  },
  {
    value: 'plan-list',
    label: 'Plan List',
    href: '/tp_ui/plan-list',
  },
  {
    value: 'tank-detail',
    label: 'Tank Detail',
    href: '/tp_ui/tank-detail',
  },
];

export default function TPUILayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();

  const getCurrentTab = useCallback(() => {
    const path = pathname.split('/').pop();
    return path || 'gb-plan';
  }, [pathname]);

  const previousTab = useRef(getCurrentTab());

  const getAnimationDirection = useCallback(() => {
    const current = navItems.findIndex(
      (item) => item.value === getCurrentTab(),
    );
    const previous = navItems.findIndex(
      (item) => item.value === previousTab.current,
    );
    return current > previous ? 1 : -1;
  }, [getCurrentTab]);

  useEffect(() => {
    previousTab.current = getCurrentTab();
  }, [getCurrentTab]);

  return (
    <div className="fixed inset-0 flex flex-col bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-50 via-zinc-100 to-zinc-100 dark:from-zinc-800 dark:via-zinc-900 dark:to-zinc-900">
      <motion.div
        initial={false}
        className="relative z-50 border-b border-slate-200/50 bg-white/80 shadow-sm backdrop-blur-xl dark:border-slate-800/50 dark:bg-zinc-900/80 dark:shadow-none"
      >
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.push('/tp_ui')}
              className={cn(
                'h-16 w-16 rounded-none border-b-2 border-transparent',
                'hover:bg-slate-100/50 dark:hover:bg-slate-800/50',
                'transition-colors duration-200',
              )}
            >
              <Home className="h-5 w-5 text-slate-600 dark:text-slate-400" />
            </Button>

            <Tabs
              value={getCurrentTab()}
              onValueChange={(value) => {
                const item = navItems.find((item) => item.value === value);
                if (item) {
                  router.push(item.href);
                }
              }}
              className="w-full"
            >
              <div className="scrollbar-hide -mx-4 overflow-x-auto px-4">
                <TabsList className="inline-flex h-16 w-full min-w-max items-center justify-start gap-1 bg-transparent p-0 px-1">
                  {navItems.map((item) => (
                    <TabsTrigger
                      key={item.value}
                      value={item.value}
                      className="group relative inline-flex h-9 items-center justify-center whitespace-nowrap rounded-md px-4 py-1 text-sm font-medium text-slate-600 ring-offset-background transition-all hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 dark:focus-visible:ring-slate-800 dark:data-[state=active]:text-white"
                    >
                      <span className="relative z-10 transition-transform duration-200 ease-out group-hover:scale-[1.02]">
                        {item.label}
                      </span>
                      <AnimatePresence>
                        {getCurrentTab() === item.value && (
                          <motion.div
                            className="absolute inset-0 rounded-md bg-slate-100/70 dark:bg-slate-800/50"
                            layoutId="activeTabBackground"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{
                              type: 'spring',
                              stiffness: 400,
                              damping: 30,
                            }}
                          />
                        )}
                      </AnimatePresence>
                      <AnimatePresence>
                        {getCurrentTab() === item.value && (
                          <motion.div
                            className="absolute bottom-0 left-0 right-0 h-[2px] bg-slate-900 dark:bg-slate-200"
                            layoutId="activeTabLine"
                            initial={{ opacity: 0, scale: 0.5 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.5 }}
                            transition={{
                              type: 'spring',
                              stiffness: 400,
                              damping: 30,
                            }}
                          />
                        )}
                      </AnimatePresence>
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>
            </Tabs>
          </div>
        </div>
      </motion.div>
      <div className="flex-1 overflow-hidden">
        <div className="h-full p-4">{children}</div>
      </div>
    </div>
  );
}
