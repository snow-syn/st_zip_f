'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { ErrorDisplay } from '@/app/tp_ui/components/error-display';
import { UploadZone } from './components';
import type { TankPlanDetailData } from '../types';
import { useLoadData } from '../hooks/useLoadData';
import { useSaveData } from '../hooks/useSaveData';
import { LTPlanTable } from './components';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Info, Save, Upload, FileDown, CalendarRange } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useValidation } from '../hooks/useValidation';
import { useExport } from '../hooks/useExport';
import { ValidationDialog } from '@/app/tp_ui/components/validation-dialog';
import { Button } from '@/components/ui/button';
import { ExcelProcessor } from '@/app/tp_ui/utils/excel-processor';
import { ltPlanExcelConfig } from '@/app/tp_ui/config/excel-config';

const PageTransition = ({
  children,
  show,
}: {
  children: React.ReactNode;
  show: boolean;
}) => (
  <motion.div
    initial={false}
    animate={{
      opacity: show ? 1 : 0,
      y: show ? 0 : 10,
      scale: show ? 1 : 0.98,
    }}
    transition={{
      duration: 0.2,
      ease: [0.32, 0.72, 0, 1],
    }}
  >
    {children}
  </motion.div>
);

const ContentTransition = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 10, scale: 0.98 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    exit={{ opacity: 0, y: -10, scale: 0.98 }}
    transition={{
      duration: 0.2,
      ease: [0.32, 0.72, 0, 1],
    }}
  >
    {children}
  </motion.div>
);

// 创建一个包含 useSearchParams 的组件
function LTPlanContent() {
  const [data, setData] = useState<TankPlanDetailData[]>([]);
  const [currentData, setCurrentData] = useState<TankPlanDetailData[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showTable, setShowTable] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const searchParams = useSearchParams();
  const planId = searchParams.get('id');

  const { loadLatestPlan, isLoading: isLoadingLatest } = useLoadData();
  const { saveData, isSaving: isDataSaving } = useSaveData();
  const { toast } = useToast();
  const { handleExport, isExporting } = useExport(
    currentData,
    ltPlanExcelConfig,
  );
  const [showValidateDialog, setShowValidateDialog] = useState(false);
  const {
    validationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
  } = useValidation();

  // 加载指定ID的计划数据
  const loadPlanById = async (id: string) => {
    const context = {
      module: 'LTPlan',
      function: 'loadPlanById',
      planId: id,
    };

    try {
      logger.group('Loading plan by ID', context);
      setIsLoading(true);
      setErrors([]);

      const result = await DatabaseService.getVersionData(Number(id));

      logger.debug('Plan data loaded', context, {
        success: result.success,
        dataLength: result.data?.length,
        error: result.error,
      });

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load plan data');
      }

      setIsTransitioning(true);
      await new Promise((resolve) => setTimeout(resolve, 150));

      setData(result.data);
      setCurrentData(result.data);

      requestAnimationFrame(() => {
        setShowTable(true);
        setTimeout(() => {
          setIsTransitioning(false);
        }, 50);
      });

      logger.debug('Plan data set successfully', context, {
        dataLength: result.data.length,
      });
    } catch (error) {
      logger.error('Failed to load plan', context, { error });
      setErrors([
        error instanceof Error ? error.message : 'Failed to load plan data',
      ]);
    } finally {
      setIsLoading(false);
      logger.groupEnd();
    }
  };

  // 初始化时检查URL参数
  useEffect(() => {
    const context = {
      module: 'LTPlan',
      function: 'initializeComponent',
      planId,
    };

    logger.debug('Component initializing', context);

    if (planId) {
      logger.debug('Plan ID found in URL, loading plan', context);
      loadPlanById(planId);
    }
  }, [planId]);

  const handleFileUpload = async (file: File) => {
    try {
      setIsLoading(true);
      setErrors([]);

      const excelProcessor = new ExcelProcessor(ltPlanExcelConfig);
      const { data: processedData, errors: importErrors } =
        await excelProcessor.processFile(file);

      if (importErrors.length > 0) {
        setErrors(importErrors);
        if (processedData.length === 0) {
          return;
        }
      }

      if (importErrors.length === 0) {
        setIsTransitioning(true);
        await new Promise((resolve) => setTimeout(resolve, 150));

        setData(processedData);
        setCurrentData(processedData);

        requestAnimationFrame(() => {
          setShowTable(true);
          setTimeout(() => {
            setIsTransitioning(false);
          }, 50);
        });
      }
    } catch (err) {
      console.error('Excel import error:', err);
      setErrors((prev) => [
        ...prev,
        err instanceof Error ? err.message : 'Failed to import Excel file',
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSwitchToUpload = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setShowTable(false);
      setTimeout(() => {
        setIsTransitioning(false);
      }, 50);
    }, 150);
  };

  const handleSave = async () => {
    try {
      setShowValidateDialog(true);
      setIsValidating(true);
      setValidationErrors([]);

      updateStepStatus('format', 'pending');
      updateStepStatus('required', 'pending');
      updateStepStatus('business', 'pending');
      updateStepStatus('save', 'pending');

      const errors = await validateData(currentData);

      if (errors.length > 0) {
        setValidationErrors(errors);
        return;
      }

      setIsValidating(false);
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to validate data',
      });
      setIsValidating(false);
    }
  };

  const handleConfirmSave = async () => {
    try {
      updateStepStatus('save', 'processing');
      setIsSaving(true);

      const success = await saveData(currentData, 'Long-term');

      if (success) {
        updateStepStatus('save', 'success');
        setTimeout(() => {
          setShowValidateDialog(false);
        }, 1000);
      } else {
        updateStepStatus('save', 'error', 'Failed to save data');
      }
    } catch (error) {
      console.error('Save error:', error);
      updateStepStatus('save', 'error', 'Failed to save data');
    } finally {
      setIsSaving(false);
    }
  };

  const handleLoadLatest = async () => {
    console.group('🔄 Load Latest Plan Flow');
    const startTime = performance.now();

    try {
      console.log('Starting load process...', {
        currentState: {
          hasData: data.length > 0,
          showTable,
          isTransitioning,
        },
      });

      setErrors([]);

      const result = await loadLatestPlan();
      console.log('Load result:', {
        success: result.success,
        dataLength: result.data?.length,
        error: result.error,
        debug: result.debug,
      });

      if (!result.success) {
        throw new Error(result.error);
      }

      setIsTransitioning(true);
      console.log('Starting transition...');
      await new Promise((resolve) => setTimeout(resolve, 150));

      setData(result.data!);
      setCurrentData(result.data!);
      console.log('Data updated', {
        rowCount: result.data!.length,
        sampleRow: result.data![0],
      });

      requestAnimationFrame(() => {
        setShowTable(true);
        console.log('Table visibility updated');

        setTimeout(() => {
          setIsTransitioning(false);
          console.log('Transition completed');
        }, 50);
      });

      toast({
        title: 'Data Loaded Successfully',
        description: `Loaded ${result.data!.length} rows from the latest plan`,
      });

      const totalTime = performance.now() - startTime;
      console.log('Load process completed', {
        totalTime: `${totalTime.toFixed(2)}ms`,
        finalState: {
          dataLength: result.data!.length,
          showTable,
          isTransitioning,
        },
      });
    } catch (err) {
      console.error('Load error:', {
        error: err,
        message: err instanceof Error ? err.message : 'Unknown error',
        stack: err instanceof Error ? err.stack : undefined,
      });

      setErrors((prev) => [
        ...prev,
        err instanceof Error ? err.message : 'Failed to load latest plan',
      ]);
    } finally {
      console.groupEnd();
    }
  };

  const ExportButton = ({
    onExport,
    isExporting,
    disabled,
  }: {
    onExport: () => Promise<void>;
    isExporting: boolean;
    disabled: boolean;
  }) => (
    <Button
      variant="outline"
      size="sm"
      onClick={onExport}
      disabled={disabled || isExporting}
    >
      <FileDown
        className={cn('mr-2 h-4 w-4', isExporting && 'animate-pulse')}
      />
      {isExporting ? 'Exporting...' : 'Export Excel'}
    </Button>
  );

  const SaveButton = () => (
    <Button
      variant="outline"
      size="sm"
      onClick={handleSave}
      disabled={isLoading || isTransitioning || isSaving || data.length === 0}
    >
      <Save className={cn('mr-2 h-4 w-4', isSaving && 'animate-pulse')} />
      {isSaving ? 'Saving...' : 'Validate & Save'}
    </Button>
  );

  const UploadButton = () => (
    <Button
      variant="outline"
      size="sm"
      onClick={handleSwitchToUpload}
      disabled={isLoading || isTransitioning}
    >
      <Upload className="mr-2 h-4 w-4" />
      Re-upload
    </Button>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="flex h-full flex-col"
    >
      <div className="min-h-0 flex-1">
        <ErrorDisplay
          errors={errors}
          title="Validation Failed"
          description="Please fix the errors and try again"
          variant="error"
          onClose={() => {
            setErrors([]);
          }}
        />

        <PageTransition show={!isTransitioning}>
          <AnimatePresence mode="wait">
            {!showTable ? (
              <ContentTransition key="upload">
                <div className="h-full">
                  <div className="mb-6 px-6">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                        <CalendarRange className="h-4 w-4 text-primary" />
                      </div>
                      <h1 className="text-xl font-semibold tracking-tight">
                        Long-term Plan
                      </h1>
                    </div>
                  </div>

                  <UploadZone
                    onFileSelect={handleFileUpload}
                    onLoadLatest={handleLoadLatest}
                    isLoading={isLoading}
                    isLoadingLatest={isLoadingLatest}
                  />
                </div>
              </ContentTransition>
            ) : (
              <ContentTransition key="table">
                <div className="flex h-full flex-col gap-4">
                  <motion.div
                    className="flex-none"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2, duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between rounded-lg px-4 py-2">
                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                            <CalendarRange className="h-4 w-4 text-primary" />
                          </div>
                          <h1 className="text-xl font-semibold tracking-tight">
                            Long-term Plan
                          </h1>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Info className="h-4 w-4" />
                            {`${data.length} rows loaded`}
                          </div>
                          {errors.length > 0 && (
                            <>
                              <div className="h-4 w-[1px] bg-border/50" />
                              <div className="flex items-center gap-2 text-sm text-yellow-500">
                                <div className="h-1.5 w-1.5 rounded-full bg-yellow-500" />
                                {errors.length} warnings
                              </div>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <SaveButton />
                        <UploadButton />
                        <ExportButton
                          onExport={handleExport}
                          isExporting={isExporting}
                          disabled={isLoading || data.length === 0}
                        />
                      </div>
                    </div>
                  </motion.div>

                  <motion.div
                    className="min-h-0 flex-1 overflow-auto"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.2 }}
                  >
                    <LTPlanTable
                      data={data}
                      errors={errors}
                      onDataChange={setCurrentData}
                    />
                  </motion.div>
                </div>
              </ContentTransition>
            )}
          </AnimatePresence>
        </PageTransition>
      </div>

      <ValidationDialog
        open={showValidateDialog}
        onOpenChange={setShowValidateDialog}
        isValidating={isValidating}
        isSaving={isSaving}
        validationErrors={validationErrors}
        validationSteps={validationSteps}
        onConfirmSave={handleConfirmSave}
      />
    </motion.div>
  );
}

// 主组件使用 Suspense 包裹
export default function LTPlan() {
  return (
    <Suspense
      fallback={
        <div className="flex h-full items-center justify-center">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span className="text-sm text-muted-foreground">Loading...</span>
          </div>
        </div>
      }
    >
      <LTPlanContent />
    </Suspense>
  );
}
