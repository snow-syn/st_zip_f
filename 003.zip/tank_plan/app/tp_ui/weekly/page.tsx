'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { ErrorDisplay } from '@/app/tp_ui/components/error-display';
import type { TankPlanDetailData, PlanVersion } from '../types';
import { useExport } from '../hooks/useExport';
import { ltPlanExcelConfig } from '../config/excel-config';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import {
  FileDown,
  CalendarRange,
  Save,
  User,
  Clock,
  Table,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/app/tp_ui/components/DataTable';
import { TANK_COLUMNS, DATE_COLUMNS, type ColumnKey } from '../config/config';
import { StringUtils, DateUtils, ValidationUtils } from '../utils';
import { TypeBadge, TagBadge } from '../plan-list/components/badges';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { useValidation } from '../hooks/useValidation';
import { ValidationDialog } from '../components/validation-dialog';
import { useSaveData } from '../hooks/useSaveData';
import { useToast } from '@/hooks/use-toast';

// 创建表格列配置
const columns = TANK_COLUMNS.map((key: ColumnKey) => ({
  accessorKey: key,
  header: key,
  cell: ({ getValue }: { getValue: () => unknown }) => {
    const value = getValue() as string;
    const isDateColumn = DATE_COLUMNS.includes(key as any);
    return isDateColumn ? DateUtils.format(value) : value;
  },
}));

// 版本信息卡片组件
const VersionInfoCard = ({
  version,
  onSave,
  onExport,
  isSaving,
  isExporting,
  isLoading,
  hasData,
}: {
  version: PlanVersion;
  onSave: () => void;
  onExport: () => Promise<void>;
  isSaving: boolean;
  isExporting: boolean;
  isLoading: boolean;
  hasData: boolean;
}) => (
  <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
    <div className="p-4">
      <div className="flex items-start justify-between">
        {/* 左侧信息 */}
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold tracking-tight">
              {version.plan_version}
            </h2>
            <TypeBadge type={version.plan_type} />
            {version.plan_official && <TagBadge tag={version.plan_official} />}
            {version.plan_version_no > 1 && (
              <Badge variant="outline" className="h-5 px-1.5">
                v{version.plan_version_no}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <User className="h-3.5 w-3.5" />
              <span>{version.user_name}</span>
            </div>
            <div>•</div>
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              <span>{format(new Date(version.create_timestamp), 'PPp')}</span>
            </div>
            <div>•</div>
            <div className="flex items-center gap-1.5">
              <Table className="h-3.5 w-3.5" />
              <span>{version.row_count} rows</span>
            </div>
          </div>
        </div>

        {/* 右侧按钮 */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onSave}
            disabled={isLoading || isSaving || !hasData}
          >
            <Save className={cn('mr-2 h-4 w-4', isSaving && 'animate-pulse')} />
            {isSaving ? 'Saving...' : 'Validate & Save'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onExport}
            disabled={isLoading || !hasData || isExporting}
          >
            <FileDown
              className={cn('mr-2 h-4 w-4', isExporting && 'animate-pulse')}
            />
            {isExporting ? 'Exporting...' : 'Export Excel'}
          </Button>
        </div>
      </div>
    </div>
  </div>
);

// 创建一个包含 useSearchParams 的内容组件
function WeeklyPlanContent() {
  const router = useRouter();
  const [data, setData] = useState<TankPlanDetailData[]>([]);
  const [versionInfo, setVersionInfo] = useState<PlanVersion | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const searchParams = useSearchParams();
  const planId = searchParams.get('id');

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);
  const { saveData, isSaving } = useSaveData();
  const { toast } = useToast();
  const {
    validationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
  } = useValidation();
  const [showValidateDialog, setShowValidateDialog] = useState(false);
  const [showConfirmSave, setShowConfirmSave] = useState(false);

  // 修改初始化加载逻辑
  useEffect(() => {
    const context = {
      module: 'WeeklyPlan',
      function: 'initializeComponent',
      planId,
    };

    logger.debug('Component initializing', context);

    const loadData = async () => {
      if (!planId) {
        logger.debug('No plan ID provided', context);
        return;
      }

      try {
        logger.debug('Loading plan data', context);
        setIsLoading(true);
        setErrors([]);

        // 同时加载数据和版本信息
        const [dataResult, versionResult] = await Promise.all([
          DatabaseService.getVersionData(Number(planId)),
          DatabaseService.getVersionInfo(Number(planId)),
        ]);

        if (!dataResult.success || !dataResult.data) {
          throw new Error(dataResult.error || 'Failed to load plan data');
        }

        if (!versionResult.success || !versionResult.data) {
          throw new Error(versionResult.error || 'Failed to load version info');
        }

        setData(dataResult.data);
        setVersionInfo(versionResult.data);

        logger.debug('Data loaded successfully', context, {
          dataCount: dataResult.data.length,
          version: versionResult.data.plan_version,
        });
      } catch (error) {
        logger.error('Failed to load data', context, { error });
        setErrors([
          error instanceof Error ? error.message : 'Failed to load data',
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [planId]);

  // 修改处理保存逻辑
  const handleSave = async () => {
    try {
      setShowValidateDialog(true);
      setIsValidating(true);
      setValidationErrors([]);

      updateStepStatus('format', 'pending');
      updateStepStatus('required', 'pending');
      updateStepStatus('business', 'pending');
      updateStepStatus('save', 'pending');

      const errors = await validateData(data);

      if (errors.length > 0) {
        setValidationErrors(errors);
        return;
      }

      // 验证通过后，显示确认对话框而不是直接保存
      setShowConfirmSave(true);
      setIsValidating(false);
    } catch (error) {
      logger.error('Validation failed', {
        module: 'WeeklyPlan',
        error,
      });
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to validate data',
      });
      setIsValidating(false);
    }
  };

  // 添加确认保存处理函数
  const handleConfirmSave = async () => {
    try {
      logger.debug('Starting save operation', {
        module: 'WeeklyPlan',
        function: 'handleConfirmSave',
      });

      updateStepStatus('save', 'processing');

      const success = await saveData(data, 'Weekly');

      if (success) {
        updateStepStatus('save', 'success');

        // 显示成功提示
        toast({
          title: 'Success',
          description: 'Plan saved successfully',
        });

        // 等待动画完成后跳转
        setTimeout(() => {
          setShowValidateDialog(false);
          // 跳转到首页
          router.push('/tp_ui');
          // 触发全���事件来刷新 plan list
          const refreshEvent = new CustomEvent('refreshPlanList');
          window.dispatchEvent(refreshEvent);
        }, 1000);
      } else {
        updateStepStatus('save', 'error', 'Failed to save data');
      }
    } catch (error) {
      logger.error('Save error:', {
        module: 'WeeklyPlan',
        function: 'handleConfirmSave',
        error,
      });
      updateStepStatus('save', 'error', 'Failed to save data');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
      className="flex h-full flex-col"
    >
      {/* 标题栏 */}
      <div className="flex-none px-4 py-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <CalendarRange className="h-4 w-4 text-primary" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight">Weekly Plan</h1>
        </div>
      </div>

      {/* 版本信息 */}
      <div className="flex-none px-4">
        <AnimatePresence mode="wait">
          {versionInfo && (
            <motion.div
              key={versionInfo.plan_master_id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <VersionInfoCard
                version={versionInfo}
                onSave={handleSave}
                onExport={handleExport}
                isSaving={isSaving}
                isExporting={isExporting}
                isLoading={isLoading}
                hasData={data.length > 0}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 错误提示 */}
      <div className="flex-none px-4">
        <ErrorDisplay
          errors={errors}
          title="Error"
          description="Failed to load plan data"
          variant="error"
          onClose={() => setErrors([])}
        />
      </div>

      {/* 数据表格 */}
      <div className="min-h-0 flex-1 p-4">
        <AnimatePresence mode="wait">
          {data.length > 0 && (
            <motion.div
              key={planId}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-full w-full"
            >
              <div className="h-full w-full">
                <DataTable
                  data={data}
                  columns={columns}
                  editConfig={{
                    allowEdit: true,
                    validateCell: (value, columnId) => {
                      const isDateColumn = DATE_COLUMNS.includes(
                        columnId as any,
                      );
                      return isDateColumn
                        ? ValidationUtils.validateDate(value, columnId)
                        : null;
                    },
                    formatValue: (value, columnId) => {
                      const isDateColumn = DATE_COLUMNS.includes(
                        columnId as any,
                      );
                      return isDateColumn ? DateUtils.format(value) : value;
                    },
                  }}
                  onDataChange={setData}
                  className="h-full w-full"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 验证对话框 */}
      <ValidationDialog
        open={showValidateDialog}
        onOpenChange={(open) => {
          setShowValidateDialog(open);
          if (!open) {
            setShowConfirmSave(false);
          }
        }}
        validationSteps={validationSteps}
        errors={validationErrors}
        isValidating={isValidating}
        isSaving={isSaving}
        onConfirmSave={showConfirmSave ? handleConfirmSave : undefined}
      />
    </motion.div>
  );
}

// 主组件使用 Suspense 包裹
export default function WeeklyPlan() {
  return (
    <Suspense
      fallback={
        <div className="flex h-full items-center justify-center">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span className="text-sm text-muted-foreground">Loading...</span>
          </div>
        </div>
      }
    >
      <WeeklyPlanContent />
    </Suspense>
  );
}
