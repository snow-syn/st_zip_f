'use client';

import { motion } from 'framer-motion';

export default function TankDetails() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="p-6"
    >
      <h1 className="mb-4 text-2xl font-bold">Tank Details</h1>
      <p>Content coming soon...</p>
    </motion.div>
  );
}
