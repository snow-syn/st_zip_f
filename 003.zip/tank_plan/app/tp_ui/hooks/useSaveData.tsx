import { useState } from 'react';
import type { TankPlanDetailData, PlanType } from '@/app/tp_ui/types';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/app/tp_ui/utils/logger';

export function useSaveData() {
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const { toast } = useToast();

  const buildMasterInsertQuery = (planType: PlanType) => {
    const currentDate = new Date();
    const planVersion = `${currentDate.toISOString().split('T')[0]}`;
    const versionMatch = currentDate
      .toISOString()
      .substring(0, 7)
      .replace('-', '');

    return {
      sql: `
        WITH latest_version AS (
          SELECT COALESCE(MAX(plan_version_no), 0) as max_version_no
          FROM app_tank_plan_master
          WHERE plan_version = ?
        )
        INSERT INTO app_tank_plan_master (
          plan_version,
          plan_type,
          plan_official,
          plan_version_no,
          version_match,
          user_name
        ) 
        SELECT 
          ?,
          ?,
          '',
          (latest_version.max_version_no + 1),
          ?,
          'system'
        FROM latest_version;
      `,
      params: [planVersion, planVersion, planType, versionMatch],
    };
  };

  const buildDetailInsertQuery = (
    planMasterId: number,
    data: TankPlanDetailData[],
  ) => {
    const placeholders = data
      .map(
        () =>
          '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      )
      .join(',');

    const params = data.flatMap((row) => [
      planMasterId,
      row.plan_row_id,
      row.tank,
      row.iso || null,
      row.glass_type || null,
      row.gen || null,
      row.RT || null,
      row.RC || null,
      row.platform || null,
      row.design_asis || null,
      row.tank_life || null,
      row.last_tank_light_date || null,
      row.drain_date || null,
      row.repair_date || null,
      row.RTL_date || null,
      row.TL_date || null,
      row.GG_date || null,
      row.cold_idle || null,
      row.repair_LT || null,
      row.RTL_LT || null,
      row.TL_LT || null,
      row.remark_category || null,
      row.remark || null,
      row.comment || null,
      'system',
    ]);

    logger.debug('Detail insert parameters validation', {
      planMasterId,
      parameterCount: params.length,
      firstRowParams: params.slice(0, 25),
      expectedParamsPerRow: 25,
      totalRows: data.length,
      planMasterIds: params.filter((_, index) => index % 25 === 0),
    });

    return {
      sql: `
        INSERT INTO app_tank_plan_detail (
          plan_master_id,
          plan_row_id,
          tank,
          iso,
          glass_type,
          gen,
          RT,
          RC,
          platform,
          design_asis,
          tank_life,
          last_tank_light_date,
          drain_date,
          repair_date,
          RTL_date,
          TL_date,
          GG_date,
          cold_idle,
          repair_LT,
          RTL_LT,
          TL_LT,
          remark_category,
          remark,
          comment,
          user_name
        ) VALUES ${placeholders}
      `,
      params,
    };
  };

  const saveData = async (
    data: TankPlanDetailData[],
    planType: PlanType,
  ): Promise<boolean> => {
    if (isSaving || !data.length) return false;

    const context = {
      module: 'useSaveData',
      function: 'saveData',
      requestId: `save-${Date.now()}`,
      planType,
    };

    try {
      logger.group('Starting save operation', context);
      setIsSaving(true);
      setErrors([]);

      // 1. 插入 master 记录
      const masterQuery = buildMasterInsertQuery(planType);
      logger.debug('Master insert query', context, {
        sql: masterQuery.sql,
        parameters: masterQuery.params,
        planType,
      });

      const masterRequestBody = {
        warehouse_id: process.env.NEXT_PUBLIC_DATABRICKS_WAREHOUSE_ID,
        statement: masterQuery.sql,
        parameters: masterQuery.params,
      };

      logger.debug('Sending master insert request', context, {
        url: `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/2.0/sql/statements`,
        method: 'POST',
        body: masterRequestBody,
      });

      const masterResponse = await fetch(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/2.0/sql/statements`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_DATABRICKS_TOKEN}`,
          },
          body: JSON.stringify(masterRequestBody),
        },
      );

      const masterResult = await masterResponse.json();
      logger.debug('Master insert response', context, {
        status: masterResponse.status,
        statusText: masterResponse.statusText,
        headers: Object.fromEntries(masterResponse.headers.entries()),
        body: masterResult,
      });

      if (masterResult.status.state !== 'SUCCEEDED') {
        throw new Error(
          masterResult.status.error?.message ||
            'Failed to create master record',
        );
      }

      const planMasterId = masterResult.result.data_array[0][1];
      logger.info('Master record created', context, {
        planMasterId,
        masterResult: masterResult.result.data_array[0],
      });

      if (!planMasterId) {
        throw new Error('Failed to get plan_master_id from master record');
      }

      // 2. 插入 detail 记录
      const detailQuery = buildDetailInsertQuery(planMasterId, data);
      logger.debug('Detail insert query', context, {
        sql: detailQuery.sql,
        parameterCount: detailQuery.params.length,
        sampleParameters: detailQuery.params.slice(0, 25), // 只记录第一行的参数
      });

      const detailRequestBody = {
        warehouse_id: process.env.NEXT_PUBLIC_DATABRICKS_WAREHOUSE_ID,
        statement: detailQuery.sql,
        parameters: detailQuery.params,
      };

      logger.debug('Sending detail insert request', context, {
        url: `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/2.0/sql/statements`,
        method: 'POST',
        body: {
          ...detailRequestBody,
          parameters: `${detailRequestBody.parameters.length} parameters`, // 避免日志过大
        },
      });

      const detailResponse = await fetch(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/2.0/sql/statements`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_DATABRICKS_TOKEN}`,
          },
          body: JSON.stringify(detailRequestBody),
        },
      );

      const detailResult = await detailResponse.json();
      logger.debug('Detail insert response', context, {
        status: detailResponse.status,
        statusText: detailResponse.statusText,
        headers: Object.fromEntries(detailResponse.headers.entries()),
        body: detailResult,
      });

      if (detailResult.status.state !== 'SUCCEEDED') {
        throw new Error(
          detailResult.status.error?.message ||
            'Failed to create detail records',
        );
      }

      logger.info('Save operation completed', context, {
        masterRecordId: planMasterId,
        detailRecordsCount: data.length,
        timing: {
          total: performance.now() - performance.timeOrigin,
        },
      });

      toast({
        title: 'Success',
        description: `Saved ${data.length} rows successfully`,
      });
      return true;
    } catch (error) {
      logger.error('Save operation failed', context, {
        error,
        message: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
        data: {
          rowCount: data.length,
          sampleRow: data[0], // 记录第一行数据用于调试
        },
      });

      const message = error instanceof Error ? error.message : 'Unknown error';
      setErrors([message]);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: message,
      });
      return false;
    } finally {
      setIsSaving(false);
      logger.groupEnd();
    }
  };

  return {
    saveData,
    isSaving,
    errors,
  } as const;
}
