import { useState } from 'react';
import type { TankPlanDetailData } from '../types';
import { useToast } from '@/hooks/use-toast';
import {
  ExcelProcessor,
  type ExcelConfig,
} from '@/app/tp_ui/utils/excel-processor';

export function useExport(
  data: TankPlanDetailData[],
  excelConfig: ExcelConfig<TankPlanDetailData>,
) {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const handleExport = async () => {
    if (isExporting || !data.length) return;

    try {
      setIsExporting(true);
      const excelProcessor = new ExcelProcessor(excelConfig);
      const blob = await excelProcessor.exportToExcel(data);
      const fileName = `Long_term_Plan_${new Date().toISOString().split('T')[0]}.xlsx`;

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: 'Export Successful',
        description: `${data.length} rows exported to ${fileName}`,
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Export Failed',
        description: error instanceof Error ? error.message : 'Export failed',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return {
    handleExport,
    isExporting,
  } as const;
}
