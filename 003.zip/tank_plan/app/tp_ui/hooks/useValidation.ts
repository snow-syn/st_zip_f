import { useState } from 'react';
import type { TankPlanDetailData } from '../types';
import { COLUMNS, validateField } from '../config/config';

export type ValidationStep = {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'success' | 'error';
  message?: string;
};

export function useValidation() {
  const [validationSteps, setValidationSteps] = useState<ValidationStep[]>([
    { id: 'format', name: 'Format Validation', status: 'pending' },
    { id: 'required', name: 'Required Fields', status: 'pending' },
    { id: 'business', name: 'Business Rules', status: 'pending' },
    { id: 'save', name: 'Save Data', status: 'pending' },
  ]);

  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isValidating, setIsValidating] = useState(false);

  const updateStepStatus = (
    stepId: string,
    status: ValidationStep['status'],
    message?: string,
  ) => {
    setValidationSteps((steps) =>
      steps.map((step) =>
        step.id === stepId ? { ...step, status, message } : step,
      ),
    );
  };

  const validateData = async (
    data: TankPlanDetailData[],
  ): Promise<string[]> => {
    const errors: string[] = [];

    updateStepStatus('format', 'processing');
    await new Promise((resolve) => setTimeout(resolve, 800));

    data.forEach((row, index) => {
      Object.entries(COLUMNS).forEach(([key, column]) => {
        if (!column.validation) return;

        const value = row[key as keyof TankPlanDetailData];
        const error = validateField(value, column);
        if (error) {
          errors.push(`Row ${index + 1}: ${error}`);
        }
      });
    });

    updateStepStatus('format', errors.length ? 'error' : 'success');
    if (errors.length) return errors;

    updateStepStatus('required', 'processing');
    await new Promise((resolve) => setTimeout(resolve, 800));

    data.forEach((row, index) => {
      Object.entries(COLUMNS)
        .filter(([_, col]) =>
          col.validation?.some((rule) => rule.type === 'required'),
        )
        .forEach(([key, column]) => {
          const value = row[key as keyof TankPlanDetailData];
          if (!value || !value.trim()) {
            errors.push(`Row ${index + 1}: ${column.label} is required`);
          }
        });
    });

    updateStepStatus('required', errors.length ? 'error' : 'success');
    if (errors.length) return errors;

    updateStepStatus('business', 'processing');
    await new Promise((resolve) => setTimeout(resolve, 800));

    data.forEach((row, index) => {
      if (row.drain && row.start) {
        const drainDate = new Date(row.drain);
        const startDate = new Date(row.start);
        if (drainDate > startDate) {
          errors.push(`Row ${index + 1}: Drain date must be before Start date`);
        }
      }
    });

    updateStepStatus('business', errors.length ? 'error' : 'success');
    return errors;
  };

  return {
    validationSteps,
    setValidationSteps,
    validationErrors,
    isValidating,
    setValidationErrors,
    setIsValidating,
    validateData,
    updateStepStatus,
  } as const;
}
