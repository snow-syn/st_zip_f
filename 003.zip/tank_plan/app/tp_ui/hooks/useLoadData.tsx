import { useState } from 'react';
import type { TankPlanDetailData, DatabricksResponse } from '@/app/tp_ui/types';
import DatabaseService from '@/app/tp_ui/services/DatabaseService';
import { useToast } from '@/hooks/use-toast';

interface LoadResult {
  success: boolean;
  data?: TankPlanDetailData[];
  error?: string;
  debug?: {
    stage: string;
    details: unknown;
    queryTime?: number;
    transformTime?: number;
    rowCount?: number;
    timestamp?: string;
  };
}

export function useLoadData() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [debugInfo, setDebugInfo] = useState<Record<string, unknown>>({});
  const { toast } = useToast();

  const logDebug = (stage: string, details: unknown) => {
    console.group(`🔍 Load Debug - ${stage}`);
    console.log('Details:', details);
    console.groupEnd();

    setDebugInfo((prev) => ({
      ...prev,
      [stage]: details,
    }));
  };

  const handleError = (error: unknown, stage: string) => {
    const message = error instanceof Error ? error.message : 'Unknown error';
    logDebug(`Error-${stage}`, { error, message });
    setError(message);
    toast({
      variant: 'destructive',
      title: 'Error',
      description: message,
    });
    return {
      success: false,
      error: message,
      debug: {
        stage,
        details: error,
      },
    } as const;
  };

  const validateResponse = (
    result: DatabricksResponse<TankPlanDetailData[]>,
  ): boolean => {
    const normalizedResult: LoadResult = {
      ...result,
      debug: result.debug
        ? {
            stage: result.debug.stage || 'Unknown',
            details: result.debug.details || {},
            queryTime: result.debug.queryTime,
            transformTime: result.debug.transformTime,
            rowCount: result.debug.rowCount,
            timestamp: result.debug.timestamp,
          }
        : {
            stage: 'Unknown',
            details: {},
          },
    };

    logDebug('ValidateResponse', {
      success: normalizedResult.success,
      hasData: !!normalizedResult.data?.length,
      dataLength: normalizedResult.data?.length,
      error: normalizedResult.error,
    });

    if (!normalizedResult.success || !normalizedResult.data?.length) {
      const message = normalizedResult.error || 'No data available';
      setError(message);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: message,
      });
      return false;
    }
    return true;
  };

  const loadLatestPlan = async (): Promise<LoadResult> => {
    if (isLoading) {
      logDebug('LoadBlocked', { reason: 'Loading already in progress' });
      return {
        success: false,
        error: 'Loading in progress',
        debug: {
          stage: 'LoadBlocked',
          details: { isLoading },
        },
      };
    }

    try {
      setIsLoading(true);
      setError(null);
      logDebug('LoadStart', { timestamp: new Date().toISOString() });

      const result = await DatabaseService.getLatestPlanData();
      logDebug('DatabaseResponse', {
        success: result.success,
        dataLength: result.data?.length,
        error: result.error,
        timestamp: new Date().toISOString(),
      });

      if (!validateResponse(result)) {
        return {
          success: false,
          error: result.error || 'No data available',
          debug: {
            stage: 'ValidationFailed',
            details: result,
          },
        };
      }

      return {
        success: true,
        data: result.data,
        debug: {
          stage: 'LoadSuccess',
          details: {
            rowCount: result.data?.length,
            timestamp: new Date().toISOString(),
          },
        },
      };
    } catch (error) {
      return handleError(error, 'LoadFailed');
    } finally {
      setIsLoading(false);
      logDebug('LoadComplete', {
        timestamp: new Date().toISOString(),
        finalState: { error, debugInfo },
      });
    }
  };

  return {
    loadLatestPlan,
    isLoading,
    error,
    clearError: () => setError(null),
    debugInfo,
  } as const;
}
