import * as React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import {
  FileDown,
  Calendar,
  User,
  GitBranch,
  GitMerge,
  History,
  Table,
  AlertCircle,
  Clock,
  BarChart2,
  Activity,
  Layers,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { PlanVersion, VersionChangeLog } from '../../../tp_ui/types';
import { TypeBadge, TagBadge } from './badges';
import { logger } from '../../../tp_ui/utils/logger';

interface VersionDialogProps {
  version: PlanVersion | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onExport?: (version: PlanVersion) => Promise<void>;
}

// 指标卡片组件
interface MetricCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
  trend?: {
    value: number;
    label: string;
  };
}

const MetricCard = ({
  title,
  value,
  icon,
  description,
  trend,
}: MetricCardProps) => (
  <div className="rounded-lg border bg-card p-4">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
          {icon}
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-semibold">{value}</p>
        </div>
      </div>
      {trend && (
        <div
          className={cn(
            'flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium',
            trend.value > 0
              ? 'bg-green-500/20 text-green-700'
              : 'bg-red-500/20 text-red-700',
          )}
        >
          {trend.value > 0 ? '+' : ''}
          {trend.value}%
          <span className="text-muted-foreground">{trend.label}</span>
        </div>
      )}
    </div>
    {description && (
      <p className="mt-2 text-xs text-muted-foreground">{description}</p>
    )}
  </div>
);

// 时间轴组件
interface TimelineItemProps {
  icon: React.ReactNode;
  title: React.ReactNode;
  description: string;
  timestamp: string;
  isLast?: boolean;
}

const TimelineItem = ({
  icon,
  title,
  description,
  timestamp,
  isLast,
}: TimelineItemProps) => (
  <div className="flex gap-3">
    <div className="flex flex-col items-center">
      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10">
        {icon}
      </div>
      {!isLast && <div className="h-full w-px bg-border" />}
    </div>
    <div className="flex-1 pb-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-sm font-medium">{title}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
        <time className="text-xs text-muted-foreground">{timestamp}</time>
      </div>
    </div>
  </div>
);

// 版本统计组件
interface StatsCardProps {
  title: string;
  stats: Array<{
    label: string;
    value: number;
    color: string;
  }>;
}

const StatsCard = ({ title, stats }: StatsCardProps) => (
  <div className="rounded-lg border bg-card p-4">
    <h4 className="mb-4 text-sm font-medium">{title}</h4>
    <div className="space-y-3">
      {stats.map((stat, index) => (
        <div key={index} className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{stat.label}</span>
            <span className="font-medium">{stat.value}</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={cn('h-full rounded-full', stat.color)}
              style={{ width: `${stat.value}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  </div>
);

export function VersionDialog({
  version,
  open,
  onOpenChange,
  onExport,
}: VersionDialogProps) {
  const [isExporting, setIsExporting] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState<
    'info' | 'changes' | 'relations'
  >('info');

  const handleExport = async () => {
    if (!version || !onExport) return;

    try {
      setIsExporting(true);
      logger.debug('Exporting version', {
        module: 'VersionDialog',
        versionId: version.plan_master_id,
      });
      await onExport(version);
    } catch (error) {
      logger.error('Export failed', {
        module: 'VersionDialog',
        error,
      });
    } finally {
      setIsExporting(false);
    }
  };

  // 计算版本年龄
  const getVersionAge = React.useMemo(() => {
    if (!version) return '0 days';
    const days = Math.floor(
      (Date.now() - new Date(version.create_timestamp).getTime()) /
        (1000 * 60 * 60 * 24),
    );
    return `${days} days`;
  }, [version]);

  if (!version) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-lg font-semibold">Version Details</span>
              <TypeBadge type={version.plan_type} />
              {version.plan_official && (
                <TagBadge tag={version.plan_official} />
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                disabled={isExporting}
              >
                <FileDown className="mr-2 h-4 w-4" />
                {isExporting ? 'Exporting...' : 'Export'}
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-6">
            {/* 指标卡片 */}
            <div className="grid grid-cols-4 gap-4">
              <MetricCard
                title="Total Rows"
                value={version.row_count || 0}
                icon={<Table className="h-4 w-4 text-primary" />}
                trend={{
                  value: 5.2,
                  label: 'vs last',
                }}
              />
              <MetricCard
                title="Version Age"
                value={getVersionAge}
                icon={<Clock className="h-4 w-4 text-primary" />}
              />
              <MetricCard
                title="Changes"
                value="12"
                icon={<Activity className="h-4 w-4 text-primary" />}
                description="Since last version"
              />
              <MetricCard
                title="Versions"
                value="5"
                icon={<Layers className="h-4 w-4 text-primary" />}
                description="In this branch"
              />
            </div>

            <div className="grid grid-cols-3 gap-6">
              <div className="col-span-2 space-y-6">
                {/* 基本信息 */}
                <div className="space-y-2">
                  <h3 className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                    <User className="h-4 w-4" />
                    Basic Information
                  </h3>
                  <div className="grid grid-cols-2 gap-4 rounded-lg border bg-card p-4">
                    <InfoItem label="Version" value={version.plan_version} />
                    <InfoItem
                      label="Version No."
                      value={version.plan_version_no}
                    />
                    <InfoItem label="Created By" value={version.user_name} />
                    <InfoItem
                      label="Created At"
                      value={new Date(
                        version.create_timestamp,
                      ).toLocaleString()}
                    />
                    <InfoItem
                      label="Updated At"
                      value={new Date(
                        version.update_timestamp,
                      ).toLocaleString()}
                    />
                    <InfoItem
                      label="Row Count"
                      value={version.row_count || 0}
                    />
                  </div>
                </div>

                {/* 版本关系 */}
                <div className="space-y-2">
                  <h3 className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                    <GitBranch className="h-4 w-4" />
                    Version Relations
                  </h3>
                  <div className="grid grid-cols-2 gap-4 rounded-lg border bg-card p-4">
                    <InfoItem
                      label="Parent Version"
                      value={version.plan_version_parent || 'None'}
                    />
                    <InfoItem
                      label="Version Match"
                      value={version.version_match}
                    />
                  </div>
                </div>

                {/* 变更历史 */}
                <div className="space-y-2">
                  <h3 className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                    <History className="h-4 w-4" />
                    Change History
                  </h3>
                  <div className="rounded-lg border bg-card p-4">
                    <TimelineItem
                      icon={<AlertCircle className="h-3 w-3 text-primary" />}
                      title={
                        <>
                          Status changed to{' '}
                          <span className="text-primary">REVIEW</span>
                        </>
                      }
                      description="Changed by John Doe"
                      timestamp="2 hours ago"
                    />
                    <TimelineItem
                      icon={<GitMerge className="h-3 w-3 text-primary" />}
                      title="Merged from Weekly Plan"
                      description="Merged by System"
                      timestamp="1 day ago"
                    />
                    <TimelineItem
                      icon={<History className="h-3 w-3 text-primary" />}
                      title="Version Created"
                      description="Created by John Doe"
                      timestamp="2 days ago"
                      isLast
                    />
                  </div>
                </div>
              </div>

              {/* 右侧统计信息 */}
              <div className="space-y-6">
                <StatsCard
                  title="Change Distribution"
                  stats={[
                    {
                      label: 'Added',
                      value: 35,
                      color: 'bg-green-500',
                    },
                    {
                      label: 'Modified',
                      value: 45,
                      color: 'bg-blue-500',
                    },
                    {
                      label: 'Deleted',
                      value: 20,
                      color: 'bg-red-500',
                    },
                  ]}
                />

                <StatsCard
                  title="Status Distribution"
                  stats={[
                    {
                      label: 'Active',
                      value: 75,
                      color: 'bg-emerald-500',
                    },
                    {
                      label: 'Pending',
                      value: 15,
                      color: 'bg-yellow-500',
                    },
                    {
                      label: 'Completed',
                      value: 10,
                      color: 'bg-purple-500',
                    },
                  ]}
                />
              </div>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

function InfoItem({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="space-y-1">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-medium">{value}</p>
    </div>
  );
}
