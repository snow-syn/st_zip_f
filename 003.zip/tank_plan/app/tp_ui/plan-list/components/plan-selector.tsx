import * as React from 'react';
import { Check, ChevronsUpDown, FileX } from 'lucide-react';
import { cn } from '../../../../lib/utils';
import { Button } from '../../../../components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from '../../../../components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../../../../components/ui/popover';
import { Badge } from '../../../../components/ui/badge';
import type { PlanVersion, PlanTag } from '../../../tp_ui/types';
import { logger } from '../../../tp_ui/utils/logger';

interface PlanSelectorProps {
  plans: PlanVersion[];
  selectedPlan?: PlanVersion | null;
  onSelect: (plan: PlanVersion) => void;
  isLoading?: boolean;
}

export function PlanSelector({
  plans = [],
  selectedPlan,
  onSelect,
  isLoading,
}: PlanSelectorProps) {
  const [open, setOpen] = React.useState(false);

  const handlePlanSelect = React.useCallback(
    (plan: PlanVersion) => {
      logger.debug('Plan selected', {
        module: 'PlanSelector',
        planId: plan.plan_master_id,
        planVersion: plan.plan_version,
      });
      onSelect(plan);
      setOpen(false);
    },
    [onSelect],
  );

  const isLatestVersion = React.useCallback(
    (plan: PlanVersion) => {
      if (!plans.length) return false;
      const sameTypePlans = plans.filter((p) => p.plan_type === plan.plan_type);
      return (
        sameTypePlans.length > 0 &&
        sameTypePlans[0].plan_master_id === plan.plan_master_id
      );
    },
    [plans],
  );

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={isLoading}
          className={cn(
            'w-[300px] justify-between',
            !selectedPlan && 'text-muted-foreground',
          )}
        >
          {selectedPlan ? (
            <div className="flex items-center gap-2">
              <div
                className={cn(
                  'h-2 w-2 rounded-full',
                  getTagStyle(selectedPlan.plan_official),
                )}
              />
              <span className="truncate">{selectedPlan.plan_version}</span>
              <Badge variant="outline">{selectedPlan.plan_type}</Badge>
            </div>
          ) : (
            <span>Select a plan...</span>
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0">
        <Command>
          <CommandInput placeholder="Search plans..." />
          <CommandEmpty>
            <div className="flex flex-col items-center gap-2 p-4">
              <FileX className="h-8 w-8 text-muted-foreground/50" />
              <p className="text-sm text-muted-foreground">
                {isLoading ? 'Loading plans...' : 'No matching plans found'}
              </p>
            </div>
          </CommandEmpty>
          <CommandGroup>
            {plans.map((plan) => (
              <CommandItem
                key={plan.plan_master_id}
                value={plan.plan_version}
                onSelect={() => handlePlanSelect(plan)}
              >
                <div className="flex w-full items-center justify-between">
                  <div className="flex items-center gap-2">
                    {plan.plan_official && (
                      <div
                        className={cn(
                          'h-2 w-2 rounded-full',
                          getTagStyle(plan.plan_official),
                        )}
                      />
                    )}
                    <span>{plan.plan_version}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{plan.plan_type}</Badge>
                    {isLatestVersion(plan) && (
                      <Badge variant="secondary">Latest</Badge>
                    )}
                  </div>
                </div>
                {selectedPlan?.plan_master_id === plan.plan_master_id && (
                  <Check className="ml-auto h-4 w-4 shrink-0 opacity-50" />
                )}
              </CommandItem>
            ))}
          </CommandGroup>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

const getTagStyle = (tag: PlanTag) => {
  switch (tag) {
    case 'GB':
      return 'bg-purple-500';
    case '18MP':
      return 'bg-amber-500';
    default:
      return '';
  }
};
