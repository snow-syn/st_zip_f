import * as React from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { GitBranch, GitMerge, History } from 'lucide-react';
import type { PlanVersion, PlanType, PlanTag } from '../../../tp_ui/types';
import { logger } from '../../../tp_ui/utils/logger';

interface VersionManagementProps {
  version: PlanVersion | null;
  onCreateVersion: (type: PlanType, parentId: number | null) => Promise<void>;
  onUpdateTag: (tag: PlanTag) => Promise<void>;
  isLoading: boolean;
}

export function VersionManagement({
  version,
  onCreateVersion,
  onUpdateTag,
  isLoading,
}: VersionManagementProps) {
  const [showCreateDialog, setShowCreateDialog] = React.useState(false);
  const [showTagDialog, setShowTagDialog] = React.useState(false);
  const [selectedType, setSelectedType] = React.useState<PlanType>('Long-term');
  const [selectedTag, setSelectedTag] = React.useState<PlanTag>('');

  const handleCreateVersion = async () => {
    try {
      logger.debug('Creating new version', {
        module: 'VersionManagement',
        type: selectedType,
        parentId: version?.plan_master_id,
      });

      await onCreateVersion(selectedType, version?.plan_master_id || null);
      setShowCreateDialog(false);
    } catch (error) {
      logger.error('Failed to create version', {
        module: 'VersionManagement',
        error,
      });
    }
  };

  const handleUpdateTag = async () => {
    try {
      logger.debug('Updating version tag', {
        module: 'VersionManagement',
        versionId: version?.plan_master_id,
        tag: selectedTag,
      });

      await onUpdateTag(selectedTag);
      setShowTagDialog(false);
    } catch (error) {
      logger.error('Failed to update tag', {
        module: 'VersionManagement',
        error,
      });
    }
  };

  return (
    <>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowCreateDialog(true)}
          disabled={isLoading}
        >
          <GitBranch className="mr-2 h-4 w-4" />
          Create Version
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowTagDialog(true)}
          disabled={isLoading || !version}
        >
          <History className="mr-2 h-4 w-4" />
          Update Tag
        </Button>
      </div>

      {/* Create Version Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Version</DialogTitle>
            <DialogDescription>
              Create a new version based on the selected plan type.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="type">Plan Type</Label>
              <Select
                value={selectedType}
                onValueChange={(value) => setSelectedType(value as PlanType)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select plan type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Long-term">Long-term</SelectItem>
                  <SelectItem value="Weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleCreateVersion} disabled={isLoading}>
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Update Tag Dialog */}
      <Dialog open={showTagDialog} onOpenChange={setShowTagDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Version Tag</DialogTitle>
            <DialogDescription>
              Change the tag of the selected version.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="tag">Tag</Label>
              <Select
                value={selectedTag}
                onValueChange={(value) => setSelectedTag(value as PlanTag)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select tag" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="GB">GB</SelectItem>
                  <SelectItem value="18MP">18MP</SelectItem>
                  <SelectItem value="">No Tag</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTagDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateTag} disabled={isLoading}>
              Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
