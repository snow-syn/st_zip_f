import * as React from 'react';
import { Check } from 'lucide-react';
import { cn } from '../../../../lib/utils';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../../../../components/ui/popover';
import { Button } from '../../../../components/ui/button';
import { ScrollArea } from '../../../../components/ui/scroll-area';
import { Badge } from '../../../../components/ui/badge';
import { Calendar } from '../../../../components/ui/calendar';
import type { PlanType } from '../../../tp_ui/types';
import { logger } from '../../../tp_ui/utils/logger';
import type { DateRange } from 'react-day-picker';

type FilterType = 'type' | 'status' | 'date' | 'tag';

interface FilterPopoverProps {
  type: FilterType;
  title: string;
  icon: React.ReactNode;
  selectedValues?: string[];
  onSelect: (values: string[]) => void;
  options?: { value: string; label: string }[];
  dateRange?: { start: Date; end: Date };
  onDateRangeChange?: (start: Date, end: Date) => void;
}

export function FilterPopover({
  type,
  title,
  icon,
  selectedValues = [],
  onSelect,
  options = [],
  dateRange,
  onDateRangeChange,
}: FilterPopoverProps) {
  const [open, setOpen] = React.useState(false);

  const handleSelect = React.useCallback(
    (value: string) => {
      logger.debug('Filter value selected', {
        module: 'FilterPopover',
        type,
        value,
      });

      const newValues = selectedValues.includes(value)
        ? selectedValues.filter((v) => v !== value)
        : [...selectedValues, value];
      onSelect(newValues);
    },
    [selectedValues, onSelect, type],
  );

  const handleDateSelect = React.useCallback(
    (range: DateRange | undefined) => {
      if (!range?.from || !range?.to || !onDateRangeChange) return;

      logger.debug('Date range selected', {
        module: 'FilterPopover',
        from: range.from,
        to: range.to,
      });

      onDateRangeChange(range.from, range.to);
      setOpen(false);
    },
    [onDateRangeChange],
  );

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn(
            'relative',
            selectedValues.length > 0 && 'border-primary/50',
          )}
        >
          {icon}
          {title}
          {selectedValues.length > 0 && (
            <Badge
              variant="secondary"
              className="ml-2 rounded-sm px-1 font-normal"
            >
              {selectedValues.length}
            </Badge>
          )}
          {dateRange && (
            <Badge
              variant="secondary"
              className="ml-2 rounded-sm px-1 font-normal"
            >
              {new Date(dateRange.start).toLocaleDateString()} -{' '}
              {new Date(dateRange.end).toLocaleDateString()}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[280px] p-0" align="start">
        <ScrollArea className="h-[300px]">
          {type === 'date' ? (
            <div className="p-2">
              <Calendar
                mode="range"
                selected={
                  dateRange
                    ? {
                        from: dateRange.start,
                        to: dateRange.end,
                      }
                    : undefined
                }
                onSelect={handleDateSelect}
                numberOfMonths={2}
                disabled={(date) =>
                  date > new Date() || date < new Date('2020-01-01')
                }
              />
            </div>
          ) : (
            <div className="space-y-1 p-2">
              {options.map((option) => (
                <Button
                  key={option.value}
                  variant="ghost"
                  className={cn(
                    'w-full justify-start',
                    selectedValues.includes(option.value) &&
                      'bg-primary/10 font-medium',
                  )}
                  onClick={() => handleSelect(option.value)}
                >
                  <Check
                    className={cn(
                      'mr-2 h-4 w-4',
                      selectedValues.includes(option.value)
                        ? 'opacity-100'
                        : 'opacity-0',
                    )}
                  />
                  {option.label}
                </Button>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
