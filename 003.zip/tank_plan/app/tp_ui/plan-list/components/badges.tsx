import * as React from 'react';
import { cn } from '@/lib/utils';
import type { PlanTag, PlanType } from '../../types';

export const TagBadge: React.FC<{ tag: PlanTag }> = ({ tag }) => {
  if (!tag) return null;

  const getTagStyle = (tag: PlanTag) => {
    switch (tag) {
      case 'GB':
        return 'border-purple-300 bg-purple-50/50 text-purple-700 hover:bg-purple-100 dark:border-purple-800 dark:bg-purple-950/20 dark:text-purple-400';
      case '18MP':
        return 'border-amber-300 bg-amber-50/50 text-amber-700 hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-400';
      default:
        return '';
    }
  };

  return (
    <div
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
        getTagStyle(tag),
      )}
    >
      {tag}
    </div>
  );
};

export const TypeBadge: React.FC<{ type: PlanType }> = ({ type }) => (
  <div
    className={cn(
      'inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-medium',
      type === 'Long-term'
        ? 'border-indigo-200 bg-indigo-50 text-indigo-800 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-400'
        : 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-400',
    )}
  >
    {type}
  </div>
);
