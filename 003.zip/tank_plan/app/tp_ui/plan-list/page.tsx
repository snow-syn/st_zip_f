'use client';

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
  CalendarRange,
  ListFilter,
  History,
  FileDown,
  ChevronDown,
  Search,
  FileX,
  Tag,
} from 'lucide-react';
import type {
  PlanVersion,
  PlanFilter,
  PlanType,
  PlanTag,
} from '../../tp_ui/types';
import { usePlanVersions } from './hooks/usePlanVersions';
import { FilterPopover } from './components/filter-popover';
import { VersionDialog } from './components/version-dialog';
import { useVersionExport } from './hooks/useVersionExport';
import { TypeBadge } from './components/badges';
import { useFilter } from './hooks/useFilter';
import { logger } from '../../tp_ui/utils/logger';
import { VersionManagement } from './components/version-management';
import DatabaseService from '../../tp_ui/services/DatabaseService';
import { toast } from '@/hooks/use-toast';

// 搜索栏组件
const SearchBar = ({
  onSearch,
  isLoading,
}: {
  onSearch: (value: string) => void;
  isLoading?: boolean;
}) => (
  <div className="relative">
    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
    <input
      type="text"
      placeholder="Search plans..."
      className={cn(
        'h-10 w-full rounded-md border bg-background pl-9 pr-4 text-sm',
        'placeholder:text-muted-foreground',
        'focus:outline-none focus:ring-2 focus:ring-primary/20',
        'disabled:cursor-not-allowed disabled:opacity-50',
      )}
      onChange={(e) => onSearch(e.target.value)}
      disabled={isLoading}
    />
  </div>
);

// 过滤器组件
const FilterBar = ({
  filter,
  onFilterChange,
  isLoading,
}: {
  filter: PlanFilter;
  onFilterChange: (filter: PlanFilter) => void;
  isLoading?: boolean;
}) => (
  <div className="flex items-center gap-2">
    <Button
      variant="outline"
      size="sm"
      className={cn(
        'relative',
        filter.type && filter.type.length > 0 && 'border-primary/50',
      )}
      disabled={isLoading}
    >
      <ListFilter className="mr-2 h-4 w-4" />
      Type
      <ChevronDown className="ml-2 h-4 w-4 opacity-50" />
      {filter.type && filter.type.length > 0 && (
        <div className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-primary" />
      )}
    </Button>

    <Button
      variant="outline"
      size="sm"
      className={cn(
        'relative',
        filter.status && filter.status.length > 0 && 'border-primary/50',
      )}
      disabled={isLoading}
    >
      <History className="mr-2 h-4 w-4" />
      Status
      <ChevronDown className="ml-2 h-4 w-4 opacity-50" />
      {filter.status && filter.status.length > 0 && (
        <div className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-primary" />
      )}
    </Button>

    <Button
      variant="outline"
      size="sm"
      className={cn('relative', filter.dateRange && 'border-primary/50')}
      disabled={isLoading}
    >
      <CalendarRange className="mr-2 h-4 w-4" />
      Date Range
      <ChevronDown className="ml-2 h-4 w-4 opacity-50" />
      {filter.dateRange && (
        <div className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-primary" />
      )}
    </Button>
  </div>
);

// 版本列表组件
const VersionList = ({
  versions,
  isLoading,
  onViewDetails,
  onExport,
}: {
  versions: PlanVersion[];
  isLoading?: boolean;
  onViewDetails: (version: PlanVersion) => void;
  onExport: (version: PlanVersion) => Promise<void>;
}) => {
  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-12rem)] items-center justify-center">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          <span className="text-sm text-muted-foreground">
            Loading versions...
          </span>
        </div>
      </div>
    );
  }

  if (!versions.length) {
    return (
      <div className="flex h-[calc(100vh-12rem)] items-center justify-center">
        <div className="text-center">
          <FileX className="mx-auto h-8 w-8 text-muted-foreground/50" />
          <p className="mt-2 text-sm text-muted-foreground">
            No versions found
          </p>
        </div>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[calc(100vh-12rem)] pr-4">
      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {versions.map((version) => (
            <motion.div
              key={version.plan_master_id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={cn(
                'group rounded-lg border bg-card p-4 shadow-sm',
                'transition-all duration-200 hover:shadow-md',
                'dark:shadow-none',
              )}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">
                        {version.plan_version}
                      </span>
                      <TypeBadge type={version.plan_type} />
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>Created by {version.user_name}</span>
                      <span>•</span>
                      <span>
                        {new Date(
                          version.create_timestamp,
                        ).toLocaleDateString()}
                      </span>
                      {version.row_count && (
                        <>
                          <span>•</span>
                          <span>{version.row_count} rows</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 opacity-0 transition-opacity group-hover:opacity-100">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onExport(version)}
                  >
                    <FileDown className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onViewDetails(version)}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ScrollArea>
  );
};

export default function PlanList() {
  const {
    filter,
    handleSearch,
    handleTypeFilter,
    handleTagFilter,
    handleDateRangeFilter,
    clearFilter,
  } = useFilter();
  const {
    versions,
    isLoading,
    error,
    getFilteredVersions,
    refresh: loadAllVersions,
  } = usePlanVersions();
  const [selectedVersion, setSelectedVersion] = useState<PlanVersion | null>(
    null,
  );
  const { exportVersion, isExporting } = useVersionExport();
  const [isManaging, setIsManaging] = useState(false);

  // 获取筛选后的版本列表
  const filteredVersions = useMemo(
    () => getFilteredVersions(filter),
    [filter, getFilteredVersions],
  );

  // 处理搜索
  const handleSearchChange = (value: string) => {
    logger.debug('Search input changed', {
      module: 'PlanList',
      value,
    });
    handleSearch(value);
  };

  // 处理查看详情
  const handleViewDetails = (version: PlanVersion) => {
    logger.debug('Opening version details', {
      module: 'PlanList',
      versionId: version.plan_master_id,
    });
    setSelectedVersion(version);
  };

  // 处理导出
  const handleExport = async (version: PlanVersion) => {
    try {
      logger.debug('Exporting version', {
        module: 'PlanList',
        versionId: version.plan_master_id,
      });
      await exportVersion(version);
    } catch (error) {
      logger.error('Export failed', {
        module: 'PlanList',
        error,
      });
    }
  };

  const handleCreateVersion = async (
    type: PlanType,
    parentId: number | null,
  ) => {
    try {
      setIsManaging(true);
      logger.debug('Creating new version', {
        module: 'PlanList',
        type,
        parentId,
      });

      const response = await DatabaseService.createVersion(type, parentId);
      if (!response.success) {
        throw new Error(response.error);
      }

      toast({
        title: 'Success',
        description: 'New version created successfully',
      });

      // 刷新版本列表
      await loadAllVersions();
    } catch (error) {
      logger.error('Failed to create version', {
        module: 'PlanList',
        error,
      });
      toast({
        variant: 'destructive',
        title: 'Error',
        description:
          error instanceof Error ? error.message : 'Failed to create version',
      });
    } finally {
      setIsManaging(false);
    }
  };

  const handleUpdateStatus = async (status: PlanTag) => {
    if (!selectedVersion) return;

    try {
      setIsManaging(true);
      logger.debug('Updating version status', {
        module: 'PlanList',
        versionId: selectedVersion.plan_master_id,
        status,
      });

      const response = await DatabaseService.updateVersionTag(
        selectedVersion.plan_master_id,
        status,
      );

      if (!response.success) {
        throw new Error(response.error);
      }

      toast({
        title: 'Success',
        description: 'Version status updated successfully',
      });

      // 刷新版本列表
      await loadAllVersions();
    } catch (error) {
      logger.error('Failed to update status', {
        module: 'PlanList',
        error,
      });
      toast({
        variant: 'destructive',
        title: 'Error',
        description:
          error instanceof Error ? error.message : 'Failed to update status',
      });
    } finally {
      setIsManaging(false);
    }
  };

  // 修改筛选器选项
  const filterOptions = {
    type: [
      { value: 'Long-term', label: 'Long-term' },
      { value: 'Weekly', label: 'Weekly' },
    ],
    tag: [
      { value: 'GB', label: 'GB' },
      { value: '18MP', label: '18MP' },
    ],
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
        ease: [0.4, 0, 0.2, 1],
      }}
      className="flex h-full flex-col gap-6 p-6"
    >
      {/* 标题区域 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <History className="h-4 w-4 text-primary" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight">Plan List</h1>
        </div>
      </div>

      {/* 工具栏 */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex-1">
          <SearchBar onSearch={handleSearchChange} isLoading={isLoading} />
        </div>
        <VersionManagement
          version={selectedVersion}
          onCreateVersion={handleCreateVersion}
          onUpdateTag={handleUpdateStatus}
          isLoading={isLoading || isManaging}
        />
        <div className="flex items-center gap-2">
          <FilterPopover
            type="type"
            title="Type"
            icon={<ListFilter className="mr-2 h-4 w-4" />}
            selectedValues={filter.type || []}
            onSelect={handleTypeFilter}
            options={[
              { value: 'Long-term', label: 'Long-term' },
              { value: 'Weekly', label: 'Weekly' },
            ]}
          />
          <FilterPopover
            type="tag"
            title="Tag"
            icon={<Tag className="mr-2 h-4 w-4" />}
            selectedValues={filter.status || []}
            onSelect={handleTagFilter}
            options={filterOptions.tag}
          />
          <FilterPopover
            type="date"
            title="Date Range"
            icon={<CalendarRange className="mr-2 h-4 w-4" />}
            dateRange={
              filter.dateRange
                ? {
                    start: new Date(filter.dateRange.start),
                    end: new Date(filter.dateRange.end),
                  }
                : undefined
            }
            onDateRangeChange={(start, end) =>
              handleDateRangeFilter(start.toISOString(), end.toISOString())
            }
            selectedValues={[]}
            onSelect={() => {}}
          />
          {(filter.type?.length ||
            filter.status?.length ||
            filter.dateRange ||
            filter.search) && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilter}
              className="text-muted-foreground hover:text-foreground"
            >
              Clear Filters
            </Button>
          )}
        </div>
      </div>

      {/* 版本列表 */}
      <div className="min-h-0 flex-1">
        <VersionList
          versions={filteredVersions}
          isLoading={isLoading}
          onViewDetails={handleViewDetails}
          onExport={handleExport}
        />
      </div>

      {/* 版本详情对框 */}
      <VersionDialog
        version={selectedVersion}
        open={!!selectedVersion}
        onOpenChange={(open) => !open && setSelectedVersion(null)}
        onExport={exportVersion}
      />
    </motion.div>
  );
}
