import { useState, useCallback } from 'react';
import type { PlanFilter, PlanTag } from '../../../tp_ui/types';
import { logger } from '../../../tp_ui/utils/logger';

export function useFilter() {
  const [filter, setFilter] = useState<PlanFilter>({});

  const handleSearch = useCallback((value: string) => {
    logger.debug('Search value changed', {
      module: 'useFilter',
      value,
    });
    setFilter((prev) => ({ ...prev, search: value }));
  }, []);

  const handleTypeFilter = useCallback((types: string[]) => {
    logger.debug('Type filter changed', {
      module: 'useFilter',
      types,
    });
    setFilter((prev) => ({ ...prev, type: types as PlanFilter['type'] }));
  }, []);

  const handleTagFilter = useCallback((tags: string[]) => {
    logger.debug('Tag filter changed', {
      module: 'useFilter',
      tags,
    });
    setFilter((prev) => ({ ...prev, status: tags as PlanTag[] }));
  }, []);

  const handleDateRangeFilter = useCallback((start: string, end: string) => {
    logger.debug('Date range filter changed', {
      module: 'useFilter',
      start,
      end,
    });
    setFilter((prev) => ({ ...prev, dateRange: { start, end } }));
  }, []);

  const clearFilter = useCallback(() => {
    logger.debug('Clearing all filters', { module: 'useFilter' });
    setFilter({});
  }, []);

  return {
    filter,
    setFilter,
    handleSearch,
    handleTypeFilter,
    handleTagFilter,
    handleDateRangeFilter,
    clearFilter,
  } as const;
}
