import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import type { PlanVersion } from '../../../tp_ui/types';
import { logger } from '../../../tp_ui/utils/logger';
import DatabaseService from '../../../tp_ui/services/DatabaseService';
import { ExcelProcessor } from '../../../tp_ui/utils/excel-processor';
import { ltPlanExcelConfig } from '../../../tp_ui/config/excel-config';

export function useVersionExport() {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const exportVersion = async (version: PlanVersion) => {
    if (isExporting) return;

    const context = {
      module: 'useVersionExport',
      versionId: version.plan_master_id,
      version: version.plan_version,
    };

    try {
      setIsExporting(true);
      logger.debug('Starting version export', context);

      // 1. 获取版本数据
      const response = await DatabaseService.getVersionData(
        version.plan_master_id,
      );

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Failed to get version data');
      }

      logger.debug('Version data retrieved', {
        ...context,
        rowCount: response.data.length,
      });

      // 2. 导出Excel
      const excelProcessor = new ExcelProcessor(ltPlanExcelConfig);
      const blob = await excelProcessor.exportToExcel(response.data);

      // 3. 下载文件
      const fileName = `Tank_Plan_${version.plan_version}_${version.plan_type}.xlsx`;
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      logger.debug('Export completed', {
        ...context,
        fileName,
        fileSize: blob.size,
      });

      toast({
        title: 'Export Successful',
        description: `Version ${version.plan_version} exported successfully`,
      });
    } catch (error) {
      logger.error('Export failed', context, { error });
      toast({
        variant: 'destructive',
        title: 'Export Failed',
        description: error instanceof Error ? error.message : 'Export failed',
      });
      throw error;
    } finally {
      setIsExporting(false);
    }
  };

  return {
    exportVersion,
    isExporting,
  } as const;
}
