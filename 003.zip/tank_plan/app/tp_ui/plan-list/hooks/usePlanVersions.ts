import { useState, useCallback, useEffect, useMemo } from 'react';
import type { PlanVersion, PlanFilter } from '../../../tp_ui/types';
import { logger } from '../../../tp_ui/utils/logger';
import DatabaseService from '../../../tp_ui/services/DatabaseService';
import { useToast } from '@/hooks/use-toast';

export function usePlanVersions() {
  const [allVersions, setAllVersions] = useState<PlanVersion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // 加载所有版本数据
  const loadAllVersions = useCallback(async () => {
    const context = {
      module: 'usePlanVersions',
      function: 'loadAllVersions',
      requestId: `load-${Date.now()}`,
    };

    try {
      logger.group('Loading all plan versions', context);
      setIsLoading(true);
      setError(null);

      const response = await DatabaseService.getAllPlanVersions();

      logger.debug('Raw response from DatabaseService', context, {
        response,
      });

      if (!response || typeof response.success !== 'boolean') {
        throw new Error('Invalid response from database service');
      }

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Failed to load versions');
      }

      logger.debug('All versions loaded successfully', context, {
        count: response.data.length,
        sample: response.data[0],
        debug: response.debug,
      });

      setAllVersions(response.data);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      logger.error('Failed to load versions', context, {
        error,
        message,
        errorType:
          error instanceof Error ? error.constructor.name : typeof error,
      });
      setError(message);
      setAllVersions([]);

      toast({
        variant: 'destructive',
        title: 'Error Loading Versions',
        description: message,
      });
    } finally {
      setIsLoading(false);
      logger.groupEnd();
    }
  }, [toast]);

  // 本地筛选逻辑
  const filterVersions = useCallback(
    (versions: PlanVersion[], filter?: PlanFilter) => {
      if (!filter) return versions;

      logger.debug('Filtering versions locally', {
        module: 'usePlanVersions',
        filter,
        totalVersions: versions.length,
      });

      return versions.filter((version) => {
        // 类型筛选
        if (filter.type?.length && !filter.type.includes(version.plan_type)) {
          return false;
        }

        // 状态筛选
        if (
          filter.status?.length &&
          !filter.status.includes(version.plan_official)
        ) {
          return false;
        }

        // 日期范围筛选
        if (filter.dateRange) {
          const createDate = new Date(version.create_timestamp);
          const startDate = new Date(filter.dateRange.start);
          const endDate = new Date(filter.dateRange.end);
          if (createDate < startDate || createDate > endDate) {
            return false;
          }
        }

        // 搜索筛选
        if (filter.search) {
          const searchTerm = filter.search.toLowerCase();
          return (
            version.plan_version.toLowerCase().includes(searchTerm) ||
            version.user_name.toLowerCase().includes(searchTerm) ||
            version.plan_type.toLowerCase().includes(searchTerm)
          );
        }

        return true;
      });
    },
    [],
  );

  // 使用 useMemo 缓存筛选结果
  const getFilteredVersions = useCallback(
    (filter?: PlanFilter) => {
      const filtered = filterVersions(allVersions, filter);
      logger.debug('Filtered versions', {
        module: 'usePlanVersions',
        totalVersions: allVersions.length,
        filteredVersions: filtered.length,
        filter,
      });
      return filtered;
    },
    [allVersions, filterVersions],
  );

  // 组件挂载时加载所有数据
  useEffect(() => {
    loadAllVersions();
  }, [loadAllVersions]);

  return {
    versions: allVersions,
    isLoading,
    error,
    getFilteredVersions,
    refresh: loadAllVersions,
  } as const;
}
