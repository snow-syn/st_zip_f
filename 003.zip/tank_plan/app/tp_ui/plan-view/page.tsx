'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { ErrorDisplay } from '@/app/tp_ui/components/error-display';
import type { TankPlanDetailData, PlanVersion } from '../types';
import { useExport } from '../hooks/useExport';
import { ltPlanExcelConfig } from '../config/excel-config';
import { logger } from '../utils/logger';
import DatabaseService from '../services/DatabaseService';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import {
  FileDown,
  CalendarRange,
  User,
  Clock,
  Table,
  Tag,
  GitBranch,
  History,
  CalendarPlus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DataTable, createColumn } from '@/app/tp_ui/components/DataTable';
import { TANK_COLUMNS, DATE_COLUMNS, type ColumnKey } from '../config/config';
import { StringUtils, DateUtils, ValidationUtils } from '../utils';
import { TypeBadge, TagBadge } from '../plan-list/components/badges';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

// 创建表格列配置
const columns = TANK_COLUMNS.map((key: ColumnKey) => {
  const isDateColumn = DATE_COLUMNS.includes(key as any);
  return createColumn({
    key: key as keyof TankPlanDetailData,
    label: isDateColumn ? key : StringUtils.truncate(key),
    tooltip: key,
    isDate: isDateColumn,
    formatValue: (value: string) =>
      isDateColumn ? DateUtils.format(value) : value,
    validateValue: (value: string) =>
      isDateColumn ? ValidationUtils.validateDate(value, key) : null,
  });
});

interface CustomColumnDef<T = any> {
  key?: string;
  formatValue?: (value: string) => string;
  // ... 其他属性
}

// 创建一个包含 useSearchParams 的内容组件
function PlanViewContent() {
  const [data, setData] = useState<TankPlanDetailData[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const planId = searchParams.get('id');

  const { handleExport, isExporting } = useExport(data, ltPlanExcelConfig);

  // 添加版本信息状态
  const [versionInfo, setVersionInfo] = useState<PlanVersion | null>(null);

  // 加载计划数据
  const loadPlanData = async (id: string) => {
    const context = {
      module: 'PlanView',
      function: 'loadPlanData',
      planId: id,
    };

    try {
      logger.group('Loading plan data', context);
      setIsLoading(true);
      setErrors([]);

      const result = await DatabaseService.getVersionData(Number(id));

      logger.debug('Plan data loaded', context, {
        success: result.success,
        dataLength: result.data?.length,
        error: result.error,
      });

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load plan data');
      }

      setData(result.data);

      logger.debug('Data set successfully', context, {
        dataLength: result.data.length,
        sampleRow: result.data[0],
      });
    } catch (error) {
      logger.error('Failed to load plan', context, { error });
      setErrors([
        error instanceof Error ? error.message : 'Failed to load plan data',
      ]);
    } finally {
      setIsLoading(false);
      logger.groupEnd();
    }
  };

  // 加载版本信息
  const loadVersionInfo = async (id: string) => {
    const context = {
      module: 'PlanView',
      function: 'loadVersionInfo',
      planId: id,
    };

    try {
      logger.group('Loading version info', context);
      const result = await DatabaseService.getVersionInfo(Number(id));

      logger.debug('Version info loaded', context, {
        success: result.success,
        data: result.data,
      });

      if (!result.success || !result.data) {
        throw new Error(result.error || 'Failed to load version info');
      }

      setVersionInfo(result.data);
    } catch (error) {
      logger.error('Failed to load version info', context, { error });
      setErrors((prev) => [
        ...prev,
        error instanceof Error ? error.message : 'Failed to load version info',
      ]);
    } finally {
      logger.groupEnd();
    }
  };

  // 修改 handleParentClick 函数，使用 router.replace 而不是 push
  const handleParentClick = (parentId: number) => {
    const context = {
      module: 'PlanView',
      function: 'handleParentClick',
      parentId,
    };

    try {
      logger.debug('Navigating to parent plan', context);
      // 使用 replace 而不是 push，这样不会在历史记录中添加新条目
      router.replace(`/tp_ui/plan-view?id=${parentId}`);
      // 手动触发数据加载
      loadPlanData(String(parentId));
      loadVersionInfo(String(parentId));
    } catch (error) {
      logger.error('Failed to navigate to parent plan', context, { error });
    }
  };

  // 修改初始化加载逻辑
  useEffect(() => {
    const context = {
      module: 'PlanView',
      function: 'initializeComponent',
      planId,
    };

    if (planId) {
      logger.debug('Loading plan data and info', context);
      // 清除旧数据
      setData([]);
      setVersionInfo(null);
      // 加载新数据
      Promise.all([loadPlanData(planId), loadVersionInfo(planId)]);
    } else {
      logger.error('No plan ID provided', context);
      setErrors(['No plan ID provided']);
    }
  }, [planId, searchParams]); // 添加 searchParams 作为依赖

  // 修改 VersionInfoCard 组件
  const VersionInfoCard = ({ version }: { version: PlanVersion }) => {
    const router = useRouter();
    const [parentInfo, setParentInfo] = useState<PlanVersion | null>(null);

    // 加载父版本信息
    useEffect(() => {
      const loadParentInfo = async () => {
        if (!version.plan_version_parent) return;

        const context = {
          module: 'VersionInfoCard',
          function: 'loadParentInfo',
          parentId: version.plan_version_parent,
        };

        try {
          logger.debug('Loading parent version info', context);
          const result = await DatabaseService.getVersionInfo(
            Number(version.plan_version_parent),
          );

          if (result.success && result.data) {
            setParentInfo(result.data);
          }
        } catch (error) {
          logger.error('Failed to load parent info', context, { error });
        }
      };

      loadParentInfo();
    }, [version.plan_version_parent]);

    // 修改 ParentTooltipContent 组件
    const ParentTooltipContent = ({ parent }: { parent: PlanVersion }) => (
      <div className="space-y-3 p-3">
        {/* 标题部分 */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-base font-semibold">
              {parent.plan_version}
            </span>
            <TypeBadge type={parent.plan_type} />
            {parent.plan_official && <TagBadge tag={parent.plan_official} />}
          </div>
          <div className="text-xs text-muted-foreground">
            Version {parent.plan_version_no}
          </div>
        </div>

        {/* 详细信息 */}
        <div className="space-y-2 rounded-md bg-muted/50 p-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <User className="h-3.5 w-3.5" />
            <span>{parent.user_name}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-3.5 w-3.5" />
            <span>{format(new Date(parent.create_timestamp), 'PPp')}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Table className="h-3.5 w-3.5" />
            <span>{parent.row_count} rows</span>
          </div>
        </div>

        {/* 修改跳转按钮样式 */}
        <Button
          variant="default"
          size="sm"
          className="group mt-2 w-full justify-center"
          onClick={() => handleParentClick(parent.plan_master_id)}
        >
          <span className="flex items-center gap-2">
            View Parent Plan
            <GitBranch className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </span>
        </Button>
      </div>
    );

    // 添加创建 Weekly Plan 的处理函数
    const handleCreateWeeklyPlan = () => {
      const context = {
        module: 'VersionInfoCard',
        function: 'handleCreateWeeklyPlan',
        sourceVersionId: version.plan_master_id,
      };

      try {
        logger.debug('Navigating to weekly plan creation', context);
        router.push(`/tp_ui/weekly?id=${version.plan_master_id}`);
      } catch (error) {
        logger.error('Failed to navigate to weekly plan creation', context, {
          error,
        });
      }
    };

    return (
      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <div className="p-4">
          <div className="flex items-start justify-between">
            {/* 左侧信息 */}
            <div className="flex items-center gap-4">
              {/* 版本号和标签 */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-semibold tracking-tight">
                    {version.plan_version}
                  </h2>
                  <TypeBadge type={version.plan_type} />
                  {version.plan_official && (
                    <TagBadge tag={version.plan_official} />
                  )}
                  {version.plan_version_no > 1 && (
                    <Badge variant="outline" className="h-5 px-1.5">
                      v{version.plan_version_no}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <User className="h-3.5 w-3.5" />
                    <span>{version.user_name}</span>
                  </div>
                  <div>•</div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" />
                    <span>
                      {format(new Date(version.create_timestamp), 'PPp')}
                    </span>
                  </div>
                  <div>•</div>
                  <div className="flex items-center gap-1.5">
                    <Table className="h-3.5 w-3.5" />
                    <span>{version.row_count} rows</span>
                  </div>
                </div>
              </div>

              {/* 分隔线 - 只在有父版本时显示 */}
              {version.plan_version_parent && parentInfo && (
                <div className="h-10 w-px bg-border" />
              )}

              {/* Parent 信息 */}
              {version.plan_version_parent && parentInfo && (
                <div className="flex items-center">
                  <TooltipProvider delayDuration={200}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="link"
                          size="sm"
                          className="group flex items-center gap-2 px-0 text-sm font-medium text-primary hover:text-primary/80"
                        >
                          <GitBranch className="h-3.5 w-3.5 transition-transform duration-200 group-hover:-translate-y-0.5" />
                          <span>
                            Parent: {parentInfo.plan_version}-v
                            {parentInfo.plan_version_no}
                          </span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent
                        side="bottom"
                        align="start"
                        className="w-72 p-0 shadow-lg"
                      >
                        <ParentTooltipContent parent={parentInfo} />
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              )}
            </div>

            {/* 修改右侧操作按钮 */}
            <div className="flex items-center gap-2">
              {/* 添加创建 Weekly Plan 按钮 */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleCreateWeeklyPlan}
                className="group"
              >
                <CalendarPlus className="mr-2 h-4 w-4 transition-transform duration-200 group-hover:scale-110" />
                Create Weekly Plan
              </Button>

              {/* 导出按钮 */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                disabled={isLoading || data.length === 0 || isExporting}
              >
                <FileDown
                  className={cn('mr-2 h-4 w-4', isExporting && 'animate-pulse')}
                />
                {isExporting ? 'Exporting...' : 'Export Excel'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
      className="flex h-full flex-col"
    >
      {/* 标题栏 */}
      <div className="flex-none px-4 py-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <CalendarRange className="h-4 w-4 text-primary" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight">Plan View</h1>
        </div>
      </div>

      {/* 版本信息 */}
      <div className="flex-none px-4">
        <AnimatePresence mode="wait">
          {versionInfo && (
            <motion.div
              key={versionInfo.plan_master_id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <VersionInfoCard version={versionInfo} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 错误提示 */}
      <div className="flex-none px-4">
        <ErrorDisplay
          errors={errors}
          title="Error"
          description="Failed to load plan data"
          variant="error"
          onClose={() => setErrors([])}
        />
      </div>

      {/* 数据表格容器 */}
      <div className="min-h-0 flex-1 p-4">
        <AnimatePresence mode="wait">
          {data.length > 0 && (
            <motion.div
              key={planId}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-full w-full"
            >
              <div className="h-full w-full">
                <DataTable
                  data={data}
                  columns={columns}
                  editConfig={{
                    allowEdit: false,
                    formatValue: (value, columnId) => {
                      const column = columns.find(
                        (col) =>
                          (col as unknown as CustomColumnDef).key === columnId,
                      ) as CustomColumnDef;
                      return column?.formatValue?.(value) ?? value;
                    },
                  }}
                  className="h-full w-full"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// 主组件使用 Suspense 包裹
export default function PlanView() {
  return (
    <Suspense
      fallback={
        <div className="flex h-full items-center justify-center">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <span className="text-sm text-muted-foreground">Loading...</span>
          </div>
        </div>
      }
    >
      <PlanViewContent />
    </Suspense>
  );
}
