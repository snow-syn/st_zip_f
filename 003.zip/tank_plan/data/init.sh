#!/bin/bash

# 设置数据库文件路径
DB_FILE="tank_plan.db"
SQL_FILE="init.sql"

# 检查数据库文件是否存在，如果存在则删除
if [ -f "$DB_FILE" ]; then
    echo "Removing existing database file..."
    rm "$DB_FILE"
fi

# 创建新的数据库并执行初始化脚本
echo "Creating new database and initializing tables..."
sqlite3 "$DB_FILE" < "$SQL_FILE"

# 检查执行结果
if [ $? -eq 0 ]; then
    echo "Database initialization completed successfully!"
    echo "Database file: $DB_FILE"
    
    # 显示表结构
    echo -e "\nTable Structures:"
    echo -e "\napp_tank_plan_master:"
    sqlite3 "$DB_FILE" ".schema app_tank_plan_master"
    echo -e "\napp_tank_plan_detail:"
    sqlite3 "$DB_FILE" ".schema app_tank_plan_detail"
    
    # 显示数据统计
    echo -e "\nData Count:"
    echo "Master records: $(sqlite3 "$DB_FILE" "SELECT COUNT(*) FROM app_tank_plan_master;")"
    echo "Detail records: $(sqlite3 "$DB_FILE" "SELECT COUNT(*) FROM app_tank_plan_detail;")"
else
    echo "Error: Database initialization failed!"
    exit 1
fi 