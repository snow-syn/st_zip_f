import random
from datetime import datetime, timedelta
import calendar

# 随机用户名列表 (移除中文名)
USERS = ['John', 'Mary', 'David', 'Sarah', 'Mike', 'Emma', 'Tom', 'Alice', 'Bob', 'Kate']

# Tank相关数据
TANKS = ['T01', 'T02', 'T03', 'T04', 'T05', 'T06', 'T07', 'T08', 'T09', 'T10']
ISOS = ['ISO1', 'ISO2', 'ISO3', 'ISO4', 'ISO5']
GLASS_TYPES = ['Type A', 'Type B', 'Type C', 'Type D']
GENS = ['G8.5', 'G8.6', 'G10.5', 'G11']
RTS = ['RT1', 'RT2', 'RT3']
RCS = ['RC1', 'RC2', 'RC3']
PLATFORMS = ['Platform A', 'Platform B', 'Platform C']

def get_last_weekly_master_id(master_records, current_date):
    """获取上一个周三的最新Weekly记录的plan_master_id"""
    last_wednesday = current_date - timedelta(days=7)
    last_records = [r for r in master_records 
                   if r['plan_type'] == 'Weekly' 
                   and r['plan_version'] == last_wednesday.strftime('%Y-%m-%d')]
    if last_records:
        return max(r['plan_master_id'] for r in last_records)
    return 'NULL'

def generate_master_data():
    # 获取过去一年的日期范围
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365)
    current_date = start_date
    
    master_records = []
    plan_master_id = 1
    
    # 为每个月选择一个周三作为18MP标记日
    monthly_18mp_dates = {}
    current = start_date
    while current <= end_date:
        year_month = current.strftime('%Y-%m')
        if year_month not in monthly_18mp_dates:
            # 获取当月所有周三
            month_wednesdays = []
            month_start = current.replace(day=1)
            month_end = (month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            temp_date = month_start
            while temp_date <= month_end:
                if temp_date.weekday() == 2:  # 周三
                    month_wednesdays.append(temp_date)
                temp_date += timedelta(days=1)
            if month_wednesdays:
                monthly_18mp_dates[year_month] = random.choice(month_wednesdays)
        current += timedelta(days=1)
    
    while current_date <= end_date:
        # 处理每周三的Weekly数据
        if current_date.weekday() == 2:  # 周三
            num_records = random.randint(1, 3)
            plan_version = current_date.strftime('%Y-%m-%d')
            year_month = current_date.strftime('%Y-%m')
            
            # 检查是否是当月的18MP日期
            is_18mp = (current_date.date() == monthly_18mp_dates[year_month].date())
            
            for i in range(num_records):
                plan_official = '18MP' if is_18mp else ''
                version_match = current_date.strftime('%Y%m')
                
                record = {
                    'plan_master_id': plan_master_id,
                    'plan_version': plan_version,
                    'plan_type': 'Weekly',
                    'plan_official': plan_official,
                    'plan_version_no': i + 1,
                    'plan_version_parent': get_last_weekly_master_id(master_records, current_date),
                    'version_match': version_match,
                    'user_name': random.choice(USERS)
                }
                master_records.append(record)
                plan_master_id += 1
        
        # 处理月底的Long-term数据
        if current_date.day == calendar.monthrange(current_date.year, current_date.month)[1]:
            num_records = random.randint(1, 3)
            plan_version = current_date.strftime('%Y-%m-%d')
            
            for i in range(num_records):
                plan_official = 'GB' if current_date.month == 9 else ''
                version_match = current_date.strftime('%Y%m')
                
                record = {
                    'plan_master_id': plan_master_id,
                    'plan_version': plan_version,
                    'plan_type': 'Long-term',
                    'plan_official': plan_official,
                    'plan_version_no': i + 1,
                    'plan_version_parent': 'NULL',
                    'version_match': version_match,
                    'user_name': random.choice(USERS)
                }
                master_records.append(record)
                plan_master_id += 1
        
        current_date += timedelta(days=1)
    
    return master_records

def generate_detail_data(master_records):
    detail_records = []
    detail_id = 1
    
    for master in master_records:
        # 为每个master记录生成5-10条detail记录
        num_details = random.randint(20, 30)
        for i in range(num_details):
            last_tank_light = datetime.now() - timedelta(days=random.randint(30, 365))
            drain_date = last_tank_light + timedelta(days=random.randint(30, 90))
            repair_date = drain_date + timedelta(days=random.randint(10, 30))
            rtl_date = repair_date + timedelta(days=random.randint(10, 30))
            tl_date = rtl_date + timedelta(days=random.randint(10, 30))
            gg_date = tl_date + timedelta(days=random.randint(5, 15))
            
            record = {
                'plan_detail_id': detail_id,
                'plan_master_id': master['plan_master_id'],
                'plan_row_id': i + 1,
                'tank': random.choice(TANKS),
                'iso': random.choice(ISOS),
                'glass_type': random.choice(GLASS_TYPES),
                'gen': random.choice(GENS),
                'RT': random.choice(RTS),
                'RC': random.choice(RCS),
                'platform': random.choice(PLATFORMS),
                'design_asis': f'Design {random.randint(1, 5)}',
                'tank_life': round(random.uniform(1.0, 5.0), 2),
                'last_tank_light_date': last_tank_light.strftime('%Y-%m-%d'),
                'drain_date': drain_date.strftime('%Y-%m-%d'),
                'repair_date': repair_date.strftime('%Y-%m-%d'),
                'RTL_date': rtl_date.strftime('%Y-%m-%d'),
                'TL_date': tl_date.strftime('%Y-%m-%d'),
                'GG_date': gg_date.strftime('%Y-%m-%d'),
                'cold_idle': round(random.uniform(5.0, 15.0), 2),
                'repair_LT': round(random.uniform(10.0, 30.0), 2),
                'RTL_LT': round(random.uniform(5.0, 15.0), 2),
                'TL_LT': round(random.uniform(5.0, 15.0), 2),
                'remark_category': random.choice(['Inventory', 'Tanks issue', 'Schedule', 'Cost', 'Resource', 'Lead time', 'Other']),
                'remark': f'Test Note {random.randint(1, 100)}',
                'comment': f'Test Comment {random.randint(1, 100)}',
                'user_name': master['user_name']
            }
            detail_records.append(record)
            detail_id += 1
    
    return detail_records

def write_sql_files(master_records, detail_records):
    # 写入master数据
    with open('test_master_data.sql', 'w', encoding='utf-8') as f:
        f.write('-- Tank Plan Master Test Data\n')
        for record in master_records:
            sql = f"""INSERT INTO app_tank_plan_master 
                    (plan_master_id, plan_version, plan_type, plan_official, 
                     plan_version_no, plan_version_parent, version_match, user_name)
                    VALUES
                    ({record['plan_master_id']}, '{record['plan_version']}', 
                     '{record['plan_type']}', '{record['plan_official']}', 
                     {record['plan_version_no']}, {record['plan_version_parent']}, 
                     '{record['version_match']}', '{record['user_name']}');\n"""
            f.write(sql)
    
    # 写入detail数据
    with open('test_detail_data.sql', 'w', encoding='utf-8') as f:
        f.write('-- Tank Plan Detail Test Data\n')
        for record in detail_records:
            sql = f"""INSERT INTO app_tank_plan_detail 
                    (plan_detail_id, plan_master_id, plan_row_id, tank, iso, 
                     glass_type, gen, RT, RC, platform, design_asis, tank_life,
                     last_tank_light_date, drain_date, repair_date, RTL_date, 
                     TL_date, GG_date, cold_idle, repair_LT, RTL_LT, TL_LT,
                     remark_category, remark, comment, user_name)
                    VALUES
                    ({record['plan_detail_id']}, {record['plan_master_id']}, 
                     {record['plan_row_id']}, '{record['tank']}', '{record['iso']}',
                     '{record['glass_type']}', '{record['gen']}', '{record['RT']}',
                     '{record['RC']}', '{record['platform']}', '{record['design_asis']}',
                     {record['tank_life']}, '{record['last_tank_light_date']}',
                     '{record['drain_date']}', '{record['repair_date']}',
                     '{record['RTL_date']}', '{record['TL_date']}', '{record['GG_date']}',
                     {record['cold_idle']}, {record['repair_LT']}, {record['RTL_LT']},
                     {record['TL_LT']}, '{record['remark_category']}', '{record['remark']}',
                     '{record['comment']}', '{record['user_name']}');\n"""
            f.write(sql)

def main():
    master_records = generate_master_data()
    detail_records = generate_detail_data(master_records)
    write_sql_files(master_records, detail_records)
    
    # 统计每月的记录数
    monthly_counts = {}
    for record in master_records:
        month = record['plan_version'][:7]  # YYYY-MM
        monthly_counts[month] = monthly_counts.get(month, 0) + 1
    
    print(f"生成了 {len(master_records)} 条master记录")
    print(f"生成了 {len(detail_records)} 条detail记录")
    print("\n每月记录数统计:")
    for month, count in sorted(monthly_counts.items()):
        print(f"{month}: {count}条记录")

if __name__ == '__main__':
    main() 