import type { TankPlanData } from './types';

// 定义验证规则类型
export type ValidationRule = {
  type: 'required' | 'date' | 'number' | 'pattern';
  message?: string;
  pattern?: RegExp;
  min?: number;
  max?: number;
};

// 定义列配置接口
export interface ColumnConfig {
  key: string; // 数据库中的列名
  label: string; // 显示的标签名
  excelHeader: string; // Excel中的列名
  type: 'text' | 'date' | 'number'; // 列的数据类型
  validation?: ValidationRule[]; // 验证规则
  width?: number; // 列宽度
  hidden?: boolean; // 是否在表格中隐藏
  order?: number; // 显示顺序
  editable?: boolean; // 是否可编辑
  format?: {
    display?: (value: string) => string; // 显示格式化
    export?: (value: string) => string; // 导出格式化
  };
}

// 列配置对象
export const COLUMNS: Record<string, ColumnConfig> = {
  plan_id: {
    key: 'plan_id',
    label: 'Plan id',
    excelHeader: 'Plan id',
    type: 'text',
    order: 1,
    validation: [{ type: 'required', message: 'Plan id is required' }],
  },
  tank: {
    key: 'tank',
    label: 'Tank',
    excelHeader: 'Tank',
    type: 'text',
    order: 2,
    validation: [{ type: 'required', message: 'Tank is required' }],
  },
  isopipe: {
    key: 'isopipe',
    label: 'Isopipe',
    excelHeader: 'Isopipe',
    type: 'text',
    order: 3,
  },
  biz_2: {
    key: 'biz_2',
    label: 'Biz_2',
    excelHeader: 'Biz_2 (After R)',
    type: 'text',
    order: 4,
  },
  gen: {
    key: 'gen',
    label: 'Gen',
    excelHeader: 'Gen',
    type: 'text',
    order: 5,
  },
  rt: {
    key: 'rt',
    label: 'RT',
    excelHeader: 'RT',
    type: 'text',
    order: 6,
  },
  rc: {
    key: 'rc',
    label: 'RC',
    excelHeader: 'RC',
    type: 'text',
    order: 7,
  },
  design_as_is: {
    key: 'design_as_is',
    label: 'Design As Is',
    excelHeader: 'Design_As Is',
    type: 'text',
    order: 8,
  },
  design_to_be: {
    key: 'design_to_be',
    label: 'Design To Be',
    excelHeader: 'Design_To Be',
    type: 'text',
    order: 9,
  },
  tank_life: {
    key: 'tank_life',
    label: 'Tank Life',
    excelHeader: 'Tank Life',
    type: 'number',
    order: 10,
  },
  last_tank_light: {
    key: 'last_tank_light',
    label: 'Last Tank Light',
    excelHeader: 'Last Tank Light',
    type: 'date',
    order: 11,
    validation: [{ type: 'date', message: 'Invalid date format' }],
  },
  drain: {
    key: 'drain',
    label: 'Drain',
    excelHeader: 'Drain',
    type: 'date',
    order: 12,
    validation: [{ type: 'date', message: 'Invalid date format' }],
  },
  start: {
    key: 'start',
    label: 'Start',
    excelHeader: 'Start',
    type: 'date',
    order: 13,
    validation: [{ type: 'date', message: 'Invalid date format' }],
  },
  rtl: {
    key: 'rtl',
    label: 'RTL',
    excelHeader: 'RTL',
    type: 'date',
    order: 14,
    validation: [{ type: 'date', message: 'Invalid date format' }],
  },
  light: {
    key: 'light',
    label: 'Light',
    excelHeader: 'Light',
    type: 'date',
    order: 15,
    validation: [{ type: 'date', message: 'Invalid date format' }],
  },
  good_glass: {
    key: 'good_glass',
    label: 'Good Glass',
    excelHeader: 'Good Glass',
    type: 'date',
    order: 16,
    validation: [{ type: 'date', message: 'Invalid date format' }],
  },
  idle_conv_days: {
    key: 'idle_conv_days',
    label: "Idle/Conv' Days",
    excelHeader: "Idle/Conv' Days",
    type: 'number',
    order: 17,
    validation: [
      {
        type: 'number',
        min: 0,
        max: 999,
        message: "Idle/Conv' Days must be a number between 0 and 999",
      },
    ],
  },
  installation_days: {
    key: 'installation_days',
    label: 'Installation Days',
    excelHeader: 'Installation Days',
    type: 'number',
    order: 18,
    validation: [
      {
        type: 'number',
        min: 0,
        max: 999,
        message: 'Installation Days must be a number between 0 and 999',
      },
    ],
  },
  protective_days: {
    key: 'protective_days',
    label: 'Protective Days',
    excelHeader: 'Protective Days',
    type: 'number',
    order: 19,
    validation: [
      {
        type: 'number',
        min: 0,
        max: 999,
        message: 'Protective Days must be a number between 0 and 999',
      },
    ],
  },
  startup_days: {
    key: 'startup_days',
    label: 'Start-up Days',
    excelHeader: 'Start-up Days',
    type: 'number',
    order: 20,
    validation: [
      {
        type: 'number',
        min: 0,
        max: 999,
        message: 'Start-up Days must be a number between 0 and 999',
      },
    ],
  },
  comments: {
    key: 'comments',
    label: 'Comments',
    excelHeader: 'Comments',
    type: 'text',
    order: 21,
  },
};

// 辅助函数
export const getColumns = () =>
  Object.values(COLUMNS).sort((a, b) => (a.order || 0) - (b.order || 0));

export const getVisibleColumns = () =>
  getColumns().filter((col) => !col.hidden);

export const getRequiredColumns = () =>
  getColumns().filter((col) =>
    col.validation?.some((rule) => rule.type === 'required'),
  );

export const getDateColumns = () =>
  getColumns().filter((col) => col.type === 'date');

export const getEditableColumns = () =>
  getColumns().filter((col) => col.editable !== false);

export const getColumnKeys = () => getColumns().map((col) => col.key);

// 获取Excel列名映射
export const getExcelHeaderMap = () => {
  const map = new Map<string, string>();
  Object.values(COLUMNS).forEach((col) => {
    map.set(col.excelHeader, col.key);
  });
  return map;
};

// 获取所有Excel列名
export const getExcelHeaders = () =>
  Object.values(COLUMNS).map((col) => col.excelHeader);

// 类型定义
export type ColumnKey = keyof typeof COLUMNS;
export type DateColumn = Extract<ColumnKey, keyof TankPlanData>;

// 常量导出
export const TANK_COLUMNS = getColumnKeys();
export const REQUIRED_COLUMNS = getRequiredColumns().map((col) => col.key);
export const DATE_COLUMNS = getDateColumns().map((col) => col.key);

// 验证工具函数
export const validateField = (
  value: string,
  column: ColumnConfig,
): string | null => {
  if (!column.validation) return null;

  for (const rule of column.validation) {
    switch (rule.type) {
      case 'required':
        if (!value || !value.trim()) {
          return rule.message || `${column.label} is required`;
        }
        break;
      case 'date':
        if (value && !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
          return rule.message || `${column.label} must be in YYYY-MM-DD format`;
        }
        break;
      case 'number':
        const num = Number(value);
        if (value && isNaN(num)) {
          return rule.message || `${column.label} must be a number`;
        }
        if (rule.min !== undefined && num < rule.min) {
          return rule.message || `${column.label} must be at least ${rule.min}`;
        }
        if (rule.max !== undefined && num > rule.max) {
          return rule.message || `${column.label} must be at most ${rule.max}`;
        }
        break;
      case 'pattern':
        if (value && rule.pattern && !rule.pattern.test(value)) {
          return rule.message || `${column.label} has invalid format`;
        }
        break;
    }
  }
  return null;
};
