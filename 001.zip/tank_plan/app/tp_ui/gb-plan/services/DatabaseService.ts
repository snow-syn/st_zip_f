import { COLUMNS, getColumns, getColumnKeys, validateField } from '../config';
import type { TankPlanData, DatabricksResponse } from '../types';
import { DateUtils } from '../utils';

export class DatabaseService {
  private static readonly API_BASE_URL =
    process.env.NEXT_PUBLIC_DATABRICKS_API_URL;
  private static readonly API_TOKEN = process.env.NEXT_PUBLIC_DATABRICKS_TOKEN;

  private static async executeQuery(sql: string) {
    try {
      if (!this.API_BASE_URL || !this.API_TOKEN) {
        throw new Error('Missing API configuration');
      }

      const response = await fetch(`${this.API_BASE_URL}/sql/query`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.API_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sql }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Database operation failed:', error);
      throw error;
    }
  }

  static async savePlanData(
    data: TankPlanData[],
  ): Promise<DatabricksResponse<{ version: string }>> {
    try {
      const version = `GB_${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`;
      const errors = this.validatePlanData(data);

      if (errors.length) {
        return { success: false, errors };
      }

      const values = data
        .map((row) => this.formatRowForInsert(row, version))
        .join(',');
      const sql = `
        INSERT INTO tank_plan (
          plan_version, plan_type, plan_version_no, plan_row_id,
          tank, iso, glass_type, gen, RT, RC, platform,
          tank_life, last_tank_light_date, drain_date,
          repair_date, RTL_date, TL_date, GG_date,
          cold_idle, repair_LT, RTL_LT, TL_LT,
          remark_category, remark,
          create_timestamp, update_timestamp
        ) VALUES ${values}
      `;

      await this.executeQuery(sql);
      return { success: true, data: { version } };
    } catch (error) {
      return {
        success: false,
        error:
          error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }
  }

  static async getLatestPlanData(): Promise<
    DatabricksResponse<TankPlanData[]>
  > {
    if (process.env.NODE_ENV === 'development') {
      try {
        console.log('Using mock API in development environment');
        const response = await fetch('/api/gb-plan', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) {
          throw new Error(`Mock API error! status: ${response.status}`);
        }

        const result = await response.json();
        return result;
      } catch (error) {
        console.error('Mock API error:', error);
        return this.handleDatabaseError(error);
      }
    }

    try {
      if (!this.API_BASE_URL || !this.API_TOKEN) {
        throw new Error('Missing API configuration');
      }

      const sql = this.buildLatestPlanQuery();
      this.debugLog('Query', { sql });

      const startTime = performance.now();
      const response = await this.executeQuery(sql);
      const queryTime = performance.now() - startTime;

      this.debugLog('RawResponse', {
        responseTime: `${queryTime.toFixed(2)}ms`,
        hasResults: !!response?.results,
        resultCount: response?.results?.length,
        sampleRow: response?.results?.[0],
      });

      if (!this.isValidResponse(response)) {
        this.debugLog('InvalidResponse', { response });
        return this.createErrorResponse('No data returned from database');
      }

      const transformStart = performance.now();
      const data = this.transformResponseData(response.results);
      const transformTime = performance.now() - transformStart;

      this.debugLog('TransformedData', {
        transformTime: `${transformTime.toFixed(2)}ms`,
        rowCount: data.length,
        sampleRow: data[0],
        columnCheck: getColumnKeys().map((col) => ({
          column: col,
          present: data[0]?.[col] !== undefined,
        })),
      });

      return {
        success: true,
        data,
        debug: {
          queryTime,
          transformTime,
          rowCount: data.length,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      this.debugLog('Error', {
        error,
        message: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
      });
      return this.handleDatabaseError(error);
    }
  }

  private static buildLatestPlanQuery(): string {
    const columns = getColumnKeys().join(',\n        ');

    return `
      WITH latest_version AS (
        SELECT MAX(plan_version) as version
        FROM tank_plan
        WHERE plan_type = 'GB'
        AND create_timestamp >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
      )
      SELECT 
        ${columns}
      FROM tank_plan
      WHERE plan_version = (SELECT version FROM latest_version)
      ORDER BY plan_row_id
    `;
  }

  private static isValidResponse(response: any): boolean {
    return response?.results && Array.isArray(response.results);
  }

  private static transformResponseData(results: any[]): TankPlanData[] {
    const transformedData = results.map((row: any, index: number) => {
      try {
        const transformedRow = this.transformDatabaseRow(row);
        const validatedRow = this.ensureRequiredColumns(transformedRow);

        // 详细的转换调试信息
        this.debugLog(`Transform-Row-${index}`, {
          original: row,
          transformed: transformedRow,
          validated: validatedRow,
          changes: Object.keys(validatedRow).filter(
            (key) => validatedRow[key as keyof TankPlanData] !== row[key],
          ),
        });

        return validatedRow;
      } catch (error) {
        this.debugLog(`Transform-Error-Row-${index}`, {
          error,
          row,
        });
        throw error;
      }
    });

    return transformedData;
  }

  private static ensureRequiredColumns(row: TankPlanData): TankPlanData {
    Object.keys(COLUMNS).forEach((key) => {
      if (!row[key as keyof TankPlanData]) {
        row[key as keyof TankPlanData] = '';
      }
    });
    return row;
  }

  private static createErrorResponse(
    message: string,
  ): DatabricksResponse<TankPlanData[]> {
    return {
      success: false,
      error: message,
    };
  }

  private static handleDatabaseError(
    error: unknown,
  ): DatabricksResponse<TankPlanData[]> {
    console.error('Failed to fetch latest plan data:', error);
    return this.createErrorResponse(
      error instanceof Error
        ? error.message
        : 'Failed to fetch latest plan data',
    );
  }

  private static validatePlanData(data: TankPlanData[]): string[] {
    const errors: string[] = [];

    data.forEach((row, index) => {
      Object.values(COLUMNS).forEach((column) => {
        if (!column.validation) return;

        const value = row[column.key];
        const error = validateField(value, column);
        if (error) {
          errors.push(`Row ${index + 1}: ${error}`);
        }
      });
    });

    return errors;
  }

  private static formatRowForInsert(
    row: TankPlanData,
    version: string,
  ): string {
    const escape = (value: string) =>
      value ? `'${value.replace(/'/g, "''")}'` : "''";
    const formatDate = (value: string) =>
      value ? `'${DateUtils.format(value)}'` : "''";

    const values = getColumns().map((column) => {
      const value = row[column.key];
      return column.type === 'date' ? formatDate(value) : escape(value);
    });

    return `(${values.join(', ')})`;
  }

  private static transformDatabaseRow(row: any): TankPlanData {
    const transformedRow = {} as TankPlanData;

    Object.keys(COLUMNS).forEach((key) => {
      const column = COLUMNS[key];
      const value = row[key];

      transformedRow[key] = value ? String(value) : '';

      // 处理日期字段
      if (column.type === 'date' && value) {
        transformedRow[key] = DateUtils.format(value);
      }
    });

    return transformedRow;
  }

  private static debugLog(stage: string, details: unknown) {
    console.group(`📊 Database Debug - ${stage}`);
    console.log('Details:', details);
    console.groupEnd();
  }
}
